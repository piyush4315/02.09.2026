import re

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

clean_calc_late_fee = r"""function calcLateFee(r) {
  var baseDate = new Date(2026, 7, 24); // 24 Aug 2026 (0-indexed month 7)
  var payDate = null;
  if (r && r.fp_date) {
    payDate = parseDateStr(r.fp_date);
  }
  var isSettled = (numOr(r && r.fp_received) > 0 && (numOr(r && r.total_receivables) - (numOr(r && r.sd_received) + numOr(r && r.fp_received))) <= SETTLEMENT_TOLERANCE);
  if (!payDate) {
    if (!isSettled) {
      payDate = new Date(2026, 7, 31); // 31 Aug 2026
    } else {
      payDate = baseDate;
    }
  }
  if (!payDate) return 0;
  var diffMs = payDate.getTime() - baseDate.getTime();
  var diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays <= 0) return 0;
  var weeks = Math.ceil(diffDays / 7);
  var baseAmt = numOr(r && r.mat_value);
  return Math.round(baseAmt * weeks * 0.01);
}"""

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Replace calcLateFee function
    content = re.sub(
        r"function calcLateFee\(r\) \{[\s\S]*?\n\}\nwindow\.calcLateFee = calcLateFee;",
        clean_calc_late_fee + "\nwindow.calcLateFee = calcLateFee;",
        content
    )

    # 2. Update XLSX_COLS formula in HTML if using W{r} to use H{r}
    content = re.sub(
        r"ROUND\(W\{r\}\*ROUNDUP",
        r"ROUND(H{r}*ROUNDUP",
        content
    )

    # 3. Update advice modal text descriptions to specify "on Material Value"
    content = content.replace("1% per wk on balance FP", "1% per wk on Material Value")
    content = content.replace("1% per week or part thereof on final balance", "1% per week or part thereof on Material Value")

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"Updated {fpath} successfully!")
