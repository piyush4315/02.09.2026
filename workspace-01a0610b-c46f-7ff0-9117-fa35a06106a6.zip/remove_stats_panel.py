import re

def clean_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Remove JavaScript stats calculation and statsHtml in showHeaderContextMenu
    old_js_stats_block = """    // Calculate column summary statistics (SUM, AVG, COUNT) for context menu
    var numSum = 0, numCount = 0, hasNumeric = false;
    var rowsToScan = isDetail ? detailRows : (typeof pivotRows !== 'undefined' ? pivotRows : lots);
    if (rowsToScan && rowsToScan.length) {
      rowsToScan.forEach(function (r) {
        if (!r) return;
        var val = r[field];
        if (val !== undefined && val !== null && val !== '') {
          var n = Number(val);
          if (!isNaN(n) && typeof val !== 'boolean') {
            numSum += n;
            numCount++;
            hasNumeric = true;
          }
        }
      });
    }

    var isMoney = typeof MONEY_FIELDS !== 'undefined' && MONEY_FIELDS.has(field);
    var isNum = typeof NUM_FIELDS !== 'undefined' && (NUM_FIELDS.indexOf(field) !== -1 || field === 'qty' || field === 'rate' || field === 'gst_tds_rate' || field === 'lots');
    var statsHtml = '';
    if (hasNumeric && (isMoney || isNum || numCount > 0)) {
      var avg = numCount > 0 ? (numSum / numCount) : 0;
      var sumDisp = isMoney ? ('₹ ' + inr(Math.round(numSum))) : numFmt(Math.round(numSum * 100) / 100);
      var avgDisp = isMoney ? ('₹ ' + inr(Math.round(avg))) : numFmt(Math.round(avg * 100) / 100);
      statsHtml =
        '<div class="xl-stats">' +
          '<div class="xl-stat-box" data-copy="' + numSum + '" title="Click to copy Column SUM (' + escHtml(sumDisp) + ')">' +
            '<span class="xl-stat-lbl">SUM</span>' +
            '<span class="xl-stat-val accent">' + escHtml(sumDisp) + '</span>' +
          '</div>' +
          '<div class="xl-stat-box" data-copy="' + (Math.round(avg * 100) / 100) + '" title="Column Average (' + escHtml(avgDisp) + ')">' +
            '<span class="xl-stat-lbl">AVG</span>' +
            '<span class="xl-stat-val">' + escHtml(avgDisp) + '</span>' +
          '</div>' +
          '<div class="xl-stat-box" title="Rows with values">' +
            '<span class="xl-stat-lbl">COUNT</span>' +
            '<span class="xl-stat-val">' + numCount + '</span>' +
          '</div>' +
        '</div>';
    } else {
      statsHtml =
        '<div class="xl-stats">' +
          '<div class="xl-stat-box" title="Total rows">' +
            '<span class="xl-stat-lbl">TOTAL ROWS</span>' +
            '<span class="xl-stat-val accent">' + (rowsToScan ? rowsToScan.length : 0) + '</span>' +
          '</div>' +
        '</div>';
    }"""

    if old_js_stats_block in content:
        content = content.replace(old_js_stats_block, '')
        print(f"Removed JS stats calculation from {file_path}")

    # Remove statsHtml from menu.innerHTML = actions + statsHtml + filterHtml;
    content = content.replace('menu.innerHTML = actions + statsHtml + filterHtml;', 'menu.innerHTML = actions + filterHtml;')

    # Remove xl-stat-box click handler
    old_click_handler = """    menu.querySelectorAll('.xl-stat-box[data-copy]').forEach(function(box) {
      box.addEventListener('click', function(ev) {
        ev.stopPropagation();
        var val = box.getAttribute('data-copy');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(val).then(function() {
            showToast('Copied: ' + val, 'ok');
          });
        }
      });
    });"""
    if old_click_handler in content:
        content = content.replace(old_click_handler, '')

    # 2. Clean up CSS for .xl-stats
    content = re.sub(r'/\* Context Menu Column Stats \(Dark Theme\) \*/\s*\.excel-menu \.xl-stats\s*\{[^}]*\}\s*\.excel-menu \.xl-stat-box\s*\{[^}]*\}\s*\.excel-menu \.xl-stat-box:hover\s*\{[^}]*\}\s*\.excel-menu \.xl-stat-lbl\s*\{[^}]*\}\s*\.excel-menu \.xl-stat-val\s*\{[^}]*\}\s*\.excel-menu \.xl-stat-val\.accent\s*\{[^}]*\}', '', content)

    content = re.sub(r'\[data-theme="light"\] \.excel-menu \.xl-stats\s*\{[^}]*\}\s*\[data-theme="light"\] \.excel-menu \.xl-stat-box\s*\{[^}]*\}\s*\[data-theme="light"\] \.excel-menu \.xl-stat-box:hover\s*\{[^}]*\}\s*\[data-theme="light"\] \.excel-menu \.xl-stat-lbl\s*\{[^}]*\}\s*\[data-theme="light"\] \.excel-menu \.xl-stat-val\s*\{[^}]*\}\s*\[data-theme="light"\] \.excel-menu \.xl-stat-val\.accent\s*\{[^}]*\}', '', content)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"File {file_path} cleaned.")

clean_file('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
clean_file('/home/user/index.html')
clean_file('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
