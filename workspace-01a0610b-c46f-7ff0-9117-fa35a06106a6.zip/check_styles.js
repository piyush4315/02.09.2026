const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(500);

  const darkSettled = await page.evaluate(() => {
    const el = document.querySelector(".lbl-settled");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow, radius: cs.borderRadius };
  });
  console.log("Dark Settled Chip:", darkSettled);

  const darkUnsettled = await page.evaluate(() => {
    const el = document.querySelector(".lbl-unsettled");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow, radius: cs.borderRadius };
  });
  console.log("Dark Unsettled Chip:", darkUnsettled);

  // Switch to light theme
  await page.click("#themeToggleBtn");
  await page.waitForTimeout(300);

  const lightSettled = await page.evaluate(() => {
    const el = document.querySelector(".lbl-settled");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow, radius: cs.borderRadius };
  });
  console.log("Light Settled Chip:", lightSettled);

  const lightUnsettled = await page.evaluate(() => {
    const el = document.querySelector(".lbl-unsettled");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow, radius: cs.borderRadius };
  });
  console.log("Light Unsettled Chip:", lightUnsettled);

  const pivotSegS = await page.evaluate(() => {
    const el = document.querySelector(".settled-counts .seg.s");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow };
  });
  console.log("Light Pivot Seg S:", pivotSegS);

  const pivotSegU = await page.evaluate(() => {
    const el = document.querySelector(".settled-counts .seg.u");
    if (!el) return null;
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, shadow: cs.boxShadow };
  });
  console.log("Light Pivot Seg U:", pivotSegU);

  await browser.close();
})();
