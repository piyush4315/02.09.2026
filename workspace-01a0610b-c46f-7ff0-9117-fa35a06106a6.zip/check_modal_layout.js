const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);

  const firstLotCell = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (firstLotCell) {
    await firstLotCell.click();
    await page.waitForTimeout(400);

    const colsInfo = await page.evaluate(() => {
      const cols = Array.from(document.querySelectorAll('.lot-inspect-col')).map(c => ({
        head: c.querySelector('.lic-head')?.textContent,
        width: c.offsetWidth,
        height: c.offsetHeight
      }));
      const kpiCards = Array.from(document.querySelectorAll('.lot-kpi-card')).map(k => ({
        lbl: k.querySelector('.lk-lbl')?.textContent,
        val: k.querySelector('.lk-val')?.textContent,
        width: k.offsetWidth,
        height: k.offsetHeight
      }));
      return { cols, kpiCards };
    });

    console.log('Columns on mobile portrait:', JSON.stringify(colsInfo, null, 2));

    await page.screenshot({ path: '/home/user/mobile_lot_inspect_modal_top.png' });

    // Scroll down inside modal body
    await page.evaluate(() => {
      const modalBody = document.querySelector('.modal-body');
      if (modalBody) modalBody.scrollTop = 400;
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: '/home/user/mobile_lot_inspect_modal_scrolled.png' });
    console.log('Saved mobile_lot_inspect_modal screenshots');
  }

  await browser.close();
})();
