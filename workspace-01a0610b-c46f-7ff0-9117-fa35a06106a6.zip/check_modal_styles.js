const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);

  const firstLotCell = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (firstLotCell) {
    await firstLotCell.click();
    await page.waitForTimeout(300);

    const info = await page.evaluate(() => {
      const modal = document.querySelector('.modal');
      const modalBody = document.querySelector('.modal-body');
      const kpis = document.querySelector('.lot-inspect-kpis');
      const cols = document.querySelector('.lot-inspect-cols');
      return {
        modal: modal ? {
          width: modal.offsetWidth,
          height: modal.offsetHeight,
          maxHeight: getComputedStyle(modal).maxHeight,
          overflow: getComputedStyle(modal).overflow
        } : null,
        modalBody: modalBody ? {
          overflowY: getComputedStyle(modalBody).overflowY,
          scrollHeight: modalBody.scrollHeight,
          clientHeight: modalBody.clientHeight
        } : null,
        kpisGrid: kpis ? getComputedStyle(kpis).gridTemplateColumns : null,
        colsGrid: cols ? getComputedStyle(cols).gridTemplateColumns : null
      };
    });
    console.log('Modal style info on mobile portrait:', JSON.stringify(info, null, 2));
  }

  await browser.close();
})();
