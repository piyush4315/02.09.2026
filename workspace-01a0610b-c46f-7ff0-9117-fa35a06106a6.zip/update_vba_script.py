with open('/home/user/ScrapSale_Pro_VBA_Suite.bas', 'r', encoding='utf-8') as f:
    vba = f.read()

vba = vba.replace('Late Fee @ 1% / Wk', 'Late Fee')
vba = vba.replace('Late Fee @ 1%/wk', 'Late Fee')
vba = vba.replace('Late Fee @ 1%', 'Late Fee')

with open('/home/user/ScrapSale_Pro_VBA_Suite.bas', 'w', encoding='utf-8') as f:
    f.write(vba)

print("Updated ScrapSale_Pro_VBA_Suite.bas")
