import json
import re
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# 1. Load SAMPLE_DATA from SaaS HTML
with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html') as f:
    c = f.read()

m = re.search(r'var SAMPLE_DATA = (\[.*?\]);', c)
if not m:
    raise Exception("SAMPLE_DATA not found")
sample_data = json.loads(m.group(1))

wb = openpyxl.Workbook()

# Style constants
FONT_NAME = 'Segoe UI'
COLOR_HEADER_BG = '0D0D24'
COLOR_HEADER_FG = '00F5FF'
COLOR_ACCENT = '7C3AED'
COLOR_ZEBRA = 'F8FAFC'
COLOR_BORDER = 'E2E8F0'

font_title = Font(name=FONT_NAME, size=16, bold=True, color='1E1B4B')
font_subtitle = Font(name=FONT_NAME, size=10.5, italic=True, color='64748B')
font_section = Font(name=FONT_NAME, size=13, bold=True, color='1E1B4B')
font_header = Font(name=FONT_NAME, size=10, bold=True, color='FFFFFF')
font_data = Font(name=FONT_NAME, size=10, color='1E293B')
font_bold = Font(name=FONT_NAME, size=10, bold=True, color='1E293B')
font_total = Font(name=FONT_NAME, size=10, bold=True, color='000000')

fill_header = PatternFill(start_color='1E1B4B', end_color='1E1B4B', fill_type='solid')
fill_header_accent = PatternFill(start_color='312E81', end_color='312E81', fill_type='solid')
fill_total = PatternFill(start_color='E0E7FF', end_color='E0E7FF', fill_type='solid')
fill_zebra = PatternFill(start_color='F1F5F9', end_color='F1F5F9', fill_type='solid')

fill_card1 = PatternFill(start_color='1E293B', end_color='1E293B', fill_type='solid')
fill_card2 = PatternFill(start_color='312E81', end_color='312E81', fill_type='solid')
fill_card3 = PatternFill(start_color='065F46', end_color='065F46', fill_type='solid')
fill_card4 = PatternFill(start_color='831843', end_color='831843', fill_type='solid')

thin_border_side = Side(style='thin', color='CBD5E1')
border_cell = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=thin_border_side)
border_top_thick = Border(top=Side(style='medium', color='1E1B4B'), bottom=Side(style='double', color='1E1B4B'), left=thin_border_side, right=thin_border_side)

align_center = Alignment(horizontal='center', vertical='center', wrap_text=True)
align_left = Alignment(horizontal='left', vertical='center', wrap_text=True)
align_right = Alignment(horizontal='right', vertical='center')
align_header = Alignment(horizontal='center', vertical='center', wrap_text=True)

# -------------------------------------------------------------
# SHEET 1: Dashboard & Controls
# -------------------------------------------------------------
ws_dash = wb.active
ws_dash.title = "Dashboard & Controls"
ws_dash.views.sheetView[0].showGridLines = True

ws_dash['A1'] = "ScrapSale Pro — Cash Receivables Management SaaS"
ws_dash['A1'].font = Font(name=FONT_NAME, size=18, bold=True, color='1E1B4B')
ws_dash['A2'] = "Live Real-Time Dashboard with Delayed Payment Charges from 24th Aug 2026 | MSETCL"
ws_dash['A2'].font = Font(name=FONT_NAME, size=11, italic=True, color='64748B')

ws_dash['A4'] = "FINANCIAL SUMMARY & EXECUTIVE KPI METRICS"
ws_dash['A4'].font = font_section

cards = [
    ("B5", "D5", "TOTAL MATERIAL VALUE", fill_card1, "B6", "D6", "=SUM('Lot Details'!$H$4:$H$40)", '₹ #,##0'),
    ("E5", "G5", "TOTAL RECEIVABLES IN CASH", fill_card2, "E6", "G6", "=SUM('Lot Details'!$S$4:$S$40)", '₹ #,##0'),
    ("H5", "J5", "TOTAL AMOUNT RECEIVED", fill_card3, "H6", "J6", "=SUM('Lot Details'!$AA$4:$AA$40)", '₹ #,##0'),
    ("K5", "M5", "OUTSTANDING RECEIVABLES", fill_card4, "K6", "M6", "=SUM('Lot Details'!$AB$4:$AB$40)", '₹ #,##0')
]

for t_start, t_end, title, fill, v_start, v_end, formula, fmt in cards:
    ws_dash.merge_cells(f"{t_start}:{t_end}")
    cell_t = ws_dash[t_start]
    cell_t.value = title
    cell_t.font = Font(name=FONT_NAME, size=9.5, bold=True, color='E2E8F0')
    cell_t.alignment = align_center
    cell_t.fill = fill
    
    ws_dash.merge_cells(f"{v_start}:{v_end}")
    cell_v = ws_dash[v_start]
    cell_v.value = formula
    cell_v.font = Font(name=FONT_NAME, size=15, bold=True, color='FFFFFF')
    cell_v.alignment = align_center
    cell_v.fill = fill
    cell_v.number_format = fmt

sec_cards = [
    ("B8", "D8", "TOTAL SCRAP LOTS", fill_card1, "B9", "D9", "=COUNTA('Lot Details'!$F$4:$F$40)", '#,##0'),
    ("E8", "G8", "TOTAL LATE FEES ACCRUED (@ 1%/WK)", fill_card4, "E9", "G9", "=SUM('Lot Details'!$Z$4:$Z$40)", '₹ #,##0'),
    ("H8", "J8", "SETTLED LOTS COUNT", fill_card3, "H9", "J9", "=COUNTIF('Lot Details'!$AC$4:$AC$40, \"Settled\")", '#,##0'),
    ("K8", "M8", "CASH COLLECTION RATE", fill_card2, "K9", "M9", "=H6/(E6+E9)", '0.0%')
]

for t_start, t_end, title, fill, v_start, v_end, formula, fmt in sec_cards:
    ws_dash.merge_cells(f"{t_start}:{t_end}")
    cell_t = ws_dash[t_start]
    cell_t.value = title
    cell_t.font = Font(name=FONT_NAME, size=9.5, bold=True, color='E2E8F0')
    cell_t.alignment = align_center
    cell_t.fill = fill
    
    ws_dash.merge_cells(f"{v_start}:{v_end}")
    cell_v = ws_dash[v_start]
    cell_v.value = formula
    cell_v.font = Font(name=FONT_NAME, size=15, bold=True, color='FFFFFF')
    cell_v.alignment = align_center
    cell_v.fill = fill
    cell_v.number_format = fmt

ws_dash['A12'] = "INTERACTIVE VBA MACROS & CONTROL SHORTCUTS"
ws_dash['A12'].font = font_section

controls_table = [
    ("Action / Feature", "VBA Macro Procedure", "Keyboard Shortcut", "Description"),
    ("↺ Reset All Filters", "ResetAllFilters", "Ctrl + Shift + R", "Clears all column filters, reveals all hidden rows/columns, and restores standard view."),
    ("📅 Select Date from Calendar", "OpenCalendarPicker", "Double-Click Date Cell", "Opens popup monthly calendar defaulting to current month for 1-click date picking."),
    ("📅 Stamp Today's Date", "StampTodayDate", "Ctrl + Shift + D", "Stamps today's current date (DD.MM.YYYY) into selected date cell."),
    ("⊞ Toggle Lot Columns (1-3)", "ToggleLotColumns", "Ctrl + Shift + L", "Expands/collapses Qty, Rate, and Lot Name under Bid Sheet column."),
    ("⊞ Toggle MSTC SC Breakup", "ToggleChargeColumns", "Ctrl + Shift + M", "Expands/collapses MSTC SC 2.25%, TDS 194H, and Net SC 2.71% columns."),
    ("🔍 Filter Unsettled Lots", "FilterUnsettledLots", "Ctrl + Shift + U", "Instantly filters Lot Details to display only Unsettled lots with pending balance."),
    ("🔍 Filter Settled Lots", "FilterSettledLots", "Ctrl + Shift + S", "Filters table to show only fully Settled lots."),
    ("🔍 Filter by Buyer Name", "FilterByBuyerPrompt", "Ctrl + Shift + B", "Interactive popup dialog to select and filter lots for a specific buyer."),
    ("🔍 Quick Universal Search", "QuickSearchPrompt", "Ctrl + Shift + F", "Instant search across lot number, buyer name, material name, and invoice number.")
]

row_idx = 14
for c_idx, head in enumerate(controls_table[0], start=2):
    cell = ws_dash.cell(row=row_idx, column=c_idx, value=head)
    cell.font = font_header
    cell.fill = fill_header
    cell.alignment = align_header
    cell.border = border_cell

for row_data in controls_table[1:]:
    row_idx += 1
    for c_idx, val in enumerate(row_data, start=2):
        cell = ws_dash.cell(row=row_idx, column=c_idx, value=val)
        cell.font = font_bold if c_idx == 2 else font_data
        cell.alignment = align_center if c_idx in [3, 4] else align_left
        cell.border = border_cell
        if (row_idx % 2 == 1):
            cell.fill = fill_zebra

dash_col_widths = {'A': 4, 'B': 24, 'C': 26, 'D': 22, 'E': 24, 'F': 22, 'G': 22, 'H': 24, 'I': 22, 'J': 22, 'K': 24, 'L': 22, 'M': 22}
for col_letter, w in dash_col_widths.items():
    ws_dash.column_dimensions[col_letter].width = w

# -------------------------------------------------------------
# SHEET 2: Lot Details (With Delayed Payment Charges & Live Excel Formulas)
# -------------------------------------------------------------
ws_lots = wb.create_sheet(title="Lot Details")
ws_lots.views.sheetView[0].showGridLines = True

headers_lots = [
    ("Qty", "A", align_right, '#,##0.00'),
    ("Rate", "B", align_right, '₹ #,##0.00'),
    ("Lot Name", "C", align_left, '@'),
    ("Bid Sheet", "D", align_center, '0'),
    ("Unit", "E", align_center, '@'),
    ("Lot No.", "F", align_center, '0'),
    ("Buyer", "G", align_left, '@'),
    ("Mat. Value", "H", align_right, '₹ #,##0'),
    ("GST (18%)", "I", align_right, '₹ #,##0'),
    ("Mat. Value + GST", "J", align_right, '₹ #,##0'),
    ("TCS (2%)", "K", align_right, '₹ #,##0'),
    ("TDS u/s 194(O)", "L", align_right, '₹ #,##0'),
    ("SC to MSTC", "M", align_right, '₹ #,##0'),
    ("TDS u/s 194(H)", "N", align_right, '₹ #,##0'),
    ("Net SC (2.71%)", "O", align_right, '₹ #,##0'),
    ("Service Charge to MSTC", "P", align_right, '₹ #,##0'),
    ("GST TDS Rate (%)", "Q", align_center, '0.0"%"'),
    ("GST TDS", "R", align_right, '₹ #,##0'),
    ("Total Receivables in Cash", "S", align_right, '₹ #,##0'),
    ("SD Expected (25%)", "T", align_right, '₹ #,##0'),
    ("SD Received", "U", align_right, '₹ #,##0'),
    ("SD Date", "V", align_center, 'DD.MM.YYYY'),
    ("FP Expected", "W", align_right, '₹ #,##0'),
    ("FP Received", "X", align_right, '₹ #,##0'),
    ("FP Date", "Y", align_center, 'DD.MM.YYYY'),
    ("Delayed Payment Charges", "Z", align_right, '₹ #,##0'),
    ("Total Received", "AA", align_right, '₹ #,##0'),
    ("Outstanding", "AB", align_right, '₹ #,##0'),
    ("Settlement Status", "AC", align_center, '@'),
    ("Invoice No.", "AD", align_center, '@'),
    ("SAP Document No.", "AE", align_center, '@'),
    ("Doc./Invoice Date", "AF", align_center, 'DD.MM.YYYY')
]

ws_lots['A1'] = "ScrapSale Pro — Detailed Lot Ledger"
ws_lots['A1'].font = Font(name=FONT_NAME, size=16, bold=True, color='1E1B4B')
ws_lots['A2'] = "Real-Time Calculated Receivables with Delayed Payment Charges from 24th Aug 2026, MSTC SC 2.71%, and GST TDS 2%"
ws_lots['A2'].font = Font(name=FONT_NAME, size=10.5, italic=True, color='64748B')

header_row = 3
for col_idx, (h_name, col_letter, h_align, num_fmt) in enumerate(headers_lots, start=1):
    cell = ws_lots.cell(row=header_row, column=col_idx, value=h_name)
    cell.font = font_header
    cell.fill = fill_header
    cell.alignment = align_header
    cell.border = border_cell
ws_lots.row_dimensions[header_row].height = 28

start_data_row = 4
for i, lot in enumerate(sample_data):
    r_idx = start_data_row + i
    
    qty = lot.get('qty', 0)
    rate = lot.get('rate', 0)
    lot_name = lot.get('lot_name', '')
    auction = lot.get('auction', '')
    unit = lot.get('unit', 'NO')
    lot_no = lot.get('lot_no', '')
    buyer = lot.get('buyer', '')
    sd_rec = lot.get('sd_received', 0)
    sd_date = lot.get('sd_date', '') or ''
    fp_rec = lot.get('fp_received', 0)
    fp_date = lot.get('fp_date', '') or ''
    inv_no = str(lot.get('invoice_no', '') or '')
    sap_doc = str(lot.get('sap_document_date', '') or '')
    doc_date = lot.get('doc_invoice_date', '') or ''
    
    row_values = [
        qty,                                                                    # A: Qty
        rate,                                                                   # B: Rate
        lot_name,                                                               # C: Lot Name
        auction,                                                                # D: Auction
        unit,                                                                   # E: Unit
        lot_no,                                                                 # F: Lot No
        buyer,                                                                  # G: Buyer
        f"=ROUND(A{r_idx}*B{r_idx}, 2)",                                        # H: Mat Value
        f"=ROUND(H{r_idx}*0.18, 0)",                                            # I: GST 18%
        f"=H{r_idx}+I{r_idx}",                                                  # J: Mat Value + GST
        f"=ROUND(H{r_idx}*0.02, 0)",                                            # K: TCS 2%
        f"=ROUND(H{r_idx}*0.001, 0)",                                           # L: TDS 194O 0.1%
        f"=ROUND(H{r_idx}*0.0225*1.18, 0)",                                     # M: SC MSTC 2.25% + GST
        f"=ROUND(H{r_idx}*0.0225*0.02, 0)",                                     # N: TDS 194H 2%
        f"=ROUND(H{r_idx}*0.0271, 0)",                                          # O: Net SC 2.71%
        f"=O{r_idx}",                                                           # P: Service Charge MSTC
        f'=IF(AND(H{r_idx}>250000, OR(UPPER(TRIM(E{r_idx}))="KG", UPPER(TRIM(E{r_idx}))="MT", UPPER(TRIM(E{r_idx}))="KGS")), 2, 0)', # Q: GST TDS Rate
        f"=ROUND(H{r_idx}*Q{r_idx}/100, 0)",                                    # R: GST TDS Amount
        f"=ROUND(H{r_idx}+I{r_idx}+K{r_idx}-L{r_idx}-O{r_idx}-R{r_idx}, 0)",    # S: Total Receivables
        f"=ROUND(H{r_idx}*0.25, 0)",                                            # T: SD Expected
        sd_rec,                                                                 # U: SD Received
        sd_date,                                                                # V: SD Date
        f"=S{r_idx}-T{r_idx}",                                                  # W: FP Expected
        fp_rec,                                                                 # X: FP Received
        fp_date,                                                                # Y: FP Date
        f'=IF(Y{r_idx}="", IF(AC{r_idx}="Unsettled", ROUND(H{r_idx}*ROUNDUP((DATE(2026,8,31)-DATE(2026,8,24))/7,0)*0.0118, 0), 0), IF(DATE(MID(Y{r_idx},7,4), MID(Y{r_idx},4,2), MID(Y{r_idx},1,2))>DATE(2026,8,24), ROUND(H{r_idx}*ROUNDUP((DATE(MID(Y{r_idx},7,4), MID(Y{r_idx},4,2), MID(Y{r_idx},1,2))-DATE(2026,8,24))/7,0)*0.0118, 0), 0))', # Z: Delayed Payment Charges on Material Value (Col H)
        f"=U{r_idx}+X{r_idx}",                                                  # AA: Total Received
        f"=(S{r_idx}+Z{r_idx})-AA{r_idx}",                                      # AB: Outstanding
        f'=IF(AB{r_idx}<=1, "Settled", "Unsettled")',                           # AC: Settlement Status
        inv_no,                                                                 # AD: Invoice No
        sap_doc,                                                                # AE: SAP Doc No
        doc_date                                                                # AF: Doc Date
    ]
    
    for c_idx, val in enumerate(row_values, start=1):
        cell = ws_lots.cell(row=r_idx, column=c_idx, value=val)
        cell.font = font_data
        cell.alignment = headers_lots[c_idx-1][2]
        cell.number_format = headers_lots[c_idx-1][3]
        cell.border = border_cell
        if i % 2 == 1:
            cell.fill = fill_zebra
            
    ws_lots.row_dimensions[r_idx].height = 20

end_data_row = start_data_row + len(sample_data) - 1
total_row = end_data_row + 1

ws_lots.cell(row=total_row, column=1, value=f"Total ({len(sample_data)} Lots)").font = font_total
ws_lots.cell(row=total_row, column=1).alignment = align_left
ws_lots.cell(row=total_row, column=1).fill = fill_total
ws_lots.cell(row=total_row, column=1).border = border_top_thick

for c_idx in range(2, len(headers_lots) + 1):
    col_let = get_column_letter(c_idx)
    cell = ws_lots.cell(row=total_row, column=c_idx)
    cell.fill = fill_total
    cell.border = border_top_thick
    cell.font = font_total
    cell.alignment = headers_lots[c_idx-1][2]
    cell.number_format = headers_lots[c_idx-1][3]
    
    if col_let in ['A', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'W', 'X', 'Z', 'AA', 'AB']:
        cell.value = f"=SUM({col_let}{start_data_row}:{col_let}{end_data_row})"
    else:
        cell.value = ""

ws_lots.row_dimensions[total_row].height = 24

for col_idx, (h_name, col_letter, h_align, num_fmt) in enumerate(headers_lots, start=1):
    max_len = max(len(h_name), 10)
    if col_letter in ['C', 'G']: max_len = 28
    elif col_letter in ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'W', 'X', 'Z', 'AA', 'AB']: max_len = 16
    elif col_letter in ['V', 'Y', 'AF']: max_len = 13
    elif col_letter in ['AD', 'AE']: max_len = 14
    elif col_letter in ['E', 'F']: max_len = 10
    ws_lots.column_dimensions[col_letter].width = max_len + 3

# -------------------------------------------------------------
# SHEET 3: Pivot Analytics (With Delayed Payment Charges)
# -------------------------------------------------------------
ws_pivot = wb.create_sheet(title="Pivot Analytics")
ws_pivot.views.sheetView[0].showGridLines = True

ws_pivot['A1'] = "ScrapSale Pro — Buyer Pivot Analytics"
ws_pivot['A1'].font = Font(name=FONT_NAME, size=16, bold=True, color='1E1B4B')
ws_pivot['A2'] = "Automated Aggregation with Live Excel SUMIF & COUNTIFS Formulas and Delayed Payment Charges Accruals"
ws_pivot['A2'].font = Font(name=FONT_NAME, size=10.5, italic=True, color='64748B')

headers_pivot = [
    ("Buyer Name", "A", align_left, '@'),
    ("Lots", "B", align_center, '#,##0'),
    ("Material Value", "C", align_right, '₹ #,##0'),
    ("GST (18%)", "D", align_right, '₹ #,##0'),
    ("TCS (2%)", "E", align_right, '₹ #,##0'),
    ("Total Receivables", "F", align_right, '₹ #,##0'),
    ("SD Expected", "G", align_right, '₹ #,##0'),
    ("SD Received", "H", align_right, '₹ #,##0'),
    ("FP Expected", "I", align_right, '₹ #,##0'),
    ("FP Received", "J", align_right, '₹ #,##0'),
    ("Delayed Payment Charges", "K", align_right, '₹ #,##0'),
    ("Total Received", "L", align_right, '₹ #,##0'),
    ("Outstanding", "M", align_right, '₹ #,##0'),
    ("Settlement Breakdown", "N", align_center, '@')
]

p_head_row = 3
for col_idx, (h_name, col_letter, h_align, num_fmt) in enumerate(headers_pivot, start=1):
    cell = ws_pivot.cell(row=p_head_row, column=col_idx, value=h_name)
    cell.font = font_header
    cell.fill = fill_header_accent
    cell.alignment = align_header
    cell.border = border_cell
ws_pivot.row_dimensions[p_head_row].height = 26

unique_buyers = sorted(list(set([lot.get('buyer', '') for lot in sample_data if lot.get('buyer', '')])))

p_start_row = 4
for i, buyer in enumerate(unique_buyers):
    p_r_idx = p_start_row + i
    
    pivot_row_vals = [
        buyer,                                                                                          # A: Buyer Name
        f'=COUNTIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx})',                                            # B: Lots Count
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$H$4:$H$40)',                   # C: Mat Value
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$I$4:$I$40)',                   # D: GST
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$K$4:$K$40)',                   # E: TCS
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$S$4:$S$40)',                   # F: Total Receivables
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$T$4:$T$40)',                   # G: SD Expected
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$U$4:$U$40)',                   # H: SD Received
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$W$4:$W$40)',                   # I: FP Expected
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$X$4:$X$40)',                   # J: FP Received
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$Z$4:$Z$40)',                   # K: Delayed Payment Charges
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$AA$4:$AA$40)',                 # L: Total Received
        f'=SUMIF(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$AB$4:$AB$40)',                 # M: Outstanding
        f'=COUNTIFS(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$AC$4:$AC$40, "Settled") & " S / " & COUNTIFS(\'Lot Details\'!$G$4:$G$40, A{p_r_idx}, \'Lot Details\'!$AC$4:$AC$40, "Unsettled") & " U"' # N: Breakdown
    ]
    
    for c_idx, val in enumerate(pivot_row_vals, start=1):
        cell = ws_pivot.cell(row=p_r_idx, column=c_idx, value=val)
        cell.font = font_data
        cell.alignment = headers_pivot[c_idx-1][2]
        cell.number_format = headers_pivot[c_idx-1][3]
        cell.border = border_cell
        if i % 2 == 1:
            cell.fill = fill_zebra
    ws_pivot.row_dimensions[p_r_idx].height = 20

p_end_row = p_start_row + len(unique_buyers) - 1
p_total_row = p_end_row + 1

ws_pivot.cell(row=p_total_row, column=1, value=f"Total ({len(unique_buyers)} Buyers)").font = font_total
ws_pivot.cell(row=p_total_row, column=1).alignment = align_left
ws_pivot.cell(row=p_total_row, column=1).fill = fill_total
ws_pivot.cell(row=p_total_row, column=1).border = border_top_thick

for c_idx in range(2, len(headers_pivot) + 1):
    col_let = get_column_letter(c_idx)
    cell = ws_pivot.cell(row=p_total_row, column=c_idx)
    cell.fill = fill_total
    cell.border = border_top_thick
    cell.font = font_total
    cell.alignment = headers_pivot[c_idx-1][2]
    cell.number_format = headers_pivot[c_idx-1][3]
    if col_let in ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']:
        cell.value = f"=SUM({col_let}{p_start_row}:{col_let}{p_end_row})"
    elif col_let == 'N':
        cell.value = f'=COUNTIF(\'Lot Details\'!$AC$4:$AC$40, "Settled") & " S / " & COUNTIF(\'Lot Details\'!$AC$4:$AC$40, "Unsettled") & " U"'

ws_pivot.row_dimensions[p_total_row].height = 24

for col_idx, (h_name, col_letter, h_align, num_fmt) in enumerate(headers_pivot, start=1):
    w = 28 if col_letter == 'A' else (20 if col_letter in ['N', 'F', 'C'] else 15)
    ws_pivot.column_dimensions[col_letter].width = w

# -------------------------------------------------------------
# SHEET 4: Buyer Payment Advice Template (With Delayed Payment Charges Line)
# -------------------------------------------------------------
ws_adv = wb.create_sheet(title="Buyer Payment Advice")
ws_adv.views.sheetView[0].showGridLines = True

ws_adv['B2'] = "MAHARASHTRA STATE ELECTRICITY TRANSMISSION CO. LTD. (MSETCL)"
ws_adv['B2'].font = Font(name=FONT_NAME, size=13, bold=True, color='1E1B4B')
ws_adv['B3'] = "BUYER PAYMENT DEMAND ADVICE & MSTC SERVICE CHARGE BREAKUP"
ws_adv['B3'].font = Font(name=FONT_NAME, size=11, bold=True, color='475569')

ws_adv['B5'] = "Buyer Name:"
ws_adv['B5'].font = font_bold
ws_adv['C5'] = "M I SCRAP TRADERS"
ws_adv['C5'].font = Font(name=FONT_NAME, size=11, bold=True, color='1E293B')

ws_adv['B6'] = "Lot Number(s):"
ws_adv['B6'].font = font_bold
ws_adv['C6'] = "Lot 2036 (Bid Sheet: 22005)"

ws_adv['B7'] = "Date of Advice:"
ws_adv['B7'].font = font_bold
ws_adv['C7'] = "31.08.2026"

advice_lines = [
    ("1", "Material Value", "=SUMIFS('Lot Details'!$H$4:$H$40, 'Lot Details'!$G$4:$G$40, C5)", '₹ #,##0'),
    ("2", "GST @ 18% on Material Value", "=ROUND(D10*0.18, 0)", '₹ #,##0'),
    ("3", "TCS @ 2% on Material Value", "=ROUND(D10*0.02, 0)", '₹ #,##0'),
    ("4", "Total Gross Receivable (1 + 2 + 3)", "=D10+D11+D12", '₹ #,##0'),
    ("5", "MSTC Service Charge @ 2.25% of Material Value", "=ROUND(D10*0.0225, 0)", '₹ #,##0'),
    ("6", "GST @ 18% on MSTC Service Charge", "=ROUND(D14*0.18, 0)", '₹ #,##0'),
    ("7", "Total MSTC Service Charge + GST (5 + 6)", "=D14+D15", '₹ #,##0'),
    ("8", "TDS u/s 194(O) @ 0.1% on Material Value", "=ROUND(D10*0.001, 0)", '₹ #,##0'),
    ("9", "TDS u/s 194(H) @ 2% on MSTC Service Charge", "=ROUND(D14*0.02, 0)", '₹ #,##0'),
    ("10", "Net Service Charge to MSTC (7 + 8 - 9)", "=D16+D17-D18", '₹ #,##0'),
    ("11", "Total Amount Before GST TDS (4 - 10)", "=D13-D19", '₹ #,##0'),
    ("12", "GST TDS @ 2% (Material Value > ₹2.5L and Unit is KG/MT)", "=IF(D10>250000, ROUND(D10*0.02, 0), 0)", '₹ #,##0'),
    ("13", "Base Receivables in Cash (11 - 12)", "=D20-D21", '₹ #,##0'),
    ("14", "Security Deposit Expected (25%)", "=ROUND(D10*0.25, 0)", '₹ #,##0'),
    ("15", "Security Deposit Received", "=SUMIFS('Lot Details'!$U$4:$U$40, 'Lot Details'!$G$4:$G$40, C5)", '₹ #,##0'),
    ("16", "Final Payment Expected (FP - after GST TDS) (13 - 14)", "=D22-D23", '₹ #,##0'),
    ("17", "Final Payment Received", "=SUMIFS('Lot Details'!$X$4:$X$40, 'Lot Details'!$G$4:$G$40, C5)", '₹ #,##0'),
    ("18", "Delayed Payment Charges", "=SUMIFS('Lot Details'!$Z$4:$Z$40, 'Lot Details'!$G$4:$G$40, C5)", '₹ #,##0'),
    ("19", "Net Outstanding Balance Due (Including Delayed Payment Charges)", "=(D22+D27)-(D24+D26)", '₹ #,##0')
]

ws_adv['B9'] = "Sr."
ws_adv['C9'] = "Calculation Component & Statutory Breakup"
ws_adv['D9'] = "Amount"
for col_let in ['B', 'C', 'D']:
    ws_adv[f"{col_let}9"].font = font_header
    ws_adv[f"{col_let}9"].fill = fill_header
    ws_adv[f"{col_let}9"].alignment = align_header
    ws_adv[f"{col_let}9"].border = border_cell

for idx, (sr, comp, formula, num_fmt) in enumerate(advice_lines, start=10):
    ws_adv.cell(row=idx, column=2, value=sr).alignment = align_center
    ws_adv.cell(row=idx, column=2).border = border_cell
    ws_adv.cell(row=idx, column=2).font = font_bold
    
    cell_c = ws_adv.cell(row=idx, column=3, value=comp)
    cell_c.alignment = align_left
    cell_c.border = border_cell
    cell_c.font = Font(name=FONT_NAME, size=10, bold=(idx in [13, 20, 22, 25, 27, 28]), color='1E293B')
    
    cell_d = ws_adv.cell(row=idx, column=4, value=formula)
    cell_d.alignment = align_right
    cell_d.border = border_cell
    cell_d.font = Font(name=FONT_NAME, size=10.5, bold=(idx in [13, 20, 22, 25, 27, 28]), color='1E293B')
    cell_d.number_format = num_fmt
    
    if idx in [13, 20, 22, 25, 27, 28]:
        ws_adv.cell(row=idx, column=2).fill = fill_total
        ws_adv.cell(row=idx, column=3).fill = fill_total
        ws_adv.cell(row=idx, column=4).fill = fill_total

ws_adv.column_dimensions['A'].width = 4
ws_adv.column_dimensions['B'].width = 8
ws_adv.column_dimensions['C'].width = 58
ws_adv.column_dimensions['D'].width = 22

# -------------------------------------------------------------
# SHEET 5: VBA Automation Guide
# -------------------------------------------------------------
ws_vba = wb.create_sheet(title='VBA Automation Guide')
ws_vba.views.sheetView[0].showGridLines = True

ws_vba['B2'] = 'ScrapSale Pro — VBA Automation & Macro Setup Guide'
ws_vba['B2'].font = Font(name=FONT_NAME, size=15, bold=True, color='1E1B4B')
ws_vba['B3'] = 'How to Enable Live Macros, Column Toggles, Calendar Date Picker, and Filter Resets in Microsoft Excel'
ws_vba['B3'].font = Font(name=FONT_NAME, size=10.5, italic=True, color='64748B')

steps = [
    ('Step', 'Action', 'Instructions'),
    ('1', 'Open VBA Editor', 'Press Alt + F11 in Excel to open the Visual Basic for Applications window.'),
    ('2', 'Import VBA Module', 'Click File > Import File... and select ScrapSale_Pro_VBA_Suite.bas (or insert a new Module and paste the code).'),
    ('3', 'Enable Date Cell Double-Click', 'Double-click Sheet2 (Lot Details) in Project Explorer and paste the Double-Click event code below.'),
    ('4', 'Save as Macro-Enabled (.xlsm)', 'Click File > Save As > choose Excel Macro-Enabled Workbook (*.xlsm).'),
    ('5', 'Run Any Macro Instantly', 'Press Alt + F8 to select and run any macro (ResetAllFilters, OpenCalendarPicker, ToggleLotColumns, etc.).')
]

r_idx = 5
for c_idx, h in enumerate(steps[0], start=2):
    cell = ws_vba.cell(row=r_idx, column=c_idx, value=h)
    cell.font = font_header
    cell.fill = fill_header
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = border_cell

for row_data in steps[1:]:
    r_idx += 1
    for c_idx, val in enumerate(row_data, start=2):
        cell = ws_vba.cell(row=r_idx, column=c_idx, value=val)
        cell.font = font_bold if c_idx == 2 else font_data
        cell.alignment = Alignment(horizontal='center' if c_idx == 2 else 'left', vertical='center')
        cell.border = border_cell
        if r_idx % 2 == 1:
            cell.fill = fill_zebra

ws_vba['B13'] = 'Sheet Double-Click Event Code (Paste into Sheet2 - Lot Details):'
ws_vba['B13'].font = Font(name=FONT_NAME, size=11, bold=True, color='1E1B4B')

event_code = '''Private Sub Worksheet_BeforeDoubleClick(ByVal Target As Range, Cancel As Boolean)
    ' Automatically opens Calendar Date Picker when double-clicking date columns (V, Y, AF)
    If Not Intersect(Target, Me.Range("V4:V40, Y4:Y40, AF4:AF40")) Is Nothing Then
        Cancel = True
        OpenCalendarPicker
    End If
End Sub'''

ws_vba['B15'] = event_code
ws_vba['B15'].font = Font(name='Consolas', size=9.5, color='0F172A')
ws_vba['B15'].alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
ws_vba.merge_cells('B15:D21')
for r in range(15, 22):
    for col in range(2, 5):
        ws_vba.cell(row=r, column=col).fill = PatternFill(start_color='F8FAFC', end_color='F8FAFC', fill_type='solid')
        ws_vba.cell(row=r, column=col).border = border_cell

ws_vba.column_dimensions['A'].width = 4
ws_vba.column_dimensions['B'].width = 12
ws_vba.column_dimensions['C'].width = 30
ws_vba.column_dimensions['D'].width = 65

# Save deliverables
output_xlsx = '/home/user/ScrapSale_Pro_Cash_Receivables.xlsx'
output_xlsm = '/home/user/ScrapSale_Pro_Cash_Receivables_VBA.xlsm'
wb.save(output_xlsx)
wb.save(output_xlsm)
print(f"Generated {output_xlsx} and {output_xlsm} successfully!")
