const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(600);

  // 1. Verify default state on landing page has NO frozen columns
  const initialFrozenState = await page.evaluate(() => {
    const pivotFrozen = document.querySelectorAll("#pivotTable .frozen").length;
    const detailFrozen = document.querySelectorAll("#detailTableDash .frozen").length;
    return {
      freezePivotField: ui.freezePivotField,
      freezeDetailField: ui.freezeDetailField,
      pivotFrozenCount: pivotFrozen,
      detailFrozenCount: detailFrozen
    };
  });
  console.log("1. Landing Page Default (No Columns Frozen):", initialFrozenState);

  // 2. Right click Buyer header in Buyer Ledger Analytics to open Context Menu
  const pivotBuyerTh = await page.$("#pivotTable thead th");
  const thBox = await pivotBuyerTh.boundingBox();
  await page.mouse.click(thBox.x + thBox.width / 2, thBox.y + thBox.height / 2, { button: "right" });
  await page.waitForTimeout(400);

  const pivotMenuOptions = await page.evaluate(() => {
    const menu = document.getElementById("thCtxMenu");
    if (!menu) return [];
    return Array.from(menu.querySelectorAll(".cm-item .cm-label")).map(el => el.innerText.trim());
  });
  console.log("2. Buyer Ledger Analytics Context Menu Options:", pivotMenuOptions);

  // Click 'Freeze through this column' in Buyer Ledger Analytics
  await page.evaluate(() => {
    const freezeBtn = document.querySelector("#thCtxMenu [data-act='freeze']");
    if (freezeBtn) freezeBtn.click();
  });
  await page.waitForTimeout(400);

  const afterPivotFreeze = await page.evaluate(() => {
    return {
      freezePivotField: ui.freezePivotField,
      frozenThs: Array.from(document.querySelectorAll("#pivotTable thead th.frozen")).map(th => th.innerText.trim())
    };
  });
  console.log("3. After Freezing Buyer in Buyer Ledger Analytics:", afterPivotFreeze);

  // 3. Right-click again in Buyer Ledger Analytics to unfreeze
  await page.mouse.click(thBox.x + thBox.width / 2, thBox.y + thBox.height / 2, { button: "right" });
  await page.waitForTimeout(400);

  const menuAfterFreeze = await page.evaluate(() => {
    const freezeBtn = document.querySelector("#thCtxMenu [data-act='freeze'] .cm-label");
    return freezeBtn ? freezeBtn.innerText.trim() : null;
  });
  console.log("4. Context Menu Button Label when Frozen:", menuAfterFreeze);

  // Click 'Unfreeze columns'
  await page.evaluate(() => {
    const freezeBtn = document.querySelector("#thCtxMenu [data-act='freeze']");
    if (freezeBtn) freezeBtn.click();
  });
  await page.waitForTimeout(400);

  const afterPivotUnfreeze = await page.evaluate(() => {
    return {
      freezePivotField: ui.freezePivotField,
      frozenCount: document.querySelectorAll("#pivotTable .frozen").length
    };
  });
  console.log("5. After Unfreezing Buyer Ledger Analytics:", afterPivotUnfreeze);

  // 4. Test Freeze & Unfreeze in Lot Details
  const detailBuyerTh = await page.$("#detailTableDash thead th[data-field='buyer'], #detailTableDash thead th:nth-child(4)");
  const detailThBox = await detailBuyerTh.boundingBox();
  await page.mouse.click(detailThBox.x + detailThBox.width / 2, detailThBox.y + detailThBox.height / 2, { button: "right" });
  await page.waitForTimeout(400);

  // Click Freeze in Lot Details
  await page.evaluate(() => {
    const freezeBtn = document.querySelector("#thCtxMenu [data-act='freeze']");
    if (freezeBtn) freezeBtn.click();
  });
  await page.waitForTimeout(400);

  const afterDetailFreeze = await page.evaluate(() => {
    return {
      freezeDetailField: ui.freezeDetailField,
      frozenThs: Array.from(document.querySelectorAll("#detailTableDash thead th.frozen")).map(th => th.innerText.trim())
    };
  });
  console.log("6. After Freezing through Buyer in Lot Details:", afterDetailFreeze);

  // Unfreeze Lot Details via column menu
  await page.mouse.click(detailThBox.x + detailThBox.width / 2, detailThBox.y + detailThBox.height / 2, { button: "right" });
  await page.waitForTimeout(400);
  await page.evaluate(() => {
    const freezeBtn = document.querySelector("#thCtxMenu [data-act='freeze']");
    if (freezeBtn) freezeBtn.click();
  });
  await page.waitForTimeout(400);

  const afterDetailUnfreeze = await page.evaluate(() => {
    return {
      freezeDetailField: ui.freezeDetailField,
      frozenCount: document.querySelectorAll("#detailTableDash .frozen").length
    };
  });
  console.log("7. After Unfreezing Lot Details:", afterDetailUnfreeze);

  await page.screenshot({ path: "/home/user/unfreeze_options_verified_proof.png" });

  await browser.close();
  console.log("All unfreeze and landing page default tests passed successfully!");
})();
