# Clean replacement script for advice suite

wa_func = r"""function generateWhatsAppAdviceText(lotsList, buyerTitle) {
  var isMulti = lotsList.length > 1;
  var bName = buyerTitle || (lotsList[0] ? lotsList[0].buyer : 'Valued Buyer');
  var b = computeAdviceBreakdown(lotsList);
  
  var lotDetailsText = '';
  if (!isMulti && lotsList[0]) {
    var r = lotsList[0];
    lotDetailsText = 
      '📋 *Lot No.:* ' + r.lot_no + ' | *Bid Sheet:* ' + (r.auction || '—') + '\n' +
      '📦 *Material:* ' + r.lot_name + '\n' +
      '⚖️ *Quantity:* ' + numFmt(r.qty) + ' ' + (r.unit || 'NO') + ' @ ₹ ' + inr(r.rate) + ' / ' + (r.unit || 'NO') + '\n';
  } else {
    lotDetailsText = '📊 *Total Lots:* ' + lotsList.length + ' Lot(s) (' + lotsList.map(function(x){ return '#' + x.lot_no; }).join(', ') + ')\n';
  }

  var sdRecLine = '   • SD Received: ₹ ' + inr(b.totSdRec) + (b.totSdRec > 0 && b.sdDatesStr ? (' _(Rec Date: ' + b.sdDatesStr + ')') : '') + '\n';
  var fpRecLine = '   • FP Received: ₹ ' + inr(b.totFpRec) + (b.totFpRec > 0 && b.fpDatesStr ? (' _(Rec Date: ' + b.fpDatesStr + ')') : '') + '\n';
  var lateFeeLine = '3️⃣ *Late Fee @ 1%/wk (from 24.08.2026):*\n' +
    '   • Delay Basis: 1% per week or part thereof after 24.08.2026\n' +
    '   • *Late Fee Payable:* ₹ ' + inr(b.totLateFee) + (b.totLateFee > 0 ? '  ⏳ [DUE]' : '  ✅ [NIL / ON TIME]') + '\n';

  var msg = 
    '🏛️ *MSETCL LIMITED — PAYMENT DEMAND ADVICE*\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '👤 *Buyer Name:* ' + bName + '\n' +
    lotDetailsText +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '💰 *VALUATION & STATUTORY CHARGES:*\n' +
    '• Material Value: ₹ ' + inr(b.totMat) + '\n' +
    '• GST @ 18%: ₹ ' + inr(b.totGst) + '\n' +
    '• Material Value + GST: ₹ ' + inr(b.totMatGst) + '\n' +
    '• TCS @ 2% of Material Value: ₹ ' + inr(b.totTcs) + '\n' +
    '• Gross Consideration (Mat. Value + GST + TCS): ₹ ' + inr(b.totGrossValuation) + '\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '⚡ *MSTC SERVICE CHARGE BREAKUP:*\n' +
    '1️⃣ Service Charge to MSTC (2.25% of Mat. Value): ₹ ' + inr(b.totScBasic) + '\n' +
    '2️⃣ GST @ 18% on Service Charge: ₹ ' + inr(b.totScGst) + '\n' +
    '3️⃣ Service Charge + GST (2.655%): ₹ ' + inr(b.totScWithGst) + '\n' +
    '4️⃣ TDS u/s 194(O) (0.1% of Mat. Value): ₹ ' + inr(b.totTds194o) + '\n' +
    '5️⃣ TDS u/s 194(H) (2% of Service Charge): ₹ ' + inr(b.totTds194h) + '\n' +
    '6️⃣ *Net Service Charge to MSTC (3+4-5 = 2.71%):* ₹ ' + inr(b.totSc271) + '\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '⚡ *TOTAL BEFORE GST TDS:* ₹ ' + inr(b.totBeforeGstTds) + '\n' +
    '• Less GST TDS Deductions: ₹ ' + inr(b.totGstTds) + '\n' +
    '💵 *TOTAL CASH RECEIVABLE (BASE):* ₹ ' + inr(b.totRec) + '\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '📅 *PAYMENT SCHEDULE & STATUS:*\n' +
    '1️⃣ *Security Deposit (SD - 25%):*\n' +
    '   • SD Expected: ₹ ' + inr(b.totSdExp) + '\n' +
    sdRecLine +
    '   • *SD Balance Due:* ₹ ' + inr(b.totSdDue) + (b.totSdDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\n\n' +
    '2️⃣ *Final Payment (FP - after GST TDS):*\n' +
    '   • FP Expected: ₹ ' + inr(b.totFpExp) + '\n' +
    fpRecLine +
    '   • *FP Balance Due:* ₹ ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\n\n' +
    lateFeeLine +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '📥 *Total Received to Date:* ₹ ' + inr(b.totReceived) + '\n' +
    '🔴 *NET AMOUNT PAYABLE NOW (INCL. LATE FEE):* ₹ ' + inr(b.totOut) + '\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '🏦 *Remittance Instructions:*\n' +
    'Please transfer payment via RTGS/NEFT to MSETCL designated bank account with reference to the Buyer Name & Lot No.\n' +
    'Thank you for your business.';

  return msg;
}"""

email_func = r"""function generateEmailAdviceText(lotsList, buyerTitle) {
  var isMulti = lotsList.length > 1;
  var bName = buyerTitle || (lotsList[0] ? lotsList[0].buyer : 'Valued Buyer');
  var b = computeAdviceBreakdown(lotsList);

  var sdRecEmail = '- Received     : Rs. ' + inr(b.totSdRec) + (b.totSdRec > 0 && b.sdDatesStr ? (' (Date: ' + b.sdDatesStr + ')') : '');
  var fpRecEmail = '- Received     : Rs. ' + inr(b.totFpRec) + (b.totFpRec > 0 && b.fpDatesStr ? (' (Date: ' + b.fpDatesStr + ')') : '');

  var txt = 
    'PAYMENT DEMAND ADVICE — MSETCL LIMITED\n' +
    '======================================================\n' +
    'To: ' + bName + '\n' +
    'Scope: ' + (isMulti ? (lotsList.length + ' Lots Consolidated') : ('Lot No. ' + lotsList[0].lot_no + ' (' + (lotsList[0].lot_name || 'Material') + ')')) + '\n\n' +
    'VALUATION & STATUTORY CHARGES BREAKDOWN:\n' +
    '------------------------------------------------------\n' +
    'Material Value (Qty x Rate)        : Rs. ' + inr(b.totMat) + '\n' +
    'GST @ 18%                          : Rs. ' + inr(b.totGst) + '\n' +
    'Material Value + GST               : Rs. ' + inr(b.totMatGst) + '\n' +
    'TCS @ 2% of Material Value         : Rs. ' + inr(b.totTcs) + '\n' +
    'Gross Material Consideration       : Rs. ' + inr(b.totGrossValuation) + '\n\n' +
    'MSTC SERVICE CHARGE BREAKUP:\n' +
    '------------------------------------------------------\n' +
    '1. Service Charge to MSTC (2.25%)  : Rs. ' + inr(b.totScBasic) + '\n' +
    '2. GST @ 18% on Service Charge     : Rs. ' + inr(b.totScGst) + '\n' +
    '3. Service Charge + GST (2.655%)   : Rs. ' + inr(b.totScWithGst) + '\n' +
    '4. TDS u/s 194(O) (0.1% of Mat)    : Rs. ' + inr(b.totTds194o) + '\n' +
    '5. TDS u/s 194(H) (2% of SC)       : Rs. ' + inr(b.totTds194h) + '\n' +
    '6. Net SC to MSTC (3+4-5 = 2.71%)  : Rs. ' + inr(b.totSc271) + '\n' +
    '------------------------------------------------------\n' +
    'TOTAL BEFORE GST TDS               : Rs. ' + inr(b.totBeforeGstTds) + '\n' +
    'Less: GST TDS Deductions           : Rs. ' + inr(b.totGstTds) + '\n' +
    '------------------------------------------------------\n' +
    'TOTAL CASH RECEIVABLE (BASE)       : Rs. ' + inr(b.totRec) + '\n' +
    '======================================================\n\n' +
    'PAYMENT SCHEDULE & STATUS:\n' +
    '1. Security Deposit (SD - 25%):\n' +
    '   - Expected : Rs. ' + inr(b.totSdExp) + '\n' +
    '   ' + sdRecEmail + '\n' +
    '   - Balance Due : Rs. ' + inr(b.totSdDue) + (b.totSdDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\n\n' +
    '2. Final Payment (FP - after GST TDS):\n' +
    '   - Expected : Rs. ' + inr(b.totFpExp) + '\n' +
    '   ' + fpRecEmail + '\n' +
    '   - Balance Due : Rs. ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\n\n' +
    '3. Late Fee @ 1% per week (from 24.08.2026):\n' +
    '   - Accrued Late Fee : Rs. ' + inr(b.totLateFee) + (b.totLateFee > 0 ? ' (PAYABLE)' : ' (NIL / ON TIME)') + '\n\n' +
    '------------------------------------------------------\n' +
    'Total Amount Received to Date      : Rs. ' + inr(b.totReceived) + '\n' +
    'NET OUTSTANDING AMOUNT PAYABLE     : Rs. ' + inr(b.totOut) + '\n' +
    '======================================================\n' +
    'Please transfer payment via RTGS/NEFT to MSETCL designated account.\n' +
    'MSETCL LIMITED — Cash Receivables SaaS Platform';

  return txt;
}"""

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find the section from "function generateWhatsAppAdviceText" to "function printPaymentAdvice"
    idx_wa = content.find("function generateWhatsAppAdviceText")
    idx_print = content.find("function printPaymentAdvice")

    if idx_wa != -1 and idx_print != -1:
        content = content[:idx_wa] + wa_func + "\n\n" + email_func + "\n\n" + content[idx_print:]
    else:
        print(f"Error finding indices in {fpath}")

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"Fixed string escapes in {fpath} successfully!")
