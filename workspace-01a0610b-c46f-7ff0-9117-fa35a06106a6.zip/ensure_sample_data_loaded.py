import re

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update LS_KEY to scrapsale_pro_v8
text = re.sub(r"var LS_KEY = 'scrapsale_pro_v\d+';", "var LS_KEY = 'scrapsale_pro_v8';", text)

# 2. Update initialization logic to ensure lots is never empty on launch
old_init_load = """  var loaded = loadState();
  if (!loaded) lots = SAMPLE_DATA.map(normalizeLot);"""

new_init_load = """  var loaded = loadState();
  if (!loaded || !lots || !lots.length) {
    lots = SAMPLE_DATA.map(normalizeLot);
    ui.groupBy = 'buyer';
    ui.auction = 'all';
    ui.settlement = 'all';
    ui.dashSearch = '';
    ui.detailSearch = '';
    ui.colFilters = {};
    selectedGroup = null;
  }"""

if old_init_load in text:
    text = text.replace(old_init_load, new_init_load)
    print("Updated initialization load logic")
else:
    print("Warning: old_init_load not found")

# 3. Add window.restoreSampleData global function
restore_fn_code = """
window.restoreSampleData = function () {
  pushHistory();
  lots = SAMPLE_DATA.map(normalizeLot);
  ui.groupBy = 'buyer';
  ui.auction = 'all';
  ui.settlement = 'all';
  ui.dashSearch = '';
  ui.detailSearch = '';
  ui.colFilters = {};
  selectedGroup = null;
  clearGridSelection();
  afterStateChange('Loaded all 37 original lots successfully');
  showToast('All 37 lots loaded into workspace', 'ok');
};
"""

if 'window.restoreSampleData' not in text:
    target_pos = text.find("function init() {")
    if target_pos != -1:
        text = text[:target_pos] + restore_fn_code + '\n' + text[target_pos:]
        print("Added window.restoreSampleData function")

# 4. Add Topbar "Load Data" button
old_top_actions = """        <div class="top-actions">
          <button class="btn hand-tool-btn" id="handToolBtn" type="button" title="Toggle Hand Pan Tool (H / Space) — Drag and glide across tables smoothly">"""

new_top_actions = """        <div class="top-actions">
          <button class="btn" id="topLoadSampleBtn" type="button" title="Load / Restore all 37 lots (Auctions 21977–21980)" style="font-weight:600"><span style="margin-right:4px">📥</span>Load Data (37 Lots)</button>
          <button class="btn hand-tool-btn" id="handToolBtn" type="button" title="Toggle Hand Pan Tool (H / Space) — Drag and glide across tables smoothly">"""

if old_top_actions in text:
    text = text.replace(old_top_actions, new_top_actions)
    print("Added Topbar Load Data button")

# 5. Connect topLoadSampleBtn in init
old_restore_btn = """  document.getElementById('restoreSample').addEventListener('click', function () {
    confirmModal('Restore sample data', 'Replace the current workspace with the original sample data (37 lots)? Undoable.', 'Restore', function () {
      pushHistory();
      lots = SAMPLE_DATA.map(normalizeLot);
      selectedGroup = null;
      afterStateChange('Sample data restored (37 lots)');
    });
  });"""

new_restore_btn = """  var topLoadBtn = document.getElementById('topLoadSampleBtn');
  if (topLoadBtn) {
    topLoadBtn.addEventListener('click', function () {
      window.restoreSampleData();
    });
  }
  document.getElementById('restoreSample').addEventListener('click', function () {
    confirmModal('Restore sample data', 'Replace the current workspace with the original sample data (37 lots)? Undoable.', 'Restore', function () {
      window.restoreSampleData();
    });
  });"""

if old_restore_btn in text:
    text = text.replace(old_restore_btn, new_restore_btn)
    print("Connected topLoadSampleBtn listener")

# 6. Add empty state helpers in renderDetailInto and renderPivot
old_detail_empty = """  var tbody = table.querySelector('tbody');
  tbody.innerHTML = rows.map(function (r) {"""

new_detail_empty = """  var tbody = table.querySelector('tbody');
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="' + (cols.length + 1) + '" style="text-align:center;padding:32px 16px;color:var(--dim)">' +
      (lots.length === 0
        ? 'No lots loaded in workspace. <button type="button" class="btn primary" onclick="restoreSampleData()" style="margin-left:8px;padding:5px 14px">📥 Load Sample Data (37 Lots)</button>'
        : 'No lots matching active filters. <button type="button" class="btn" onclick="resetDetailFilters()" style="margin-left:8px;padding:4px 10px">↺ Clear Filters</button>') +
    '</td></tr>';
    var tfoot = table.querySelector('tfoot');
    if (tfoot) tfoot.innerHTML = '';
    return;
  }
  tbody.innerHTML = rows.map(function (r) {"""

if old_detail_empty in text:
    text = text.replace(old_detail_empty, new_detail_empty)
    print("Added empty state handling in renderDetailInto")

# Save to all copies
for path in [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html'
]:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)

print("Saved all 3 files successfully.")
