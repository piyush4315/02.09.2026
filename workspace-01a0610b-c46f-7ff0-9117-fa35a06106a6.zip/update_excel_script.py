with open('/home/user/generate_all_excel_with_late_fee.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Replace headers and labels
code = code.replace('("Late Fee @ 1%", "Z", align_right, \'₹ #,##0\')', '("Late Fee", "Z", align_right, \'₹ #,##0\')')
code = code.replace('("Late Fee @ 1%", "K", align_right, \'₹ #,##0\')', '("Late Fee", "K", align_right, \'₹ #,##0\')')
code = code.replace('("18", "Late Fee @ 1% per week (from 24th Aug 2026)",', '("18", "Late Fee",')
code = code.replace('with Late Fee @ 1% / week from 24th Aug 2026', 'with Late Fee from 24th Aug 2026')
code = code.replace('with Late Fee @ 1% per week from 24th Aug 2026', 'with Late Fee from 24th Aug 2026')
code = code.replace('SHEET 2: Lot Details (With Late Fee @ 1% & Live Excel Formulas)', 'SHEET 2: Lot Details (With Late Fee & Live Excel Formulas)')
code = code.replace('Late Fee @ 1% on Material Value (Col H)', 'Late Fee on Material Value (Col H)')

with open('/home/user/generate_all_excel_with_late_fee.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Updated generate_all_excel_with_late_fee.py")
