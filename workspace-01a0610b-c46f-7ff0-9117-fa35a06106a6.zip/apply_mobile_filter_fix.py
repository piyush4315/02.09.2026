import re

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add CSS rules
css_block = '''
/* ── COLUMN FILTER BUTTONS & MOBILE FILTER ENHANCEMENTS ── */
.th-wrap {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  justify-content: flex-end;
  max-width: 100%;
}
th.left .th-wrap, th.center .th-wrap {
  justify-content: inherit;
}
.th-filt-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  margin-left: 2px;
  border: 1px solid transparent;
  border-radius: 4px;
  background: transparent;
  color: var(--dim, #94a3b8);
  cursor: pointer;
  transition: all 0.15s ease;
  flex: 0 0 auto;
  vertical-align: middle;
  touch-action: manipulation;
  outline: none;
}
.th-filt-btn:hover {
  background: rgba(0, 245, 255, 0.15);
  color: var(--cyan, #00f5ff);
  border-color: rgba(0, 245, 255, 0.35);
}
.th-filt-btn.active, thead th.has-filter .th-filt-btn {
  background: rgba(0, 245, 255, 0.25) !important;
  color: #00f5ff !important;
  border-color: rgba(0, 245, 255, 0.7) !important;
  box-shadow: 0 0 8px rgba(0, 245, 255, 0.4) !important;
}
[data-theme="light"] .th-filt-btn {
  color: #94a3b8;
}
[data-theme="light"] .th-filt-btn:hover {
  background: #eff6ff;
  color: #2563eb;
  border-color: #93c5fd;
}
[data-theme="light"] .th-filt-btn.active, [data-theme="light"] thead th.has-filter .th-filt-btn {
  background: #eff6ff !important;
  color: #1d4ed8 !important;
  border-color: #3b82f6 !important;
  box-shadow: 0 0 0 1px #3b82f6 !important;
}

@media (max-width: 768px), (pointer: coarse) {
  .th-filt-btn {
    width: 22px;
    height: 22px;
    margin-left: 3px;
    opacity: 0.95;
  }
}

.col-menu-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(3px);
  -webkit-backdrop-filter: blur(3px);
  z-index: 9990;
  display: none;
  animation: fadeIn 0.18s ease;
}
[data-theme="light"] .col-menu-backdrop {
  background: rgba(15, 23, 42, 0.45);
}

.col-menu.mobile-sheet {
  position: fixed !important;
  left: 10px !important;
  right: 10px !important;
  bottom: 12px !important;
  top: auto !important;
  width: auto !important;
  max-width: 460px !important;
  margin: 0 auto !important;
  max-height: 85vh !important;
  border-radius: 16px !important;
  box-shadow: 0 24px 64px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.15) !important;
  animation: sheetSlideUp 0.22s cubic-bezier(0.16, 1, 0.3, 1) !important;
  z-index: 9999 !important;
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column !important;
}
@keyframes sheetSlideUp {
  from { transform: translateY(100%); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}
[data-theme="light"] .col-menu.mobile-sheet {
  background: #ffffff !important;
  border: 1px solid #cbd5e1 !important;
  box-shadow: 0 24px 60px rgba(15, 23, 42, 0.25), 0 0 0 1px #e2e8f0 !important;
}
.col-menu.mobile-sheet .xl-values {
  max-height: 220px !important;
  -webkit-overflow-scrolling: touch !important;
}
.col-menu.mobile-sheet .xl-value {
  padding: 8px 10px !important;
  min-height: 38px !important;
  font-size: 13px !important;
}
.col-menu.mobile-sheet .xl-value input[type="checkbox"] {
  width: 18px !important;
  height: 18px !important;
}
.col-menu.mobile-sheet .xl-filter-foot {
  padding: 10px 6px 6px !important;
}
.col-menu.mobile-sheet .xl-filter-foot .btn {
  padding: 8px 14px !important;
  font-size: 12.5px !important;
}

.active-filters-bar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
  padding: 7px 10px;
  margin-bottom: 10px;
  background: rgba(0, 245, 255, 0.06);
  border: 1px solid rgba(0, 245, 255, 0.25);
  border-radius: 8px;
  font-size: 11.5px;
  color: var(--text);
  animation: fadeIn 0.2s ease;
}
[data-theme="light"] .active-filters-bar {
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  color: #1e40af;
}
.af-label {
  font-weight: 700;
  font-size: 10.5px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--cyan, #00f5ff);
  margin-right: 2px;
}
[data-theme="light"] .af-label {
  color: #1d4ed8;
}
.af-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.16);
  padding: 3px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 500;
  line-height: 1.3;
}
[data-theme="light"] .af-chip {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #0f172a;
}
.af-chip-del {
  border: none;
  background: transparent;
  color: #ff6b6b;
  cursor: pointer;
  font-weight: bold;
  font-size: 12px;
  padding: 0 3px;
  border-radius: 3px;
  line-height: 1;
}
.af-chip-del:hover {
  background: rgba(255, 107, 107, 0.2);
}
.af-clear-all {
  margin-left: auto;
  border: 1px solid rgba(255, 107, 107, 0.35);
  background: rgba(255, 107, 107, 0.1);
  color: #ff6b6b;
  border-radius: 6px;
  padding: 3px 9px;
  font-size: 10.5px;
  font-weight: 600;
  cursor: pointer;
}
.af-clear-all:hover {
  background: rgba(255, 107, 107, 0.22);
}
.filter-count-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 17px;
  height: 17px;
  padding: 0 5px;
  border-radius: 10px;
  background: var(--cyan, #00f5ff);
  color: #0d0d24;
  font-size: 10px;
  font-weight: 800;
  margin-left: 4px;
  vertical-align: middle;
}
[data-theme="light"] .filter-count-badge {
  background: #2563eb;
  color: #ffffff;
}

.col-filter-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 8px;
  margin-top: 10px;
  max-height: 55vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  padding-right: 4px;
}
.col-filter-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 9px 12px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s ease;
  text-align: left;
  font-family: inherit;
  color: var(--text);
  width: 100%;
}
.col-filter-card:hover {
  background: rgba(0, 245, 255, 0.08);
  border-color: rgba(0, 245, 255, 0.35);
}
.col-filter-card.filtered {
  background: rgba(0, 245, 255, 0.12);
  border-color: rgba(0, 245, 255, 0.5);
}
[data-theme="light"] .col-filter-card {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
}
[data-theme="light"] .col-filter-card:hover {
  background: #eff6ff;
  border-color: #93c5fd;
}
[data-theme="light"] .col-filter-card.filtered {
  background: #eff6ff;
  border-color: #3b82f6;
}
.col-filter-card-name {
  font-size: 12px;
  font-weight: 600;
}
.col-filter-card-status {
  font-size: 10.5px;
  color: var(--dim, #94a3b8);
}
.col-filter-card.filtered .col-filter-card-status {
  color: var(--cyan, #00f5ff);
  font-weight: 700;
}
[data-theme="light"] .col-filter-card.filtered .col-filter-card-status {
  color: #1d4ed8;
}
'''

# Insert CSS before </style>
if '/* ── COLUMN FILTER BUTTONS & MOBILE FILTER ENHANCEMENTS ── */' not in text:
    text = text.replace('</style>', css_block + '\n</style>', 1)

# 2. Update HTML toolbars to include Filter Buttons & Active Filter Bars
old_pivot_controls = '''            <button class="btn" id="resetPivotFiltersBtn" type="button" title="Reset all Pivot Analytics filters, search, and column filters">↺ Reset Filters</button>
            <div class="spacer"></div>
            <input type="text" id="search" placeholder="Search buyer, lot no, material..."/>
          </div>'''

new_pivot_controls = '''            <button class="btn" id="pivotColFilterBtn" type="button" title="Filter columns and values" style="color:var(--cyan);border-color:rgba(0,245,255,0.35);background:rgba(0,245,255,0.08)"><svg viewBox="0 0 16 16" width="12" height="12" style="vertical-align:-1px;margin-right:4px;fill:currentColor"><path d="M1.5 2.5h13l-5 6v5.5l-3-2V8.5z"/></svg>Filters <span id="pivotFilterCountBadge" class="filter-count-badge" style="display:none">0</span></button>
            <button class="btn" id="resetPivotFiltersBtn" type="button" title="Reset all Pivot Analytics filters, search, and column filters">↺ Reset Filters</button>
            <div class="spacer"></div>
            <input type="text" id="search" placeholder="Search buyer, lot no, material..."/>
          </div>
          <div id="pivotActiveFiltersBar" class="active-filters-bar" style="display:none"></div>'''

if old_pivot_controls in text:
    text = text.replace(old_pivot_controls, new_pivot_controls)
else:
    print("Warning: old_pivot_controls not found directly")

old_detail_controls = '''              <input type="text" id="detailSearch" placeholder="Search this table..." style="min-width:170px"/>
              <button class="btn" id="resetDetailFiltersBtn" type="button" title="Reset all Lot Details search, column filters, and selections">↺ Reset Filters</button>'''

new_detail_controls = '''              <input type="text" id="detailSearch" placeholder="Search this table..." style="min-width:170px"/>
              <button class="btn" id="detailColFilterBtn" type="button" title="Filter columns and values" style="color:var(--cyan);border-color:rgba(0,245,255,0.35);background:rgba(0,245,255,0.08)"><svg viewBox="0 0 16 16" width="12" height="12" style="vertical-align:-1px;margin-right:4px;fill:currentColor"><path d="M1.5 2.5h13l-5 6v5.5l-3-2V8.5z"/></svg>Filters <span id="detailFilterCountBadge" class="filter-count-badge" style="display:none">0</span></button>
              <button class="btn" id="resetDetailFiltersBtn" type="button" title="Reset all Lot Details search, column filters, and selections">↺ Reset Filters</button>'''

if old_detail_controls in text:
    text = text.replace(old_detail_controls, new_detail_controls)
    # Add detailActiveFiltersBar
    text = text.replace('<div class="col-toggles" id="dashColToggles"></div>', '<div id="detailActiveFiltersBar" class="active-filters-bar" style="display:none"></div>\n          <div class="col-toggles" id="dashColToggles"></div>')
else:
    print("Warning: old_detail_controls not found directly")

# 3. Update thPickerHtml to include .th-filt-btn with filter status
old_thPicker = '''function thPickerHtml(field, table, place, layoutKind) {
  var isSorted = sortState.table === table && sortState.key === field;
  var arrow = isSorted ? (sortState.dir === 1 ? ' ▲' : ' ▼') : '';
  var kind = fieldKind(field);
  var isCenter = (kind === 'center' || kind === 'date' || kind === 'date-edit' || kind === 'status' || field === 'lot_no' || field === 'unit' || field === 'invoice_no' || field === 'sap_document_date' || field === 'sd_date' || field === 'fp_date' || field === 'doc_invoice_date' || field === 'auction' || field === 'settlement_status');
  var cls = isCenter ? 'center' : ((kind === 'left') ? 'left' : '');
  var dragAttr = (layoutKind === 'detail' || layoutKind === 'pivotLot' || layoutKind === 'pivotMetric') ? ' draggable="true"' : '';
  return '<th class="' + cls + '"' + dragAttr + ' data-field="' + escHtml(field) + '" data-table="' + table + '" data-place="' + place + '" data-layout="' + layoutKind + '">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(fieldLabel(field)) + '</span>' +
      (arrow ? '<span class="arrow">' + arrow + '</span>' : '') +
    '</span></th>';
}'''

new_thPicker = '''function thPickerHtml(field, table, place, layoutKind) {
  var isSorted = sortState.table === table && sortState.key === field;
  var arrow = isSorted ? (sortState.dir === 1 ? ' ▲' : ' ▼') : '';
  var kind = fieldKind(field);
  var isCenter = (kind === 'center' || kind === 'date' || kind === 'date-edit' || kind === 'status' || field === 'lot_no' || field === 'unit' || field === 'invoice_no' || field === 'sap_document_date' || field === 'sd_date' || field === 'fp_date' || field === 'doc_invoice_date' || field === 'auction' || field === 'settlement_status');
  var cls = isCenter ? 'center' : ((kind === 'left') ? 'left' : '');
  var dragAttr = (layoutKind === 'detail' || layoutKind === 'pivotLot' || layoutKind === 'pivotMetric') ? ' draggable="true"' : '';
  var filterKey = (table === 'pivot' && ui.groupBy !== 'default' && field !== ui.groupBy && field !== 'key' && field !== 'settlement_status' && field !== 'settled_breakdown')
    ? ('pivot_' + field)
    : (field === 'key' ? ui.groupBy : field);
  var hasFilter = colFilterOn(filterKey);
  var filterBtnHtml = '<button type="button" class="th-filt-btn' + (hasFilter ? ' active' : '') + '" data-filter-field="' + escHtml(field) + '" data-filter-table="' + table + '" title="' + (hasFilter ? 'Filter active — tap to edit or clear' : 'Filter / Column options') + '" aria-label="Filter ' + escHtml(fieldLabel(field)) + '">' +
    '<svg class="filt-svg" viewBox="0 0 16 16" width="11" height="11"><path fill="currentColor" d="M1.5 2.5h13l-5 6v5.5l-3-2V8.5z"/></svg>' +
  '</button>';

  return '<th class="' + cls + (hasFilter ? ' has-filter' : '') + '"' + dragAttr + ' data-field="' + escHtml(field) + '" data-table="' + table + '" data-place="' + place + '" data-layout="' + layoutKind + '">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(fieldLabel(field)) + '</span>' +
      (arrow ? '<span class="arrow">' + arrow + '</span>' : '') +
      filterBtnHtml +
    '</span></th>';
}'''

if old_thPicker in text:
    text = text.replace(old_thPicker, new_thPicker)
else:
    print("Warning: old_thPicker not matched exactly")

# 4. Update buyer grouped thead in renderPivot
old_pivot_buyer_th = '''  thead.innerHTML = '<tr><th class="' + (isBuyerGroup ? 'left th-buyer' : 'left') + '" data-field="' + escHtml(groupKey) + '"' + (isBuyerGroup ? ' data-group="buyer"' : '') + ' data-table="pivot">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(groupLabel) + '</span>' +
      (sortState.table === 'pivot' && sortState.key === 'key' ? '<span class="arrow">' + (sortState.dir === 1 ? ' ▲' : ' ▼') + '</span>' : '') +
    '</span>' +
    '</th>' + metricKeys.map(function (f, i) { return thPickerHtml(f, 'pivot', i, 'pivotMetric'); }).join('') + '</tr>';'''

new_pivot_buyer_th = '''  var groupFilterKey = (groupKey === 'key' ? ui.groupBy : groupKey);
  var groupHasFilter = colFilterOn(groupFilterKey);
  var groupFilterBtnHtml = '<button type="button" class="th-filt-btn' + (groupHasFilter ? ' active' : '') + '" data-filter-field="' + escHtml(groupKey) + '" data-filter-table="pivot" title="' + (groupHasFilter ? 'Filter active' : 'Filter / Column options') + '" aria-label="Filter group">' +
    '<svg class="filt-svg" viewBox="0 0 16 16" width="11" height="11"><path fill="currentColor" d="M1.5 2.5h13l-5 6v5.5l-3-2V8.5z"/></svg>' +
  '</button>';

  thead.innerHTML = '<tr><th class="' + (isBuyerGroup ? 'left th-buyer' : 'left') + (groupHasFilter ? ' has-filter' : '') + '" data-field="' + escHtml(groupKey) + '"' + (isBuyerGroup ? ' data-group="buyer"' : '') + ' data-table="pivot">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(groupLabel) + '</span>' +
      (sortState.table === 'pivot' && sortState.key === 'key' ? '<span class="arrow">' + (sortState.dir === 1 ? ' ▲' : ' ▼') + '</span>' : '') +
      groupFilterBtnHtml +
    '</span>' +
    '</th>' + metricKeys.map(function (f, i) { return thPickerHtml(f, 'pivot', i, 'pivotMetric'); }).join('') + '</tr>';'''

if old_pivot_buyer_th in text:
    text = text.replace(old_pivot_buyer_th, new_pivot_buyer_th)
else:
    print("Warning: old_pivot_buyer_th not matched directly")

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'w', encoding='utf-8') as f:
    f.write(text)

print("Step 1 done. Output length:", len(text))
