import re

def process_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Add CSS for Mobile View Mode
    mobile_css = """
/* ── MOBILE / DESKTOP VIEW TOGGLE ── */
.view-mode-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
.view-mode-btn .view-mode-icon {
  font-size: 13px;
  display: inline-block;
  transition: transform 0.2s ease;
}
.view-mode-btn:hover .view-mode-icon {
  transform: scale(1.15);
}
[data-view-mode="mobile"] .view-mode-btn {
  background: rgba(124, 58, 237, 0.2) !important;
  border-color: rgba(124, 58, 237, 0.6) !important;
  color: #c4b5fd !important;
  box-shadow: 0 0 12px rgba(124, 58, 237, 0.3) !important;
}
[data-theme="light"][data-view-mode="mobile"] .view-mode-btn {
  background: #eff6ff !important;
  border-color: #2563eb !important;
  color: #1d4ed8 !important;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.18) !important;
}

/* ── MOBILE VIEW OPTIMIZED STYLES (When data-view-mode="mobile") ── */
[data-view-mode="mobile"] #app {
  max-width: 480px;
  margin: 0 auto;
  min-height: 100vh;
  box-shadow: 0 0 60px rgba(0, 0, 0, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.08);
  border-right: 1px solid rgba(255, 255, 255, 0.08);
  transition: max-width 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}
[data-theme="light"][data-view-mode="mobile"] #app {
  border-left: 1px solid #cbd5e1;
  border-right: 1px solid #cbd5e1;
  box-shadow: 0 0 40px rgba(15, 23, 42, 0.12);
}

[data-view-mode="mobile"] .hero {
  padding: 22px 14px 10px;
}
[data-view-mode="mobile"] .hero h1 {
  font-size: 20px;
  line-height: 1.25;
}
[data-view-mode="mobile"] .hero-sub {
  font-size: 11.5px;
}
[data-view-mode="mobile"] .badges {
  gap: 5px;
  margin-top: 8px;
  justify-content: center;
}
[data-view-mode="mobile"] .badges .badge {
  font-size: 9px;
  padding: 2px 6px;
}

[data-view-mode="mobile"] .cards,
[data-view-mode="mobile"] .kpi-grid {
  grid-template-columns: repeat(2, 1fr) !important;
  gap: 8px;
  padding: 0 12px 12px;
}
[data-view-mode="mobile"] .card,
[data-view-mode="mobile"] .kpi {
  padding: 10px 10px;
}
[data-view-mode="mobile"] .card-label,
[data-view-mode="mobile"] .kpi-label {
  font-size: 9px;
}
[data-view-mode="mobile"] .card-value,
[data-view-mode="mobile"] .kpi-val {
  font-size: 14.5px;
}

[data-view-mode="mobile"] #topbar {
  padding: 0;
}
[data-view-mode="mobile"] .nav-row {
  padding: 6px 10px;
  gap: 6px;
}
[data-view-mode="mobile"] .nav-btn {
  padding: 7px 10px;
  font-size: 11px;
}
[data-view-mode="mobile"] .toolbar-row {
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 12px;
}
[data-view-mode="mobile"] .toolbar-title h1 {
  font-size: 15px;
}
[data-view-mode="mobile"] .toolbar-title p {
  font-size: 10px;
}
[data-view-mode="mobile"] .top-actions {
  width: 100%;
  display: flex;
  overflow-x: auto;
  padding-bottom: 4px;
  gap: 5px;
  scrollbar-width: none;
}
[data-view-mode="mobile"] .top-actions::-webkit-scrollbar {
  display: none;
}
[data-view-mode="mobile"] .top-actions .btn {
  flex-shrink: 0;
  padding: 5px 9px;
  font-size: 10.5px;
}

[data-view-mode="mobile"] main {
  padding: 10px 12px;
}
[data-view-mode="mobile"] .panel {
  padding: 12px 10px;
  border-radius: 12px;
  margin-bottom: 12px;
}
[data-view-mode="mobile"] .panel h2 {
  font-size: 13.5px;
}

[data-view-mode="mobile"] .controls {
  flex-direction: column;
  align-items: stretch;
  gap: 7px;
}
[data-view-mode="mobile"] .controls > div,
[data-view-mode="mobile"] .controls select,
[data-view-mode="mobile"] .controls input,
[data-view-mode="mobile"] .controls .btn {
  width: 100% !important;
  min-width: unset !important;
}

[data-view-mode="mobile"] .detail-header {
  flex-direction: column;
  align-items: stretch;
  gap: 8px;
}
[data-view-mode="mobile"] .toolbar-right {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  width: 100%;
}
[data-view-mode="mobile"] .toolbar-right input,
[data-view-mode="mobile"] .toolbar-right .btn {
  flex: 1 1 calc(50% - 6px);
  min-width: 120px;
}

[data-view-mode="mobile"] .table-wrap {
  border-radius: 10px;
  margin-top: 6px;
}
[data-view-mode="mobile"] table {
  font-size: 10.5px;
}
[data-view-mode="mobile"] thead th,
[data-view-mode="mobile"] tbody td {
  padding: 5px 6px;
}
[data-view-mode="mobile"] .app-foot {
  padding: 12px 14px;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 6px;
}
"""

    if '/* ── MOBILE / DESKTOP VIEW TOGGLE ── */' not in content:
        content = content.replace('/* Theme Toggle Button Component */', mobile_css + '\n/* Theme Toggle Button Component */')

    # 2. Add Button in Topbar
    btn_html = """          <button class="btn view-mode-btn" id="viewModeToggleBtn" type="button" title="Toggle Mobile / Desktop View (Shortcut: M)" aria-label="Toggle Mobile View">
            <span class="view-mode-icon" id="viewModeIcon">📱</span>
            <span id="viewModeText">Mobile</span>
          </button>
"""
    if 'id="viewModeToggleBtn"' not in content:
        content = content.replace(
            '<button class="btn hand-tool-btn"',
            btn_html + '          <button class="btn hand-tool-btn"'
        )

    # 3. Add JavaScript Logic
    js_logic = """
/* ==========================================================================
   VIEW MODE CONTROLLER (Mobile View & Desktop View Toggle)
   ========================================================================== */
function getStoredViewMode() {
  try {
    var m = localStorage.getItem('scrapsale_view_mode');
    if (m === 'mobile' || m === 'desktop') return m;
  } catch (e) {}
  return 'desktop';
}

function applyViewMode(mode, save) {
  var isMobile = mode === 'mobile';
  document.documentElement.setAttribute('data-view-mode', mode);
  if (save) {
    try { localStorage.setItem('scrapsale_view_mode', mode); } catch (e) {}
  }
  
  var btn = document.getElementById('viewModeToggleBtn');
  var icon = document.getElementById('viewModeIcon');
  var text = document.getElementById('viewModeText');
  
  if (isMobile) {
    if (icon) icon.textContent = '💻';
    if (text) text.textContent = 'Desktop';
    if (btn) btn.setAttribute('title', 'Switch to Desktop Full View (Shortcut: M)');
  } else {
    if (icon) icon.textContent = '📱';
    if (text) text.textContent = 'Mobile';
    if (btn) btn.setAttribute('title', 'Switch to Mobile Optimized View (Shortcut: M)');
  }
}

function toggleViewMode() {
  var current = document.documentElement.getAttribute('data-view-mode') || 'desktop';
  var next = (current === 'mobile') ? 'desktop' : 'mobile';
  applyViewMode(next, true);
  showToast('Switched to ' + (next === 'mobile' ? '📱 Mobile View' : '💻 Desktop View'), 'ok');
}

window.toggleViewMode = toggleViewMode;
window.applyViewMode = applyViewMode;

// Immediate view mode initialization
(function() {
  var storedView = getStoredViewMode();
  document.documentElement.setAttribute('data-view-mode', storedView);
})();
"""

    if 'VIEW MODE CONTROLLER' not in content:
        content = content.replace('function toggleTheme() {', js_logic + '\nfunction toggleTheme() {')

    # 4. Attach listener in init() and keyboard shortcut 'M'
    old_init_theme_listener = "  var themeBtn = document.getElementById('themeToggleBtn');\n  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);"
    new_init_theme_listener = """  var themeBtn = document.getElementById('themeToggleBtn');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);
  var viewModeBtn = document.getElementById('viewModeToggleBtn');
  if (viewModeBtn) viewModeBtn.addEventListener('click', toggleViewMode);
  applyViewMode(getStoredViewMode());"""

    if old_init_theme_listener in content:
        content = content.replace(old_init_theme_listener, new_init_theme_listener)

    # Add 'M' shortcut listener in keydown
    old_h_shortcut = "    if (e.key === 'h' || e.key === 'H') {"
    new_h_m_shortcut = """    if (e.key === 'm' || e.key === 'M') {
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        toggleViewMode();
        return;
      }
    }
    if (e.key === 'h' || e.key === 'H') {"""
    if old_h_shortcut in content and "e.key === 'm'" not in content:
        content = content.replace(old_h_shortcut, new_h_m_shortcut)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Processed {file_path}")

process_file('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
process_file('/home/user/index.html')
process_file('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
