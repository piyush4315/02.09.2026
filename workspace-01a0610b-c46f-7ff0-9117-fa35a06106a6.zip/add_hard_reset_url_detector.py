with open('/home/user/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Add URL-based hard reset detector at the start of app script
url_reset_snippet = """
/* ── URL HARD RESET DETECTOR (?reset=1 or #reset) ── */
(function checkUrlHardReset() {
  try {
    var href = window.location.href.toLowerCase();
    if (href.indexOf('reset') !== -1 || href.indexOf('clear=1') !== -1 || href.indexOf('purge=1') !== -1) {
      localStorage.clear();
      sessionStorage.clear();
      if ('caches' in window) {
        caches.keys().then(function(names) { names.forEach(function(n) { caches.delete(n); }); });
      }
      if (window.history && window.history.replaceState) {
        var cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
      }
    }
  } catch (e) {}
})();
"""

if '/* ── URL HARD RESET DETECTOR' not in text:
    text = text.replace('<script id="app">\n"use strict";', '<script id="app">\n"use strict";\n' + url_reset_snippet)
    print("Added URL hard reset detector")

for path in [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html'
]:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)

print("Synchronized all files.")
