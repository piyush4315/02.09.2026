const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(500);

  // Switch to Light Theme
  const themeToggle = await page.$("#themeToggleBtn");
  if (themeToggle) {
    await themeToggle.click();
    await page.waitForTimeout(300);
  }

  // Screenshot Lot Details table in Light Theme
  const lotsSection = await page.$("#tableWrap, .table-wrap");
  if (lotsSection) {
    await lotsSection.scrollIntoViewIfNeeded();
    await page.waitForTimeout(300);
    await page.screenshot({ path: "/home/user/neon_chips_lot_details_light.png" });
  }

  // Scroll to Pivot Table in Light Theme
  const pivotTable = await page.$("#pivotTable");
  if (pivotTable) {
    await pivotTable.scrollIntoViewIfNeeded();
    await page.waitForTimeout(300);
    await page.screenshot({ path: "/home/user/neon_chips_pivot_light.png" });
  }

  // Open Lot Inspector modal in Light Theme
  await page.evaluate(() => {
    if (typeof openLotDetails === "function") openLotDetails(0);
  });
  await page.waitForTimeout(400);
  await page.screenshot({ path: "/home/user/neon_chips_lot_inspector_light.png" });

  // Close modal and open Payment Advice modal in Light Theme
  await page.evaluate(() => {
    if (typeof closeModal === "function") closeModal();
    if (typeof openPaymentAdvice === "function") openPaymentAdvice(0);
  });
  await page.waitForTimeout(400);
  await page.screenshot({ path: "/home/user/neon_chips_payment_advice_light.png" });

  await browser.close();
  console.log("All screenshots captured successfully!");
})();
