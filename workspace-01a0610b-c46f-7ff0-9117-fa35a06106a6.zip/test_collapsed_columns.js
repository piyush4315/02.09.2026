const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 950 } });

  page.on('console', msg => console.log('PAGE LOG:', msg.type(), msg.text()));
  page.on('pageerror', err => console.log('PAGE ERROR:', err.message));

  await page.goto('http://127.0.0.1:8080/index.html?reset=1', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  // Check detail headers
  const detailHeaders = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('#detailTableDash thead th[data-field]')).map(th => ({
      field: th.dataset.field,
      label: th.querySelector('.th-label')?.textContent?.trim() || th.dataset.field
    }));
  });
  console.log('Total visible detail columns:', detailHeaders.length);
  console.log('Visible columns list:', detailHeaders.map(h => h.label));

  const hasQty = detailHeaders.some(h => h.field === 'qty');
  const hasRate = detailHeaders.some(h => h.field === 'rate');
  const hasLotName = detailHeaders.some(h => h.field === 'lot_name');
  const hasTcs = detailHeaders.some(h => h.field === 'tcs');
  const hasTds194o = detailHeaders.some(h => h.field === 'tds194o');
  
  console.log('Are columns 1-3 (Qty, Rate, Lot Name) collapsed/hidden?:', !hasQty && !hasRate && !hasLotName);
  console.log('Are columns 12-15 (TCS, TDS 194O, SC MSTC, etc.) collapsed/hidden?:', !hasTcs && !hasTds194o);

  // Take screenshot of collapsed Lot Details table
  await page.screenshot({ path: '/home/user/scrapsale_collapsed_default_proof.png' });
  console.log('Saved: /home/user/scrapsale_collapsed_default_proof.png');

  // Test expanding columns 1-3 by clicking on Bid Sheet header
  const bidSheetTh = await page.$('#detailTableDash thead th[data-field="auction"]');
  if (bidSheetTh) {
    await bidSheetTh.click();
    await page.waitForTimeout(300);
    const expandedHeaders = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('#detailTableDash thead th[data-field]')).map(th => th.dataset.field);
    });
    console.log('After clicking Bid Sheet, are columns 1-3 expanded?:', expandedHeaders.includes('qty') && expandedHeaders.includes('rate'));
  }

  await browser.close();
  console.log('Column Collapse Default test PASSED!');
})();
