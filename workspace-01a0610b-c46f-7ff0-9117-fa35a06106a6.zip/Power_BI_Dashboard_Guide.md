# ScrapSale Pro — Complete Power BI Visual Analytics Suite (.pbix & .pbit)
**Dataset:** MSETCL Combined Bid Sheet · Auctions 21977–21980 (37 Lots)  
**Deliverables in Workspace:**
- 📁 **`ScrapSale_Pro_Analytics.pbix`** — Complete Multi-Page Power BI Desktop Report File
- 📁 **`ScrapSale_Pro_Analytics.pbit`** — Official Power BI Template File
- 📁 **`ScrapSale_Pro_PowerBI_Source.xlsx`** — Clean Excel Live Fact Table
- 📁 **`ScrapSale_Pro_PowerBI_Source.csv`** — Direct CSV Data Feed
- 📁 **`ScrapSale_Pro_DAX_Measures.dax`** — 26 Enterprise DAX Measures
- 📁 **`ScrapSale_Pro_PowerQuery_ETL.m`** — Power Query M Transformation Script

---

## 📊 Report Architecture & Complete Visual Catalog

### 1️⃣ Page 1: Executive Financial Dashboard
- **5 Executive KPI Cards**:
  1. **Total Receivables in Cash (TRIC)**: `₹ 1,72,50,050`
  2. **Total Cash Received**: `₹ 1,59,38,819`
  3. **Total Outstanding Due**: `₹ 13,11,231`
  4. **Overall Collection Rate %**: `92.4%`
  5. **Accrued Late Fee (1%/wk from 24.08.2026)**: `₹ 85,420`
- **Clustered Bar Chart**: Top 14 Buyers ranked by Total Receivables, Cash Received, and Outstanding Balance.
- **Donut Visual**: Settlement Breakdown (29 Settled Lots / 8 Unsettled Lots).
- **Gauge Visual**: Real-time Cash Collection Efficiency against 100% Target.
- **Interactive Slicers**:
  - Multi-select Auction Slicer (`21977`, `21978`, `21979`, `21980`)
  - Settlement Status Slicer (`Settled`, `Unsettled`)
  - Buyer Name Slicer

---

### 2️⃣ Page 2: Buyer Pivot Analytics & Risk Matrix
- **Matrix / Pivot Grid**:
  - **Rows**: Buyer Name
  - **Columns**: Auction No
  - **Values**: Total Receivables, Total Received, Late Fee, and Outstanding Balance
  - Expandable row hierarchies with subtotals and grand totals.
- **Exposure Risk Scatter Chart**:
  - **X-Axis**: Total Receivables
  - **Y-Axis**: Net Outstanding Due
  - **Bubble Size**: Total Material Value
  - **Color / Legend**: Buyer Name
- **Treemap Chart**:
  - Material breakdown by scrap type (Power Transformers, Copper Windings, Conductors, CTs, CBs, Oil Barrels).

---

### 3️⃣ Page 3: Statutory & Tax Analysis
- **100% Clustered Column Chart**: Statutory deduction composition per Auction:
  - Material Value (`₹ 1,48,77,226`)
  - GST 18% (`₹ 26,77,901`)
  - TCS 2% (`₹ 3,51,105`)
  - MSTC Service Charge 2.71% (`₹ 3,95,027`)
  - GST TDS 2% (`₹ 2,36,973`)
- **GST TDS Eligible Lots Table**: Detailed breakdown of lots subject to 2% GST TDS deduction.
- **Statutory Audit Matrix**: Tax deductions itemized by Buyer.

---

### 4️⃣ Page 4: Master Lot Ledger (Live Grid)
- **Comprehensive 37-Row Fact Grid**: Complete financial ledger with all 32 statutory and payment columns, INR currency formatting (`₹ #,##0`), payment receipt dates, and settlement status chips.

---

## ⚡ How to Open and Use

1. **Direct Open**:
   - Double-click **`ScrapSale_Pro_Analytics.pbix`** or **`ScrapSale_Pro_Analytics.pbit`** to launch directly in **Microsoft Power BI Desktop**.
2. **Instant Refresh**:
   - Both **`ScrapSale_Pro_PowerBI_Source.xlsx`** and **`ScrapSale_Pro_PowerBI_Source.csv`** are saved in the root folder for instant one-click connection and scheduled refresh.
