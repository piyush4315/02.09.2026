with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update allAssignableFields to exclude invoice_no from pivotLot
old_aaf = """function allAssignableFields(which) {
  var out = [];
  if (which === 'detail') {
    DEFAULT_DETAIL_KEYS.forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
    customCols.forEach(function (c) { out.push({ key: c.id, label: c.name + ' (custom)' }); });
  } else if (which === 'pivotLot') {
    DEFAULT_DETAIL_KEYS.forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
    customCols.forEach(function (c) { out.push({ key: c.id, label: c.name + ' (custom)' }); });
  } else {
    DEFAULT_PIVOT_METRIC_KEYS.forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
  }
  return out;
}"""

new_aaf = """function allAssignableFields(which) {
  var out = [];
  if (which === 'detail') {
    DEFAULT_DETAIL_KEYS.forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
    customCols.forEach(function (c) { out.push({ key: c.id, label: c.name + ' (custom)' }); });
  } else if (which === 'pivotLot') {
    DEFAULT_DETAIL_KEYS.filter(function(k){ return k !== 'invoice_no'; }).forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
    customCols.forEach(function (c) { out.push({ key: c.id, label: c.name + ' (custom)' }); });
  } else {
    DEFAULT_PIVOT_METRIC_KEYS.forEach(function (k) { out.push({ key: k, label: fieldLabel(k) }); });
    customCols.forEach(function (c) {
      if (c.type === 'number') out.push({ key: c.id, label: c.name + ' (custom)' });
    });
  }
  return out;
}"""

if old_aaf in text:
    text = text.replace(old_aaf, new_aaf, 1)
    print("1. Updated allAssignableFields")
else:
    print("1. allAssignableFields not found")

# 2. Update unhideFieldAt
old_unhide = """/* Re-show a hidden column, keeping the canonical column order when possible */
function unhideFieldAt(layoutKind, key) {
  var lay = colLayout[layoutKind];
  if (!lay || lay.indexOf(key) !== -1) return;
  var defaults = (layoutKind === 'detail') ? DEFAULT_DETAIL_KEYS : (layoutKind === 'pivotLot' ? DEFAULT_PIVOT_LOT_KEYS : DEFAULT_PIVOT_METRIC_KEYS);
  var di = defaults.indexOf(key);
  var insertAt = lay.length;
  if (di >= 0) {
    for (var i = 0; i < lay.length; i++) {
      var ci = defaults.indexOf(lay[i]);
      if (ci >= 0 && ci > di) { insertAt = i; break; }
    }
  }
  lay.splice(insertAt, 0, key);
}"""

new_unhide = """/* Re-show a hidden column, keeping the canonical column order when possible */
function unhideFieldAt(layoutKind, key) {
  var lay = colLayout[layoutKind];
  if (!lay || lay.indexOf(key) !== -1) return;
  var defaults = (layoutKind === 'detail') 
    ? DEFAULT_DETAIL_KEYS 
    : (layoutKind === 'pivotLot' ? DEFAULT_DETAIL_KEYS.filter(function(k){ return k !== 'invoice_no'; }) : DEFAULT_PIVOT_METRIC_KEYS);
  var di = defaults.indexOf(key);
  var insertAt = lay.length;
  if (di >= 0) {
    for (var i = 0; i < lay.length; i++) {
      var ci = defaults.indexOf(lay[i]);
      if (ci >= 0 && ci > di) { insertAt = i; break; }
    }
  }
  lay.splice(insertAt, 0, key);
}"""

if old_unhide in text:
    text = text.replace(old_unhide, new_unhide, 1)
    print("2. Updated unhideFieldAt")
else:
    print("2. unhideFieldAt not found")

# 3. Update renderColToggles
old_rct = """function renderColToggles(containerId, layoutKind) {
  var container = document.getElementById(containerId);
  if (!container) return;
  var catalog = allAssignableFields(layoutKind);
  var arr = colLayout[layoutKind] || [];
  var hiddenCols = catalog.filter(function (c) {
    return arr.indexOf(c.key) === -1;
  });

  if (hiddenCols.length === 0) {
    container.innerHTML = '';
    container.style.display = 'none';
    return;
  }

  container.style.display = 'flex';
  var html = '<span style="font-size:11px;font-weight:600;color:var(--dim);display:inline-flex;align-items:center;margin-right:2px;">Hidden columns:</span>';
  html += hiddenCols.map(function (c) {
    return '<button type="button" class="col-toggle off" data-key="' + escHtml(c.key) + '" title="Click to show “' + escHtml(c.label) + '” column">+ ' + escHtml(c.label) + '</button>';
  }).join('');
  if (hiddenCols.length > 1) {
    html += '<button type="button" class="col-toggle on" id="unhideAllColsBtn" title="Show all hidden columns">↺ Show all (' + hiddenCols.length + ')</button>';
  }
  container.innerHTML = html;

  container.querySelectorAll('.col-toggle[data-key]').forEach(function (b) {
    b.addEventListener('click', function () {
      var key = b.getAttribute('data-key');
      pushHistory();
      unhideFieldAt(layoutKind, key);
      saveState();
      renderAll();
      var f = fieldDef(layoutKind, key);
      showToast('Restored “' + (f ? f.label : key) + '” column', 'ok');
    });
  });

  var unhideAllBtn = container.querySelector('#unhideAllColsBtn');
  if (unhideAllBtn) {
    unhideAllBtn.addEventListener('click', function () {
      pushHistory();
      hiddenCols.forEach(function (c) {
        unhideFieldAt(layoutKind, c.key);
      });
      saveState();
      renderAll();
      showToast('Restored all hidden columns', 'ok');
    });
  }
}"""

new_rct = """function renderColToggles(containerId, layoutKind) {
  var container = document.getElementById(containerId);
  if (!container) return;
  var catalog = allAssignableFields(layoutKind);
  var arr = colLayout[layoutKind] || [];
  var hiddenCols = catalog.filter(function (c) {
    return arr.indexOf(c.key) === -1;
  });

  if (hiddenCols.length === 0) {
    container.innerHTML = '';
    container.style.display = 'none';
    return;
  }

  container.style.display = 'flex';
  var html = '<span style="font-size:11px;font-weight:600;color:var(--dim);display:inline-flex;align-items:center;margin-right:2px;">Hidden columns:</span>';
  html += hiddenCols.map(function (c) {
    return '<button type="button" class="col-toggle off" data-key="' + escHtml(c.key) + '" title="Click to show “' + escHtml(c.label) + '” column">+ ' + escHtml(c.label) + '</button>';
  }).join('');
  if (hiddenCols.length > 1) {
    html += '<button type="button" class="col-toggle on unhide-all-btn" title="Show all hidden columns">↺ Show all (' + hiddenCols.length + ')</button>';
  }
  container.innerHTML = html;

  container.querySelectorAll('.col-toggle[data-key]').forEach(function (b) {
    b.addEventListener('click', function () {
      var key = b.getAttribute('data-key');
      pushHistory();
      unhideFieldAt(layoutKind, key);
      saveState();
      renderAll();
      var f = fieldDef(layoutKind, key);
      showToast('Restored “' + (f ? f.label : key) + '” column', 'ok');
    });
  });

  var unhideAllBtn = container.querySelector('.unhide-all-btn') || container.querySelector('#unhideAllColsBtn');
  if (unhideAllBtn) {
    unhideAllBtn.addEventListener('click', function () {
      pushHistory();
      hiddenCols.forEach(function (c) {
        unhideFieldAt(layoutKind, c.key);
      });
      saveState();
      renderAll();
      showToast('Restored all hidden columns', 'ok');
    });
  }
}"""

if old_rct in text:
    text = text.replace(old_rct, new_rct, 1)
    print("3. Updated renderColToggles")
else:
    print("3. renderColToggles not found")

# 4. Update renderAll
old_ra = """function renderAll() {
  renderActiveFiltersBar();
  renderCards();
  renderPivot();
  renderDetail();
  renderColToggles('dashColToggles', 'detail');
  updateUndoRedoUI();
  paintColSelection();"""

new_ra = """function renderAll() {
  renderActiveFiltersBar();
  renderCards();
  renderPivot();
  renderDetail();
  var pivotLayoutKind = (ui.groupBy === 'default') ? 'pivotLot' : 'pivotMetric';
  renderColToggles('pivotColToggles', pivotLayoutKind);
  renderColToggles('dashColToggles', 'detail');
  updateUndoRedoUI();
  paintColSelection();"""

if old_ra in text:
    text = text.replace(old_ra, new_ra, 1)
    print("4. Updated renderAll")
else:
    print("4. renderAll not found")

# 5. Update paintColSelection & showHideSelectedBtn
old_pcs = """function paintColSelection() {
  var ths = document.querySelectorAll('#detailTableDash thead th[data-field]');
  ths.forEach(function (th) {
    var f = th.dataset.field;
    if (colSel.selected.has(f)) th.classList.add('th-selected');
    else th.classList.remove('th-selected');
  });
  showHideSelectedBtn();
}
function showHideSelectedBtn() {
  var n = colSel.selected.size;
  var btn = document.getElementById('hideSelColsBtn');
  if (!btn) return;
  if (n > 0) { btn.style.display = 'inline-block'; btn.textContent = '⊗ Hide ' + n + ' column' + (n > 1 ? 's' : ''); }
  else { btn.style.display = 'none'; }
}"""

new_pcs = """function paintColSelection() {
  var thsDetail = document.querySelectorAll('#detailTableDash thead th[data-field]');
  thsDetail.forEach(function (th) {
    var f = th.dataset.field;
    if (colSel.lastTable === 'detail' && colSel.selected.has(f)) th.classList.add('th-selected');
    else th.classList.remove('th-selected');
  });
  var thsPivot = document.querySelectorAll('#pivotTable thead th[data-field]');
  thsPivot.forEach(function (th) {
    var f = th.dataset.field;
    if (colSel.lastTable === 'pivot' && colSel.selected.has(f)) th.classList.add('th-selected');
    else th.classList.remove('th-selected');
  });
  showHideSelectedBtn();
}
function showHideSelectedBtn() {
  var n = colSel.selected.size;
  var isPivot = colSel.lastTable === 'pivot';
  var detailBtn = document.getElementById('hideSelColsBtn');
  var pivotBtn = document.getElementById('hideSelPivotColsBtn');
  if (detailBtn) {
    if (n > 0 && !isPivot) {
      detailBtn.style.display = 'inline-block';
      detailBtn.textContent = '⊗ Hide ' + n + ' column' + (n > 1 ? 's' : '');
    } else {
      detailBtn.style.display = 'none';
    }
  }
  if (pivotBtn) {
    if (n > 0 && isPivot) {
      pivotBtn.style.display = 'inline-block';
      pivotBtn.textContent = '⊗ Hide ' + n + ' column' + (n > 1 ? 's' : '');
    } else {
      pivotBtn.style.display = 'none';
    }
  }
}"""

if old_pcs in text:
    text = text.replace(old_pcs, new_pcs, 1)
    print("5. Updated paintColSelection & showHideSelectedBtn")
else:
    print("5. paintColSelection not found")

# 6. Update hideSelectedCols
old_hsc = """  function hideSelectedCols() {
    var n = colSel.selected.size;
    if (n === 0) { showToast('No columns selected.', 'info'); return; }
    var arr = colLayout.detail;
    if (!arr) return;
    pushHistory();
    colSel.selected.forEach(function (k) {
      var ix = arr.indexOf(k);
      if (ix !== -1) arr.splice(ix, 1);
    });
    colSel.selected.clear(); colSel.lastAnchor = null; colSel.lastTable = null;
    saveState(); renderAll();
    showToast('Column hidden', 'ok');
  }"""

new_hsc = """  function hideSelectedCols() {
    var n = colSel.selected.size;
    if (n === 0) { showToast('No columns selected.', 'info'); return; }
    var layoutKind = (colSel.lastTable === 'pivot') ? ((ui.groupBy === 'default') ? 'pivotLot' : 'pivotMetric') : 'detail';
    var arr = colLayout[layoutKind];
    if (!arr) return;
    pushHistory();
    colSel.selected.forEach(function (k) {
      var ix = arr.indexOf(k);
      if (ix !== -1) arr.splice(ix, 1);
    });
    colSel.selected.clear(); colSel.lastAnchor = null; colSel.lastTable = null;
    saveState(); renderAll();
    showToast(n + ' column' + (n > 1 ? 's' : '') + ' hidden', 'ok');
  }"""

if old_hsc in text:
    text = text.replace(old_hsc, new_hsc, 1)
    print("6. Updated hideSelectedCols")
else:
    print("6. hideSelectedCols not found")

# 7. Update hideSelPivotColsBtn listener in init()
old_init_btn = """  document.getElementById('hideSelColsBtn').addEventListener('click', function () {
    hideSelectedCols();
  });"""

new_init_btn = """  document.getElementById('hideSelColsBtn').addEventListener('click', function () {
    hideSelectedCols();
  });
  var hidePivotBtn = document.getElementById('hideSelPivotColsBtn');
  if (hidePivotBtn) {
    hidePivotBtn.addEventListener('click', function () {
      hideSelectedCols();
    });
  }"""

if old_init_btn in text:
    text = text.replace(old_init_btn, new_init_btn, 1)
    print("7. Updated hideSelPivotColsBtn listener")
else:
    print("7. hideSelColsBtn in init not found")

# 8. Update openLotDetails buttons
old_old_btns = """    buttons: [
      {
        label: '✏️ Edit this Lot',
        cls: 'primary',
        onClick: function () {
          modal.close();
          openLotForm(lotIdx);
          return false;
        }
      },
      {
        label: 'Close',
        cls: 'secondary',
        onClick: function () {
          return true;
        }
      }
    ]"""

new_old_btns = """    buttons: [
      {
        label: '📋 Buyer Advice',
        cls: 'secondary',
        onClick: function () {
          modal.close();
          openPaymentAdvice(r.buyer);
          return false;
        }
      },
      {
        label: '✏️ Edit this Lot',
        cls: 'primary',
        onClick: function () {
          modal.close();
          openLotForm(lotIdx);
          return false;
        }
      },
      {
        label: 'Close',
        cls: 'secondary',
        onClick: function () {
          return true;
        }
      }
    ]"""

if old_old_btns in text:
    text = text.replace(old_old_btns, new_old_btns, 1)
    print("8. Updated openLotDetails buttons")
else:
    print("8. openLotDetails buttons not found")

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("Saved updated index.html successfully!")
