import json, zipfile, os, re, datetime
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

print("Building Power BI Suite...")

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'var SAMPLE_DATA = (\[.*?\]);', text, re.DOTALL)
lots_raw = json.loads(m.group(1))

base_date = datetime.date(2026, 8, 24)
curr_date = datetime.date(2026, 8, 31)

def parse_dot_date(dstr):
    if not dstr or dstr in ['—', '-', 'N/A']: return None
    try:
        parts = dstr.split('.')
        return datetime.date(int(parts[2]), int(parts[1]), int(parts[0]))
    except Exception:
        return None

processed_lots = []
for idx, r in enumerate(lots_raw, 1):
    unit = r.get('unit', '')
    qty = float(r.get('qty', 0))
    rate = float(r.get('rate', 0))
    auction = int(r.get('auction', 0))
    lot_name = r.get('lot_name', '')
    lot_no = int(r.get('lot_no', 0))
    buyer = r.get('buyer', '')
    mat_value = round(float(r.get('mat_value', qty * rate)))
    gst = round(float(r.get('gst', mat_value * 0.18)))
    mat_value_plus_gst = mat_value + gst
    tcs = round(float(r.get('tcs', 0)))
    tds194o = round(float(r.get('tds194o', mat_value * 0.001)), 2)
    service_charge_mstc = round(float(r.get('service_charge_mstc', 0)), 2)
    tds194h = round(float(r.get('tds194h', 0)), 2)
    net_service_charge = round(float(r.get('net_service_charge', 0)), 2)
    service_charge_to_mstc = round(float(r.get('service_charge_to_mstc', 0)))
    gst_tds_rate = float(r.get('gst_tds_rate', 0))
    gst_tds = round(float(r.get('gst_tds', mat_value * gst_tds_rate / 100)))
    total_receivables = round(mat_value + gst + tcs - tds194o - net_service_charge - gst_tds)
    sd_expected = round(float(r.get('sd_expected', mat_value * 0.25)))
    sd_received = round(float(r.get('sd_received', 0)))
    sd_date = r.get('sd_date', '') or ''
    fp_expected = total_receivables - sd_expected
    fp_received = round(float(r.get('fp_received', 0)))
    fp_date = r.get('fp_date', '') or ''

    fp_d = parse_dot_date(fp_date)
    late_fee = 0
    if fp_d:
        if fp_d > base_date:
            days = (fp_d - base_date).days
            weeks = (days + 6) // 7
            late_fee = round(mat_value * weeks * 0.01)
    else:
        unpaid_fp = max(0, fp_expected - fp_received)
        if unpaid_fp > 1:
            days = (curr_date - base_date).days
            weeks = (days + 6) // 7
            late_fee = round(mat_value * weeks * 0.01)

    total_received = sd_received + fp_received
    outstanding = round(total_receivables + late_fee - total_received)
    settlement_status = "Settled" if outstanding <= 1 else "Unsettled"
    invoice_no = r.get('invoice_no', '') or ''
    sap_document_date = r.get('sap_document_date', '') or ''
    doc_invoice_date = r.get('doc_invoice_date', '') or ''

    processed_lots.append({
        'Lot No': lot_no,
        'Auction': auction,
        'Buyer': buyer,
        'Lot Name': lot_name,
        'Unit': unit,
        'Qty': qty,
        'Rate': rate,
        'Material Value': mat_value,
        'GST': gst,
        'Material Value + GST': mat_value_plus_gst,
        'TCS': tcs,
        'TDS 194O': tds194o,
        'MSTC Service Charge': service_charge_mstc,
        'TDS 194H': tds194h,
        'Net Service Charge': net_service_charge,
        'Service Charge to MSTC': service_charge_to_mstc,
        'GST TDS Rate': gst_tds_rate,
        'GST TDS': gst_tds,
        'Total Receivables': total_receivables,
        'SD Expected': sd_expected,
        'SD Received': sd_received,
        'SD Date': sd_date,
        'FP Expected': fp_expected,
        'FP Received': fp_received,
        'FP Date': fp_date,
        'Late Fee': late_fee,
        'Total Received': total_received,
        'Outstanding': outstanding,
        'Settlement Status': settlement_status,
        'Invoice No': invoice_no,
        'SAP Doc No': sap_document_date,
        'Invoice Date': doc_invoice_date
    })

df = pd.DataFrame(processed_lots)

# CSV & Excel Data Sources
excel_path = '/home/user/ScrapSale_Pro_PowerBI_Source.xlsx'
csv_path = '/home/user/ScrapSale_Pro_PowerBI_Source.csv'
df.to_csv(csv_path, index=False, encoding='utf-8')

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "CashReceivables"
ws.views.sheetView[0].showGridLines = True

hdr_fill = PatternFill(start_color="1E1B4B", end_color="1E1B4B", fill_type="solid")
hdr_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
thin_border = Border(
    left=Side(style='thin', color='CBD5E1'),
    right=Side(style='thin', color='CBD5E1'),
    top=Side(style='thin', color='CBD5E1'),
    bottom=Side(style='thin', color='CBD5E1')
)

headers = list(df.columns)
ws.append(headers)
for col_num, h in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.fill = hdr_fill
    cell.font = hdr_font
    cell.alignment = Alignment(horizontal="center", vertical="center")

for r_idx, row in df.iterrows():
    row_data = list(row)
    ws.append(row_data)
    curr_r = r_idx + 2
    for c_idx, val in enumerate(row_data, 1):
        cell = ws.cell(row=curr_r, column=c_idx)
        cell.border = thin_border
        cell.font = Font(name="Calibri", size=10)
        h_name = headers[c_idx-1]
        if isinstance(val, (int, float)) and c_idx not in [1, 2]:
            if h_name in ['Material Value', 'GST', 'Material Value + GST', 'TCS', 'Total Receivables', 'SD Expected', 'SD Received', 'FP Expected', 'FP Received', 'Late Fee', 'Total Received', 'Outstanding', 'Service Charge to MSTC', 'GST TDS']:
                cell.number_format = '₹ #,##0'
                cell.alignment = Alignment(horizontal="right")
            elif h_name in ['TDS 194O', 'MSTC Service Charge', 'TDS 194H', 'Net Service Charge']:
                cell.number_format = '₹ #,##0.00'
                cell.alignment = Alignment(horizontal="right")
            elif h_name in ['Qty', 'Rate', 'GST TDS Rate']:
                cell.number_format = '#,##0.00' if h_name != 'Qty' else '#,##0'
                cell.alignment = Alignment(horizontal="right")
        elif h_name in ['Lot No', 'Auction', 'SD Date', 'FP Date', 'Invoice Date', 'Settlement Status', 'Unit', 'Invoice No', 'SAP Doc No']:
            cell.alignment = Alignment(horizontal="center")
        else:
            cell.alignment = Alignment(horizontal="left")

for col in ws.columns:
    max_len = max(len(str(cell.value or '')) for cell in col)
    col_letter = get_column_letter(col[0].column)
    ws.column_dimensions[col_letter].width = max(max_len + 3, 11)

wb.save(excel_path)
print(f"Saved Excel source: {excel_path} and CSV source: {csv_path}")

# Construct TMSL Model Schema
schema_dict = {
    "name": "ScrapSale_Pro_Model",
    "compatibilityLevel": 1550,
    "model": {
        "culture": "en-US",
        "dataAccessOptions": {"legacyRedirects": True, "returnErrorValuesAsNull": True},
        "defaultPowerBIDataSourceVersion": "powerBI_V3",
        "sourceQueryCulture": "en-IN",
        "tables": [
            {
                "name": "CashReceivables",
                "columns": [
                    {"name": "Lot No", "dataType": "int64", "formatString": "0", "sourceColumn": "Lot No", "summarizeBy": "none"},
                    {"name": "Auction", "dataType": "int64", "formatString": "0", "sourceColumn": "Auction", "summarizeBy": "none"},
                    {"name": "Buyer", "dataType": "string", "sourceColumn": "Buyer", "summarizeBy": "none"},
                    {"name": "Lot Name", "dataType": "string", "sourceColumn": "Lot Name", "summarizeBy": "none"},
                    {"name": "Unit", "dataType": "string", "sourceColumn": "Unit", "summarizeBy": "none"},
                    {"name": "Qty", "dataType": "double", "formatString": "#,##0", "sourceColumn": "Qty", "summarizeBy": "sum"},
                    {"name": "Rate", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "Rate", "summarizeBy": "average"},
                    {"name": "Material Value", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Material Value", "summarizeBy": "sum"},
                    {"name": "GST", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "GST", "summarizeBy": "sum"},
                    {"name": "Material Value + GST", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Material Value + GST", "summarizeBy": "sum"},
                    {"name": "TCS", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "TCS", "summarizeBy": "sum"},
                    {"name": "TDS 194O", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "TDS 194O", "summarizeBy": "sum"},
                    {"name": "MSTC Service Charge", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "MSTC Service Charge", "summarizeBy": "sum"},
                    {"name": "TDS 194H", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "TDS 194H", "summarizeBy": "sum"},
                    {"name": "Net Service Charge", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "Net Service Charge", "summarizeBy": "sum"},
                    {"name": "Service Charge to MSTC", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Service Charge to MSTC", "summarizeBy": "sum"},
                    {"name": "GST TDS Rate", "dataType": "double", "formatString": "0.00%", "sourceColumn": "GST TDS Rate", "summarizeBy": "average"},
                    {"name": "GST TDS", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "GST TDS", "summarizeBy": "sum"},
                    {"name": "Total Receivables", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Total Receivables", "summarizeBy": "sum"},
                    {"name": "SD Expected", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "SD Expected", "summarizeBy": "sum"},
                    {"name": "SD Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "SD Received", "summarizeBy": "sum"},
                    {"name": "SD Date", "dataType": "string", "sourceColumn": "SD Date", "summarizeBy": "none"},
                    {"name": "FP Expected", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "FP Expected", "summarizeBy": "sum"},
                    {"name": "FP Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "FP Received", "summarizeBy": "sum"},
                    {"name": "FP Date", "dataType": "string", "sourceColumn": "FP Date", "summarizeBy": "none"},
                    {"name": "Late Fee", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Late Fee", "summarizeBy": "sum"},
                    {"name": "Total Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Total Received", "summarizeBy": "sum"},
                    {"name": "Outstanding", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Outstanding", "summarizeBy": "sum"},
                    {"name": "Settlement Status", "dataType": "string", "sourceColumn": "Settlement Status", "summarizeBy": "none"},
                    {"name": "Invoice No", "dataType": "string", "sourceColumn": "Invoice No", "summarizeBy": "none"},
                    {"name": "SAP Doc No", "dataType": "string", "sourceColumn": "SAP Doc No", "summarizeBy": "none"},
                    {"name": "Invoice Date", "dataType": "string", "sourceColumn": "Invoice Date", "summarizeBy": "none"}
                ],
                "measures": [
                    {"name": "Total Receivables", "expression": "SUM(CashReceivables[Total Receivables])", "formatString": "₹ #,##0"},
                    {"name": "Total Received", "expression": "SUM(CashReceivables[Total Received])", "formatString": "₹ #,##0"},
                    {"name": "Total Outstanding", "expression": "SUM(CashReceivables[Outstanding])", "formatString": "₹ #,##0"},
                    {"name": "Total Material Value", "expression": "SUM(CashReceivables[Material Value])", "formatString": "₹ #,##0"},
                    {"name": "Total Late Fee", "expression": "SUM(CashReceivables[Late Fee])", "formatString": "₹ #,##0"},
                    {"name": "Collection %", "expression": "DIVIDE([Total Received], [Total Receivables] + [Total Late Fee], 0)", "formatString": "0.0%"},
                    {"name": "Settled Lots Count", "expression": "CALCULATE(COUNTROWS(CashReceivables), CashReceivables[Settlement Status] = \"Settled\")", "formatString": "#,##0"},
                    {"name": "Unsettled Lots Count", "expression": "CALCULATE(COUNTROWS(CashReceivables), CashReceivables[Settlement Status] = \"Unsettled\")", "formatString": "#,##0"},
                    {"name": "Total Lots", "expression": "COUNTROWS(CashReceivables)", "formatString": "#,##0"},
                    {"name": "Total Buyers", "expression": "DISTINCTCOUNT(CashReceivables[Buyer])", "formatString": "#,##0"}
                ]
            }
        ]
    }
}

# Construct Report Layout with 4 Rich Visual Pages
sections = [
    {
        "id": 0,
        "name": "ReportSection_ExecDashboard",
        "displayName": "Executive Financial Dashboard",
        "filters": "[]",
        "ordinal": 0,
        "width": 1280.0,
        "height": 720.0,
        "visualContainers": [
            {
                "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 55.0,
                "config": json.dumps({
                    "name": "TitleBox",
                    "singleVisual": {
                        "visualType": "textbox",
                        "objects": {
                            "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "ScrapSale Pro — Executive Cash Receivables Dashboard (MSETCL)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "18pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 80.0, "z": 1.0, "width": 230.0, "height": 110.0,
                "config": json.dumps({
                    "name": "KpiTotalRec",
                    "singleVisual": {
                        "visualType": "card",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Total Receivables"}]},
                        "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#2563EB"}}}}]}
                    }
                })
            },
            {
                "x": 270.0, "y": 80.0, "z": 2.0, "width": 230.0, "height": 110.0,
                "config": json.dumps({
                    "name": "KpiTotalReceived",
                    "singleVisual": {
                        "visualType": "card",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Total Received"}]},
                        "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#16A34A"}}}}]}
                    }
                })
            },
            {
                "x": 520.0, "y": 80.0, "z": 3.0, "width": 230.0, "height": 110.0,
                "config": json.dumps({
                    "name": "KpiOutstanding",
                    "singleVisual": {
                        "visualType": "card",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Total Outstanding"}]},
                        "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#E11D48"}}}}]}
                    }
                })
            },
            {
                "x": 770.0, "y": 80.0, "z": 4.0, "width": 230.0, "height": 110.0,
                "config": json.dumps({
                    "name": "KpiCollectionPct",
                    "singleVisual": {
                        "visualType": "card",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Collection %"}]},
                        "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#0284C7"}}}}]}
                    }
                })
            },
            {
                "x": 1020.0, "y": 80.0, "z": 5.0, "width": 240.0, "height": 110.0,
                "config": json.dumps({
                    "name": "KpiLateFee",
                    "singleVisual": {
                        "visualType": "card",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Total Late Fee"}]},
                        "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#D97706"}}}}]}
                    }
                })
            },
            {
                "x": 20.0, "y": 205.0, "z": 6.0, "width": 620.0, "height": 335.0,
                "config": json.dumps({
                    "name": "BarTopBuyers",
                    "singleVisual": {
                        "visualType": "clusteredBarChart",
                        "projections": {
                            "Category": [{"queryRef": "CashReceivables.Buyer"}],
                            "Y": [
                                {"queryRef": "CashReceivables.Total Receivables"},
                                {"queryRef": "CashReceivables.Total Received"},
                                {"queryRef": "CashReceivables.Outstanding"}
                            ]
                        }
                    }
                })
            },
            {
                "x": 660.0, "y": 205.0, "z": 7.0, "width": 320.0, "height": 335.0,
                "config": json.dumps({
                    "name": "DonutSettlement",
                    "singleVisual": {
                        "visualType": "donutChart",
                        "projections": {
                            "Category": [{"queryRef": "CashReceivables.Settlement Status"}],
                            "Y": [{"queryRef": "CashReceivables.Total Receivables"}]
                        }
                    }
                })
            },
            {
                "x": 1000.0, "y": 205.0, "z": 8.0, "width": 260.0, "height": 335.0,
                "config": json.dumps({
                    "name": "GaugeCollection",
                    "singleVisual": {
                        "visualType": "gauge",
                        "projections": {
                            "Y": [{"queryRef": "CashReceivables.Total Received"}],
                            "TargetValue": [{"queryRef": "CashReceivables.Total Receivables"}]
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 555.0, "z": 9.0, "width": 380.0, "height": 145.0,
                "config": json.dumps({
                    "name": "SlicerAuction",
                    "singleVisual": {
                        "visualType": "slicer",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Auction"}]}
                    }
                })
            },
            {
                "x": 420.0, "y": 555.0, "z": 10.0, "width": 380.0, "height": 145.0,
                "config": json.dumps({
                    "name": "SlicerStatus",
                    "singleVisual": {
                        "visualType": "slicer",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Settlement Status"}]}
                    }
                })
            },
            {
                "x": 820.0, "y": 555.0, "z": 11.0, "width": 440.0, "height": 145.0,
                "config": json.dumps({
                    "name": "SlicerBuyer",
                    "singleVisual": {
                        "visualType": "slicer",
                        "projections": {"Values": [{"queryRef": "CashReceivables.Buyer"}]}
                    }
                })
            }
        ]
    },
    {
        "id": 1,
        "name": "ReportSection_BuyerPivot",
        "displayName": "Buyer Pivot & Risk Matrix",
        "filters": "[]",
        "ordinal": 1,
        "width": 1280.0,
        "height": 720.0,
        "visualContainers": [
            {
                "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 50.0,
                "config": json.dumps({
                    "name": "TitlePivot",
                    "singleVisual": {
                        "visualType": "textbox",
                        "objects": {
                            "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Buyer Pivot Analytics & Exposure Risk Matrix", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 75.0, "z": 1.0, "width": 800.0, "height": 620.0,
                "config": json.dumps({
                    "name": "MatrixPivot",
                    "singleVisual": {
                        "visualType": "pivotTable",
                        "projections": {
                            "Rows": [{"queryRef": "CashReceivables.Buyer"}],
                            "Columns": [{"queryRef": "CashReceivables.Auction"}],
                            "Values": [
                                {"queryRef": "CashReceivables.Total Receivables"},
                                {"queryRef": "CashReceivables.Total Received"},
                                {"queryRef": "CashReceivables.Late Fee"},
                                {"queryRef": "CashReceivables.Outstanding"}
                            ]
                        }
                    }
                })
            },
            {
                "x": 840.0, "y": 75.0, "z": 2.0, "width": 420.0, "height": 340.0,
                "config": json.dumps({
                    "name": "ScatterRisk",
                    "singleVisual": {
                        "visualType": "scatterChart",
                        "projections": {
                            "Category": [{"queryRef": "CashReceivables.Buyer"}],
                            "X": [{"queryRef": "CashReceivables.Total Receivables"}],
                            "Y": [{"queryRef": "CashReceivables.Outstanding"}],
                            "Size": [{"queryRef": "CashReceivables.Material Value"}]
                        }
                    }
                })
            },
            {
                "x": 840.0, "y": 430.0, "z": 3.0, "width": 420.0, "height": 265.0,
                "config": json.dumps({
                    "name": "TreemapMaterial",
                    "singleVisual": {
                        "visualType": "treemap",
                        "projections": {
                            "Group": [{"queryRef": "CashReceivables.Lot Name"}],
                            "Values": [{"queryRef": "CashReceivables.Material Value"}]
                        }
                    }
                })
            }
        ]
    },
    {
        "id": 2,
        "name": "ReportSection_Statutory",
        "displayName": "Statutory & Tax Analysis",
        "filters": "[]",
        "ordinal": 2,
        "width": 1280.0,
        "height": 720.0,
        "visualContainers": [
            {
                "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 50.0,
                "config": json.dumps({
                    "name": "TitleStatutory",
                    "singleVisual": {
                        "visualType": "textbox",
                        "objects": {
                            "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Statutory Taxes & Charges Breakdown (GST 18%, TCS 2%, MSTC SC 2.71%, GST TDS 2%)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 75.0, "z": 1.0, "width": 780.0, "height": 380.0,
                "config": json.dumps({
                    "name": "ColumnStatutory",
                    "singleVisual": {
                        "visualType": "clusteredColumnChart",
                        "projections": {
                            "Category": [{"queryRef": "CashReceivables.Auction"}],
                            "Y": [
                                {"queryRef": "CashReceivables.Material Value"},
                                {"queryRef": "CashReceivables.GST"},
                                {"queryRef": "CashReceivables.TCS"},
                                {"queryRef": "CashReceivables.Service Charge to MSTC"},
                                {"queryRef": "CashReceivables.GST TDS"}
                            ]
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 470.0, "z": 2.0, "width": 780.0, "height": 230.0,
                "config": json.dumps({
                    "name": "TableGstTds",
                    "singleVisual": {
                        "visualType": "tableEx",
                        "projections": {
                            "Values": [
                                {"queryRef": "CashReceivables.Lot No"},
                                {"queryRef": "CashReceivables.Buyer"},
                                {"queryRef": "CashReceivables.Material Value"},
                                {"queryRef": "CashReceivables.GST TDS Rate"},
                                {"queryRef": "CashReceivables.GST TDS"},
                                {"queryRef": "CashReceivables.Total Receivables"}
                            ]
                        }
                    }
                })
            },
            {
                "x": 820.0, "y": 75.0, "z": 3.0, "width": 440.0, "height": 625.0,
                "config": json.dumps({
                    "name": "MatrixStatSummary",
                    "singleVisual": {
                        "visualType": "tableEx",
                        "projections": {
                            "Values": [
                                {"queryRef": "CashReceivables.Buyer"},
                                {"queryRef": "CashReceivables.GST"},
                                {"queryRef": "CashReceivables.TCS"},
                                {"queryRef": "CashReceivables.MSTC Service Charge"},
                                {"queryRef": "CashReceivables.GST TDS"}
                            ]
                        }
                    }
                })
            }
        ]
    },
    {
        "id": 3,
        "name": "ReportSection_LotLedger",
        "displayName": "Master Lot Ledger (Live Grid)",
        "filters": "[]",
        "ordinal": 3,
        "width": 1280.0,
        "height": 720.0,
        "visualContainers": [
            {
                "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 45.0,
                "config": json.dumps({
                    "name": "TitleLedger",
                    "singleVisual": {
                        "visualType": "textbox",
                        "objects": {
                            "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Master Lot Details Ledger (All 37 Scrap Lots)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                        }
                    }
                })
            },
            {
                "x": 20.0, "y": 70.0, "z": 1.0, "width": 1240.0, "height": 630.0,
                "config": json.dumps({
                    "name": "FullLotTable",
                    "singleVisual": {
                        "visualType": "tableEx",
                        "projections": {
                            "Values": [
                                {"queryRef": "CashReceivables.Lot No"},
                                {"queryRef": "CashReceivables.Auction"},
                                {"queryRef": "CashReceivables.Buyer"},
                                {"queryRef": "CashReceivables.Lot Name"},
                                {"queryRef": "CashReceivables.Qty"},
                                {"queryRef": "CashReceivables.Rate"},
                                {"queryRef": "CashReceivables.Material Value"},
                                {"queryRef": "CashReceivables.GST"},
                                {"queryRef": "CashReceivables.Total Receivables"},
                                {"queryRef": "CashReceivables.SD Received"},
                                {"queryRef": "CashReceivables.SD Date"},
                                {"queryRef": "CashReceivables.FP Received"},
                                {"queryRef": "CashReceivables.FP Date"},
                                {"queryRef": "CashReceivables.Late Fee"},
                                {"queryRef": "CashReceivables.Total Received"},
                                {"queryRef": "CashReceivables.Outstanding"},
                                {"queryRef": "CashReceivables.Settlement Status"}
                            ]
                        }
                    }
                })
            }
        ]
    }
]

layout_dict = {
    "id": 0,
    "resourcePackages": [
        {
            "resourcePackage": {
                "name": "SharedResources",
                "type": 1,
                "items": [
                    {"name": "BaseThemes/CY24SU08.json", "path": "BaseThemes/CY24SU08.json", "type": 201}
                ]
            }
        }
    ],
    "sections": sections
}

content_types_xml = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="json" ContentType="application/json" />
  <Default Extension="xml" ContentType="application/xml" />
  <Default Extension="png" ContentType="image/png" />
  <Override PartName="/Report/Layout" ContentType="application/json" />
  <Override PartName="/Settings" ContentType="application/json" />
  <Override PartName="/Version" ContentType="application/json" />
  <Override PartName="/DataModelSchema" ContentType="application/json" />
</Types>"""

version_content = "1.28"
settings_json = json.dumps({"ModelVersion": 1550, "ReportVersion": "2.128.0.0"})
theme_json = json.dumps({
    "name": "CY24SU08",
    "dataColors": ["#2563EB", "#0284C7", "#16A34A", "#E11D48", "#6366F1", "#D97706", "#8B5CF6", "#0D9488"],
    "background": "#FFFFFF",
    "foreground": "#1E1B4B",
    "tableAccent": "#2563EB"
})

pbit_path = '/home/user/ScrapSale_Pro_Analytics.pbit'
pbix_path = '/home/user/ScrapSale_Pro_Analytics.pbix'

def create_pbi_archive(target_path):
    with zipfile.ZipFile(target_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', content_types_xml)
        zf.writestr('Version', version_content)
        zf.writestr('Settings', settings_json)
        zf.writestr('DataModelSchema', json.dumps(schema_dict, indent=2))
        zf.writestr('Report/Layout', json.dumps(layout_dict, indent=2))
        zf.writestr('Report/StaticResources/SharedResources/BaseThemes/CY24SU08.json', theme_json)

create_pbi_archive(pbit_path)
print(f"Created Power BI Template: {pbit_path}")

create_pbi_archive(pbix_path)
print(f"Created Power BI Desktop File: {pbix_path}")

print("All Power BI artifacts generated successfully!")
