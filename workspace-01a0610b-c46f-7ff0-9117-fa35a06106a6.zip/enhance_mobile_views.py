import re

def apply_mobile_view_enhancements(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Enhanced Mobile View CSS targeting [data-view-mode="mobile"] and @media (max-width: 768px)
    mobile_modal_css = """
/* ==========================================================================
   MOBILE VIEW ADAPTATIONS: MODALS, FORMS, ADVICE & REPORTS
   ========================================================================== */
[data-view-mode="mobile"] #modalRoot .overlay,
@media (max-width: 768px) {
  #modalRoot .overlay {
    padding: 10px !important;
    align-items: flex-end !important;
  }
}

[data-view-mode="mobile"] .modal,
[data-view-mode="mobile"] .modal.wide,
[data-view-mode="mobile"] .modal.ultra-wide,
@media (max-width: 768px) {
  .modal, .modal.wide, .modal.ultra-wide {
    width: 100% !important;
    max-width: 100% !important;
    max-height: 90vh !important;
    border-radius: 16px 16px 0 0 !important;
    margin: 0 !important;
  }
  .modal-head {
    padding: 12px 16px !important;
  }
  .modal-head h3 {
    font-size: 13.5px !important;
  }
  .modal-body {
    padding: 12px 14px !important;
    max-height: calc(90vh - 110px) !important;
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
  }
  .modal-foot {
    padding: 10px 14px !important;
    gap: 6px !important;
  }
  .modal-foot .btn {
    flex: 1 1 calc(50% - 6px) !important;
    text-align: center !important;
    justify-content: center !important;
  }
}

/* 1. Buyer Payment Advice Modal on Mobile */
[data-view-mode="mobile"] .buyer-advice-modal,
@media (max-width: 768px) {
  .buyer-advice-modal {
    font-size: 11.5px !important;
  }
  .buyer-advice-modal div[style*="display:flex;justify-content:space-between"] {
    flex-direction: column !important;
    align-items: flex-start !important;
    gap: 8px !important;
  }
  .buyer-advice-modal div[style*="text-align:right"] {
    text-align: left !important;
    width: 100% !important;
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
  }
  .buyer-advice-modal div[style*="grid-template-columns:repeat(auto-fit,minmax(210px,1fr))"] {
    grid-template-columns: 1fr !important;
    gap: 8px !important;
  }
  .buyer-advice-modal div[style*="grid-template-columns:1fr 1fr"] {
    grid-template-columns: 1fr !important;
    gap: 10px !important;
  }
  .buyer-advice-modal .lic-table {
    gap: 3px !important;
  }
  .buyer-advice-modal .lic-row {
    padding: 4px 0 !important;
    font-size: 11px !important;
  }
  .buyer-advice-modal .lic-k {
    font-size: 10.5px !important;
    max-width: 60% !important;
    white-space: normal !important;
    word-break: break-word !important;
  }
  .buyer-advice-modal .lic-v {
    font-size: 11.5px !important;
    max-width: 40% !important;
  }
  .buyer-advice-modal table {
    font-size: 10.5px !important;
  }
  .buyer-advice-modal th, .buyer-advice-modal td {
    padding: 5px 6px !important;
  }
}

/* 2. Add / Edit Lot Form on Mobile */
[data-view-mode="mobile"] .form-grid,
@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr !important;
    gap: 8px !important;
  }
  .form-grid .full,
  .form-grid .span2 {
    grid-column: 1 / -1 !important;
  }
  .form-grid label {
    font-size: 11px !important;
    gap: 3px !important;
  }
  .form-grid input,
  .form-grid select {
    padding: 8px 10px !important;
    font-size: 13px !important;
    border-radius: 8px !important;
  }
  .amt-grid {
    grid-template-columns: 1fr 1fr !important;
    gap: 8px !important;
  }
  .amt-grid .amt-h {
    font-size: 9px !important;
  }
  .form-sec {
    margin: 10px 0 6px !important;
    font-size: 10.5px !important;
  }
}

/* 3. Lot Inspection Detail Modal on Mobile */
[data-view-mode="mobile"] .lot-inspect-wrap,
@media (max-width: 768px) {
  .lot-inspect-kpis {
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 6px !important;
  }
  .lot-inspect-cols {
    grid-template-columns: 1fr !important;
    gap: 8px !important;
  }
  .lot-inspect-col {
    padding: 8px 10px !important;
  }
  .lot-kpi-card {
    padding: 6px 8px !important;
  }
  .lot-kpi-card .lk-val {
    font-size: 12px !important;
  }
}

/* 4. Date Picker on Mobile */
[data-view-mode="mobile"] #datePickerPopup,
@media (max-width: 768px) {
  #datePickerPopup {
    position: fixed !important;
    top: 50% !important;
    left: 50% !important;
    transform: translate(-50%, -50%) !important;
    width: min(300px, 92vw) !important;
    padding: 12px !important;
    border-radius: 16px !important;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7) !important;
  }
  .dt-day-btn {
    height: 32px !important;
    line-height: 32px !important;
    font-size: 12px !important;
  }
}

/* 5. Export Grid on Mobile */
[data-view-mode="mobile"] .export-grid,
@media (max-width: 768px) {
  .two-col {
    grid-template-columns: 1fr !important;
  }
  .export-grid {
    grid-template-columns: 1fr !important;
    gap: 8px !important;
  }
  .export-card {
    padding: 10px !important;
  }
}

/* 6. Calculation HUD Toolbar on Mobile */
[data-view-mode="mobile"] .excel-calc-hud,
@media (max-width: 768px) {
  .excel-calc-hud {
    padding: 4px 8px !important;
    gap: 6px !important;
    border-radius: 10px !important;
    max-width: 95vw !important;
  }
  .excel-calc-hud .calc-lbl {
    font-size: 8px !important;
  }
  .excel-calc-hud .calc-val {
    font-size: 11px !important;
  }
  .excel-calc-hud .calc-copy-all-btn,
  .excel-calc-hud .calc-close-btn {
    padding: 3px 6px !important;
    font-size: 10px !important;
  }
}
"""

    if '/* ==========================================================================\n   MOBILE VIEW ADAPTATIONS' not in content:
        content = content.replace('/* Theme Toggle Button Component */', mobile_modal_css + '\n/* Theme Toggle Button Component */')

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Mobile adaptations applied to {file_path}")

apply_mobile_view_enhancements('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
apply_mobile_view_enhancements('/home/user/index.html')
apply_mobile_view_enhancements('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
