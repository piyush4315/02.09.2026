import re

def enhance_theme_rightclick(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Add Dark Theme CSS for .xl-stats and enhanced context menu items
    dark_stats_css = """
/* Context Menu Column Stats (Dark Theme) */
.excel-menu .xl-stats {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 10px;
  background: rgba(0, 0, 0, 0.25);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.excel-menu .xl-stat-box {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 5px 7px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
  min-width: 0;
}
.excel-menu .xl-stat-box:hover {
  background: rgba(0, 245, 255, 0.08);
  border-color: rgba(0, 245, 255, 0.35);
}
.excel-menu .xl-stat-lbl {
  font-size: 8.5px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--dim);
  line-height: 1;
}
.excel-menu .xl-stat-val {
  font-size: 11.5px;
  font-weight: 800;
  color: #ffffff;
  font-variant-numeric: tabular-nums;
  margin-top: 2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.excel-menu .xl-stat-val.accent {
  color: var(--cyan);
}
"""

    if '.excel-menu .xl-stats' not in content:
        content = content.replace(
            '.excel-menu .xl-actions{padding:6px;flex:0 0 auto}',
            '.excel-menu .xl-actions{padding:6px;flex:0 0 auto}\n' + dark_stats_css
        )

    # 2. Add Comprehensive Light Theme CSS for right-click context menu, filter form, SUM stats, HUD, and popups
    light_ctx_css = """
/* ==========================================================================
   LIGHT THEME: RIGHT-CLICK MENUS, FILTER FORMS, STATS & CALCULATION HUD
   ========================================================================== */
[data-theme="light"] .col-menu,
[data-theme="light"] #thCtxMenu.excel-menu,
[data-theme="light"] #invContextMenu {
  background: #ffffff !important;
  border: 1px solid #cbd5e1 !important;
  box-shadow: 0 16px 36px -4px rgba(15, 23, 42, 0.14), 0 4px 12px rgba(15, 23, 42, 0.06) !important;
  color: #0f172a !important;
}

[data-theme="light"] .excel-menu .xl-head {
  background: #f8fafc !important;
  border-bottom: 1px solid #e2e8f0 !important;
  color: #0f172a !important;
  font-weight: 800 !important;
}

[data-theme="light"] .excel-menu .xl-stats {
  background: #f8fafc !important;
  border-bottom: 1px solid #e2e8f0 !important;
}

[data-theme="light"] .excel-menu .xl-stat-box {
  background: #ffffff !important;
  border: 1px solid #cbd5e1 !important;
}

[data-theme="light"] .excel-menu .xl-stat-box:hover {
  background: #eff6ff !important;
  border-color: #93c5fd !important;
}

[data-theme="light"] .excel-menu .xl-stat-lbl {
  color: #64748b !important;
}

[data-theme="light"] .excel-menu .xl-stat-val {
  color: #0f172a !important;
}

[data-theme="light"] .excel-menu .xl-stat-val.accent {
  color: #2563eb !important;
}

[data-theme="light"] .excel-menu .xl-actions {
  background: #ffffff !important;
}

[data-theme="light"] .col-menu .cm-item {
  color: #334155 !important;
}

[data-theme="light"] .col-menu .cm-item:hover {
  background: #f1f5f9 !important;
  color: #0f172a !important;
}

[data-theme="light"] .col-menu .cm-item.active {
  background: #eff6ff !important;
  color: #1d4ed8 !important;
  font-weight: 700 !important;
}

[data-theme="light"] .col-menu .cm-item .cm-check {
  color: #2563eb !important;
}

[data-theme="light"] .col-menu .cm-item .cm-hint {
  color: #64748b !important;
}

[data-theme="light"] .col-menu .cm-item.disabled {
  opacity: 0.4 !important;
  color: #94a3b8 !important;
}

[data-theme="light"] .excel-menu .xl-divider,
[data-theme="light"] #invContextMenu .inv-ctx-divider {
  background: #e2e8f0 !important;
}

[data-theme="light"] .excel-menu .xl-filter {
  background: #ffffff !important;
  border-top: 1px solid #e2e8f0 !important;
}

[data-theme="light"] .excel-menu .xl-filter-title {
  color: #475569 !important;
}

[data-theme="light"] .excel-menu .xl-search,
[data-theme="light"] .col-menu .cm-search {
  background: #f8fafc !important;
  border: 1px solid #cbd5e1 !important;
  color: #0f172a !important;
}

[data-theme="light"] .excel-menu .xl-search::placeholder,
[data-theme="light"] .col-menu .cm-search::placeholder {
  color: #94a3b8 !important;
}

[data-theme="light"] .excel-menu .xl-search:focus,
[data-theme="light"] .col-menu .cm-search:focus {
  border-color: #2563eb !important;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.15) !important;
  background: #ffffff !important;
}

[data-theme="light"] .excel-menu .xl-select-tools {
  background: transparent !important;
}

[data-theme="light"] .excel-menu .xl-mini {
  background: #f1f5f9 !important;
  border: 1px solid #cbd5e1 !important;
  color: #475569 !important;
}

[data-theme="light"] .excel-menu .xl-mini:hover {
  background: #e2e8f0 !important;
  border-color: #94a3b8 !important;
  color: #0f172a !important;
}

[data-theme="light"] .excel-menu .xl-values {
  background: #f8fafc !important;
  border: 1px solid #e2e8f0 !important;
}

[data-theme="light"] .excel-menu .xl-value {
  color: #334155 !important;
}

[data-theme="light"] .excel-menu .xl-value:hover {
  background: #eff6ff !important;
  color: #0f172a !important;
}

[data-theme="light"] .excel-menu .xl-value input[type="checkbox"] {
  accent-color: #2563eb !important;
}

[data-theme="light"] .excel-menu .xl-only {
  background: #eff6ff !important;
  border: 1px solid #bfdbfe !important;
  color: #2563eb !important;
}

[data-theme="light"] .excel-menu .xl-value:hover .xl-only,
[data-theme="light"] .excel-menu .xl-only:focus {
  background: #dbeafe !important;
  border-color: #93c5fd !important;
}

[data-theme="light"] .excel-menu .xl-match-count {
  color: #64748b !important;
}

[data-theme="light"] .excel-menu .xl-no-values {
  color: #94a3b8 !important;
}

/* Light Theme Invoice Context Menu */
[data-theme="light"] #invContextMenu .inv-ctx-item {
  color: #334155 !important;
}

[data-theme="light"] #invContextMenu .inv-ctx-item:hover {
  background: #f1f5f9 !important;
  color: #0f172a !important;
}

/* Light Theme Calculation HUD (SUM & COUNT Bar) */
[data-theme="light"] .excel-calc-hud {
  background: rgba(255, 255, 255, 0.98) !important;
  border: 1px solid #cbd5e1 !important;
  box-shadow: 0 12px 32px -4px rgba(15, 23, 42, 0.16), 0 2px 6px rgba(15, 23, 42, 0.08) !important;
}

[data-theme="light"] .excel-calc-hud .calc-item:hover {
  background: #f1f5f9 !important;
}

[data-theme="light"] .excel-calc-hud .calc-lbl {
  color: #64748b !important;
}

[data-theme="light"] .excel-calc-hud .calc-val {
  color: #0f172a !important;
}

[data-theme="light"] .excel-calc-hud .calc-val.accent {
  color: #2563eb !important;
  text-shadow: none !important;
}

[data-theme="light"] .excel-calc-hud .calc-val.dim {
  color: #94a3b8 !important;
}

[data-theme="light"] .excel-calc-hud .calc-divider {
  background: #e2e8f0 !important;
}

[data-theme="light"] .excel-calc-hud .calc-copy-all-btn {
  background: #f8fafc !important;
  border: 1px solid #cbd5e1 !important;
  color: #334155 !important;
}

[data-theme="light"] .excel-calc-hud .calc-copy-all-btn:hover {
  background: #eff6ff !important;
  border-color: #93c5fd !important;
  color: #1d4ed8 !important;
}

[data-theme="light"] .excel-calc-hud .calc-close-btn {
  background: #f8fafc !important;
  border: 1px solid #cbd5e1 !important;
  color: #64748b !important;
}

[data-theme="light"] .excel-calc-hud .calc-close-btn:hover {
  background: #fee2e2 !important;
  border-color: #fca5a5 !important;
  color: #dc2626 !important;
}

/* Light Theme Column Picker & Field Chooser */
[data-theme="light"] .col-picker-panel,
[data-theme="light"] #fieldChooser {
  background: #ffffff !important;
  border: 1px solid #cbd5e1 !important;
  box-shadow: 0 16px 36px -4px rgba(15, 23, 42, 0.14) !important;
}

[data-theme="light"] .col-picker-head {
  background: #f8fafc !important;
  border-bottom: 1px solid #e2e8f0 !important;
  color: #0f172a !important;
}

[data-theme="light"] .col-row:hover {
  background: #f1f5f9 !important;
}
"""

    if 'LIGHT THEME: RIGHT-CLICK MENUS, FILTER FORMS, STATS & CALCULATION HUD' not in content:
        content = content.replace('/* Theme Toggle Button Component */', light_ctx_css + '\n/* Theme Toggle Button Component */')

    # 3. Enhance showHeaderContextMenu in JavaScript to compute and display Column Stats (SUM, AVG, COUNT)
    old_menu_construction = """    var values = colDistinctValues(field, tableKind);
    var current = colFilterKeys(filterKey);
    var draft = new Set(current === null ? [] : current);
    var filterHtml =
      '<div class="xl-filter">' +
        '<div class="xl-filter-title"><span>Filter by values</span>' + (hasFilter ? '<span style="color:var(--cyan)">● active</span>' : '') + '</div>' +
        '<input type="search" class="xl-search" placeholder="Search values…" autocomplete="off"/>' +
        '<div class="xl-select-tools">' +
          '<button type="button" class="xl-mini" data-act="selectall">Select all</button>' +
          '<button type="button" class="xl-mini" data-act="clearall">Clear all</button>' +
        '</div>' +
        '<div class="xl-values"></div>' +
        '<div class="xl-filter-foot">' +
          '<span class="xl-match-count"></span>' +
          '<button type="button" class="btn" data-act="clearfilter"' + (!hasFilter ? ' disabled' : '') + '>Clear filter</button>' +
          '<button type="button" class="btn" data-act="cancel">Cancel</button>' +
          '<button type="button" class="btn primary" data-act="applyfilter">Apply</button>' +
        '</div>' +
      '</div>';

    menu.innerHTML = actions + filterHtml;"""

    new_menu_construction = """    // Calculate column summary statistics (SUM, AVG, COUNT) for context menu
    var numSum = 0, numCount = 0, hasNumeric = false;
    var rowsToScan = isDetail ? detailRows : (typeof pivotRows !== 'undefined' ? pivotRows : lots);
    if (rowsToScan && rowsToScan.length) {
      rowsToScan.forEach(function (r) {
        if (!r) return;
        var val = r[field];
        if (val !== undefined && val !== null && val !== '') {
          var n = Number(val);
          if (!isNaN(n) && typeof val !== 'boolean') {
            numSum += n;
            numCount++;
            hasNumeric = true;
          }
        }
      });
    }

    var isMoney = typeof MONEY_FIELDS !== 'undefined' && MONEY_FIELDS.has(field);
    var isNum = typeof NUM_FIELDS !== 'undefined' && (NUM_FIELDS.indexOf(field) !== -1 || field === 'qty' || field === 'rate' || field === 'gst_tds_rate' || field === 'lots');
    var statsHtml = '';
    if (hasNumeric && (isMoney || isNum || numCount > 0)) {
      var avg = numCount > 0 ? (numSum / numCount) : 0;
      var sumDisp = isMoney ? ('₹ ' + inr(Math.round(numSum))) : numFmt(Math.round(numSum * 100) / 100);
      var avgDisp = isMoney ? ('₹ ' + inr(Math.round(avg))) : numFmt(Math.round(avg * 100) / 100);
      statsHtml =
        '<div class="xl-stats">' +
          '<div class="xl-stat-box" data-copy="' + numSum + '" title="Click to copy Column SUM (' + escHtml(sumDisp) + ')">' +
            '<span class="xl-stat-lbl">SUM</span>' +
            '<span class="xl-stat-val accent">' + escHtml(sumDisp) + '</span>' +
          '</div>' +
          '<div class="xl-stat-box" data-copy="' + (Math.round(avg * 100) / 100) + '" title="Column Average (' + escHtml(avgDisp) + ')">' +
            '<span class="xl-stat-lbl">AVG</span>' +
            '<span class="xl-stat-val">' + escHtml(avgDisp) + '</span>' +
          '</div>' +
          '<div class="xl-stat-box" title="Rows with values">' +
            '<span class="xl-stat-lbl">COUNT</span>' +
            '<span class="xl-stat-val">' + numCount + '</span>' +
          '</div>' +
        '</div>';
    } else {
      statsHtml =
        '<div class="xl-stats">' +
          '<div class="xl-stat-box" title="Total rows">' +
            '<span class="xl-stat-lbl">TOTAL ROWS</span>' +
            '<span class="xl-stat-val accent">' + (rowsToScan ? rowsToScan.length : 0) + '</span>' +
          '</div>' +
        '</div>';
    }

    var values = colDistinctValues(field, tableKind);
    var current = colFilterKeys(filterKey);
    var draft = new Set(current === null ? [] : current);
    var filterHtml =
      '<div class="xl-filter">' +
        '<div class="xl-filter-title"><span>Filter by values</span>' + (hasFilter ? '<span style="color:var(--cyan)">● active</span>' : '') + '</div>' +
        '<input type="search" class="xl-search" placeholder="Search values…" autocomplete="off"/>' +
        '<div class="xl-select-tools">' +
          '<button type="button" class="xl-mini" data-act="selectall">Select all</button>' +
          '<button type="button" class="xl-mini" data-act="clearall">Clear all</button>' +
        '</div>' +
        '<div class="xl-values"></div>' +
        '<div class="xl-filter-foot">' +
          '<span class="xl-match-count"></span>' +
          '<button type="button" class="btn" data-act="clearfilter"' + (!hasFilter ? ' disabled' : '') + '>Clear filter</button>' +
          '<button type="button" class="btn" data-act="cancel">Cancel</button>' +
          '<button type="button" class="btn primary" data-act="applyfilter">Apply</button>' +
        '</div>' +
      '</div>';

    menu.innerHTML = actions + statsHtml + filterHtml;"""

    if old_menu_construction in content:
        content = content.replace(old_menu_construction, new_menu_construction)
        print("Updated showHeaderContextMenu with Column Stats successfully.")
    else:
        print("Warning: old_menu_construction not matched.")

    # 4. Attach click-to-copy handler on stat boxes in context menu
    old_search_listener = "    if (search) search.addEventListener('input', renderValues);"
    new_search_listener = """    if (search) search.addEventListener('input', renderValues);
    menu.querySelectorAll('.xl-stat-box[data-copy]').forEach(function(box) {
      box.addEventListener('click', function(ev) {
        ev.stopPropagation();
        var val = box.getAttribute('data-copy');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(val).then(function() {
            showToast('Copied: ' + val, 'ok');
          });
        }
      });
    });"""

    if old_search_listener in content and "Copied: ' + val" not in content:
        content = content.replace(old_search_listener, new_search_listener)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Enhanced {file_path} successfully.")

enhance_theme_rightclick('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
enhance_theme_rightclick('/home/user/index.html')
enhance_theme_rightclick('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
