const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  
  // 1. Desktop Dashboard View (showing KPI cards, Pivot Analytics table with 13 buyers, and Lot Details)
  const page = await browser.newPage({ viewport: { width: 1440, height: 950 } });
  await page.goto('http://127.0.0.1:8080/', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);
  
  // Desktop view screenshot (Pivot + Lot details)
  await page.screenshot({ path: '/home/user/scrapsale_desktop_proof.png', fullPage: false });
  console.log('Saved: /home/user/scrapsale_desktop_proof.png');

  // Full page desktop screenshot
  await page.screenshot({ path: '/home/user/scrapsale_full_page_proof.png', fullPage: true });
  console.log('Saved: /home/user/scrapsale_full_page_proof.png');

  // 2. Light Theme Screenshot
  await page.click('#themeToggleBtn');
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/home/user/scrapsale_light_theme_proof.png', fullPage: false });
  console.log('Saved: /home/user/scrapsale_light_theme_proof.png');

  // Switch back to Dark Theme
  await page.click('#themeToggleBtn');
  await page.waitForTimeout(300);

  // 3. Mobile View Screenshot
  const mobilePage = await browser.newPage({ viewport: { width: 420, height: 900 } });
  await mobilePage.goto('http://127.0.0.1:8080/', { waitUntil: 'networkidle' });
  await mobilePage.waitForTimeout(600);
  await mobilePage.screenshot({ path: '/home/user/scrapsale_mobile_proof.png', fullPage: false });
  console.log('Saved: /home/user/scrapsale_mobile_proof.png');

  await browser.close();
  console.log('All proof screenshots captured successfully!');
})();
