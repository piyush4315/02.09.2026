const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 950 } });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);

  console.log('=== TEST 1: Hidden Column Buttons (No + icon) ===');
  // Hide some columns in Lot Details and Pivot Analytics
  await page.evaluate(() => {
    colLayout.detail = colLayout.detail.filter(k => k !== 'mat_value' && k !== 'gst');
    colLayout.pivotMetric = colLayout.pivotMetric.filter(k => k !== 'tcs' && k !== 'gst');
    renderAll();
  });
  await page.waitForTimeout(300);

  const detailToggleBtns = await page.$$eval('#dashColToggles .col-toggle.off', els => els.map(el => el.textContent));
  const pivotToggleBtns = await page.$$eval('#pivotColToggles .col-toggle.off', els => els.map(el => el.textContent));

  console.log('Lot Details Hidden Buttons:', detailToggleBtns);
  console.log('Pivot Analytics Hidden Buttons:', pivotToggleBtns);

  const hasPlusIcon = detailToggleBtns.concat(pivotToggleBtns).some(txt => txt.includes('+') || txt.includes('＋'));
  if (hasPlusIcon) {
    console.error('FAIL: Found + icon in hidden buttons!');
    process.exit(1);
  } else {
    console.log('PASS: No + icon in any hidden column button!');
  }

  console.log('\n=== TEST 2: Color grading of Settled/Unsettled chips (Pivot vs Lot Details) ===');
  // Compare Dark Mode
  const darkComparison = await page.evaluate(() => {
    const lotSettledPill = document.querySelector('#detailTableDash .lbl-settled');
    const pivotSettledSeg = document.querySelector('#pivotTable .seg.s');
    const lotUnsettledPill = document.querySelector('#detailTableDash .lbl-unsettled');
    const pivotUnsettledSeg = document.querySelector('#pivotTable .seg.u');

    return {
      lotSettled: lotSettledPill ? {
        bg: getComputedStyle(lotSettledPill).backgroundImage,
        color: getComputedStyle(lotSettledPill).color,
        fontSize: getComputedStyle(lotSettledPill).fontSize,
        borderRadius: getComputedStyle(lotSettledPill).borderRadius
      } : null,
      pivotSettled: pivotSettledSeg ? {
        bg: getComputedStyle(pivotSettledSeg).backgroundImage,
        color: getComputedStyle(pivotSettledSeg).color,
        fontSize: getComputedStyle(pivotSettledSeg).fontSize,
        borderRadius: getComputedStyle(pivotSettledSeg).borderRadius
      } : null,
      lotUnsettled: lotUnsettledPill ? {
        bg: getComputedStyle(lotUnsettledPill).backgroundColor,
        color: getComputedStyle(lotUnsettledPill).color,
        fontSize: getComputedStyle(lotUnsettledPill).fontSize,
        borderRadius: getComputedStyle(lotUnsettledPill).borderRadius
      } : null,
      pivotUnsettled: pivotUnsettledSeg ? {
        bg: getComputedStyle(pivotUnsettledSeg).backgroundColor,
        color: getComputedStyle(pivotUnsettledSeg).color,
        fontSize: getComputedStyle(pivotUnsettledSeg).fontSize,
        borderRadius: getComputedStyle(pivotUnsettledSeg).borderRadius
      } : null
    };
  });
  console.log('Dark Mode Chip Comparison:', JSON.stringify(darkComparison, null, 2));

  // Compare Light Mode
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'light'));
  await page.waitForTimeout(300);

  const lightComparison = await page.evaluate(() => {
    const lotSettledPill = document.querySelector('#detailTableDash .lbl-settled');
    const pivotSettledSeg = document.querySelector('#pivotTable .seg.s');
    const lotUnsettledPill = document.querySelector('#detailTableDash .lbl-unsettled');
    const pivotUnsettledSeg = document.querySelector('#pivotTable .seg.u');

    return {
      lotSettled: lotSettledPill ? {
        bg: getComputedStyle(lotSettledPill).backgroundColor,
        color: getComputedStyle(lotSettledPill).color,
        border: getComputedStyle(lotSettledPill).border
      } : null,
      pivotSettled: pivotSettledSeg ? {
        bg: getComputedStyle(pivotSettledSeg).backgroundColor,
        color: getComputedStyle(pivotSettledSeg).color,
        border: getComputedStyle(pivotSettledSeg).border
      } : null,
      lotUnsettled: lotUnsettledPill ? {
        bg: getComputedStyle(lotUnsettledPill).backgroundColor,
        color: getComputedStyle(lotUnsettledPill).color,
        border: getComputedStyle(lotUnsettledPill).border
      } : null,
      pivotUnsettled: pivotUnsettledSeg ? {
        bg: getComputedStyle(pivotUnsettledSeg).backgroundColor,
        color: getComputedStyle(pivotUnsettledSeg).color,
        border: getComputedStyle(pivotUnsettledSeg).border
      } : null
    };
  });
  console.log('Light Mode Chip Comparison:', JSON.stringify(lightComparison, null, 2));

  console.log('\n=== TEST 3: Uniform Color Grading of Settled Rows in Lot Details ===');
  // Check Light Mode settled row cells
  const lightSettledRowCells = await page.evaluate(() => {
    const tr = document.querySelector('#detailTableDash tbody tr.settled');
    if (!tr) return null;
    const cells = Array.from(tr.querySelectorAll('td')).map(td => ({
      field: td.dataset.field || 'action',
      cls: td.className,
      color: getComputedStyle(td).color,
      isStatus: td.classList.contains('status')
    }));
    return cells;
  });
  console.log('Light Mode Settled Row Cells sample:');
  lightSettledRowCells.forEach(c => {
    if (!c.isStatus && c.field !== 'action') {
      console.log(`  Field [${c.field}] class [${c.cls}] -> color: ${c.color}`);
    }
  });

  // Check Dark Mode settled row cells
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
  await page.waitForTimeout(300);

  const darkSettledRowCells = await page.evaluate(() => {
    const tr = document.querySelector('#detailTableDash tbody tr.settled');
    if (!tr) return null;
    const cells = Array.from(tr.querySelectorAll('td')).map(td => ({
      field: td.dataset.field || 'action',
      cls: td.className,
      color: getComputedStyle(td).color,
      isStatus: td.classList.contains('status')
    }));
    return cells;
  });
  console.log('\nDark Mode Settled Row Cells sample:');
  darkSettledRowCells.forEach(c => {
    if (!c.isStatus && c.field !== 'action') {
      console.log(`  Field [${c.field}] class [${c.cls}] -> color: ${c.color}`);
    }
  });

  // Verify non-status cells have identical color
  const nonStatusDarkColors = new Set(darkSettledRowCells.filter(c => !c.isStatus && c.field !== 'action').map(c => c.color));
  const nonStatusLightColors = new Set(lightSettledRowCells.filter(c => !c.isStatus && c.field !== 'action').map(c => c.color));

  console.log('\nDistinct dark text colors across settled row non-status cells:', Array.from(nonStatusDarkColors));
  console.log('Distinct light text colors across settled row non-status cells:', Array.from(nonStatusLightColors));

  if (nonStatusDarkColors.size === 1 && nonStatusLightColors.size === 1) {
    console.log('\nPASS: All non-status cells in settled rows have 100% UNIFORM color grading!');
  } else {
    console.error('\nFAIL: Non-uniform colors found in settled row cells!');
    process.exit(1);
  }

  // Take screenshot proofs
  await page.screenshot({ path: '/home/user/settled_rows_dark_proof.png' });
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'light'));
  await page.waitForTimeout(200);
  await page.screenshot({ path: '/home/user/settled_rows_light_proof.png' });
  console.log('Saved screenshots.');

  await browser.close();
})();
