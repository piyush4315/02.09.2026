Attribute VB_Name = "ScrapSale_Pro_VBA_Suite"
Option Explicit

' ==============================================================================
' ScrapSale Pro — Advanced VBA Automation Suite
' Live Calculations | Delayed Payment Charges | Column Toggles | Calendar Date Picker | AutoFilter & Reset
' ==============================================================================

#If VBA7 Then
    Private Declare PtrSafe Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
    Private Type POINTAPI
        x As Long
        y As Long
    End Type
#End If

' ------------------------------------------------------------------------------
' 1. RESET ALL FILTERS & RESTORE VIEW
' ------------------------------------------------------------------------------
Public Sub ResetAllFilters()
    ' Keyboard Shortcut: Ctrl + Shift + R
    ' Clears all active filters, unhides all rows and columns (A:AF), and restores full view
    Dim ws As Worksheet
    Dim wsPivot As Worksheet
    
    On Error GoTo ErrHandler
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    
    ' 1. Reset Lot Details Sheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    If ws.AutoFilterMode Then
        If ws.FilterMode Then ws.ShowAllData
    Else
        ws.Range("A3:AF40").AutoFilter
    End If
    
    ' Reveal all columns (Qty, Rate, Lot Name, MSTC SC Breakdown, Delayed Payment Charges)
    ws.Columns("A:AF").Hidden = False
    ws.Rows("4:45").Hidden = False
    
    ' 2. Reset Pivot Analytics Sheet
    On Error Resume Next
    Set wsPivot = ThisWorkbook.Sheets("Pivot Analytics")
    If Not wsPivot Is Nothing Then
        If wsPivot.FilterMode Then wsPivot.ShowAllData
        wsPivot.Columns("A:N").Hidden = False
    End If
    On Error GoTo ErrHandler
    
    ws.Activate
    ws.Range("A4").Select
    
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    
    MsgBox "All filters and column views have been successfully reset!" & vbCrLf & _
           "Showing all 37 scrap lots and full statutory breakdown with Delayed Payment Charges.", vbInformation, "ScrapSale Pro — Reset Filters"
    Exit Sub

ErrHandler:
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    MsgBox "Error resetting filters: " & Err.Description, vbExclamation, "Reset Error"
End Sub

' ------------------------------------------------------------------------------
' 2. COLUMN TOGGLE FUNCTIONS
' ------------------------------------------------------------------------------
Public Sub ToggleLotColumns()
    ' Keyboard Shortcut: Ctrl + Shift + L
    ' Toggles visibility of Columns A:C (Qty, Rate, Lot Name) under Column D (Bid Sheet)
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    Application.ScreenUpdating = False
    Dim isHidden As Boolean
    isHidden = ws.Columns("A").Hidden
    
    ws.Columns("A:C").Hidden = Not isHidden
    Application.ScreenUpdating = True
    
    If Not isHidden Then
        MsgBox "Columns 1–3 (Qty, Rate, Lot Name) collapsed under Bid Sheet.", vbInformation, "Column Toggle"
    Else
        MsgBox "Columns 1–3 (Qty, Rate, Lot Name) expanded.", vbInformation, "Column Toggle"
    End If
End Sub

Public Sub ToggleChargeColumns()
    ' Keyboard Shortcut: Ctrl + Shift + M
    ' Toggles visibility of Columns M:O (SC 2.25%, TDS 194H, Net SC 2.71%)
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    Application.ScreenUpdating = False
    Dim isHidden As Boolean
    isHidden = ws.Columns("M").Hidden
    
    ws.Columns("M:O").Hidden = Not isHidden
    Application.ScreenUpdating = True
    
    If Not isHidden Then
        MsgBox "MSTC Service Charge bifurcation columns (12–15) collapsed.", vbInformation, "Column Toggle"
    Else
        MsgBox "MSTC Service Charge bifurcation columns expanded.", vbInformation, "Column Toggle"
    End If
End Sub

Public Sub ToggleSettledUnsettled()
    ' Cycles through: All Lots -> Unsettled Only -> Settled Only
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    
    Dim curFilter As String
    On Error Resume Next
    curFilter = ws.AutoFilter.Filters(29).Criteria1
    On Error GoTo 0
    
    If curFilter = "=Unsettled" Then
        ws.Range("A3:AF40").AutoFilter Field:=29, Criteria1:="Settled"
        MsgBox "Displaying: SETTLED LOTS ONLY", vbInformation, "Status Filter"
    ElseIf curFilter = "=Settled" Then
        If ws.FilterMode Then ws.ShowAllData
        MsgBox "Displaying: ALL LOTS", vbInformation, "Status Filter"
    Else
        ws.Range("A3:AF40").AutoFilter Field:=29, Criteria1:="Unsettled"
        MsgBox "Displaying: UNSETTLED LOTS ONLY (Outstanding Balance Due)", vbInformation, "Status Filter"
    End If
End Sub

' ------------------------------------------------------------------------------
' 3. POPUP CALENDAR & DATE SELECTION FUNCTIONS
' ------------------------------------------------------------------------------
Public Sub OpenCalendarPicker()
    ' Defaults to the CURRENT MONTH and YEAR for fast 1-click date picking
    Dim targetCell As Range
    Set targetCell = ActiveCell
    
    Dim curMonth As Long, curYear As Long, curDay As Long
    curMonth = Month(Date)
    curYear = Year(Date)
    curDay = Day(Date)
    
    If IsDate(targetCell.Value) Then
        curMonth = Month(targetCell.Value)
        curYear = Year(targetCell.Value)
        curDay = Day(targetCell.Value)
    End If
    
    Dim monthNameStr As String
    monthNameStr = MonthName(curMonth) & " " & curYear
    
    Dim promptMsg As String
    promptMsg = "ScrapSale Pro — Calendar Date Picker" & vbCrLf & _
                "====================================" & vbCrLf & _
                "Current Month: " & UCase(monthNameStr) & vbCrLf & _
                "Today's Date : " & Format(Date, "DD.MM.YYYY") & vbCrLf & vbCrLf & _
                "Enter Day (1–" & Day(DateSerial(curYear, curMonth + 1, 0)) & ") to select in current month," & vbCrLf & _
                "or enter full date (DD.MM.YYYY), or click OK for Today:"
                
    Dim inputVal As String
    inputVal = InputBox(promptMsg, "Calendar Date Picker (" & monthNameStr & ")", curDay)
    
    If Trim(inputVal) = "" Then Exit Sub
    
    Dim finalDateStr As String
    If IsNumeric(inputVal) And Val(inputVal) >= 1 And Val(inputVal) <= 31 Then
        Dim chosenDay As Long
        chosenDay = Val(inputVal)
        Dim maxDays As Long
        maxDays = Day(DateSerial(curYear, curMonth + 1, 0))
        If chosenDay > maxDays Then chosenDay = maxDays
        finalDateStr = Format(DateSerial(curYear, curMonth, chosenDay), "DD.MM.YYYY")
    ElseIf IsDate(inputVal) Then
        finalDateStr = Format(CDate(inputVal), "DD.MM.YYYY")
    Else
        finalDateStr = inputVal
    End If
    
    targetCell.Value = finalDateStr
    targetCell.NumberFormat = "@"
End Sub

Public Sub StampTodayDate()
    ' Keyboard Shortcut: Ctrl + Shift + D
    ' Stamps today's date in DD.MM.YYYY format into the active cell
    ActiveCell.Value = Format(Date, "DD.MM.YYYY")
    ActiveCell.NumberFormat = "@"
End Sub

Public Sub ClearDateCell()
    ' Clears date to dash '—'
    ActiveCell.Value = "—"
    ActiveCell.NumberFormat = "@"
End Sub

' ------------------------------------------------------------------------------
' 4. FILTERING & SEARCH FUNCTIONS
' ------------------------------------------------------------------------------
Public Sub FilterUnsettledLots()
    ' Keyboard Shortcut: Ctrl + Shift + U
    ' Filters table for Unsettled lots
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    ws.Range("A3:AF40").AutoFilter Field:=29, Criteria1:="Unsettled"
    MsgBox "Filter Applied: Unsettled Lots with Pending Balance", vbInformation, "ScrapSale Pro"
End Sub

Public Sub FilterSettledLots()
    ' Keyboard Shortcut: Ctrl + Shift + S
    ' Filters table for Settled lots
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    ws.Range("A3:AF40").AutoFilter Field:=29, Criteria1:="Settled"
    MsgBox "Filter Applied: Settled Lots", vbInformation, "ScrapSale Pro"
End Sub

Public Sub FilterByBuyerPrompt()
    ' Keyboard Shortcut: Ctrl + Shift + B
    ' Prompts user to filter by specific buyer name
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    Dim buyerQuery As String
    buyerQuery = InputBox("Enter Buyer Name to filter (e.g. AL HAMD, RELIABLE, AMBIKA):", "Filter by Buyer Name")
    
    If Trim(buyerQuery) = "" Then Exit Sub
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    ws.Range("A3:AF40").AutoFilter Field:=7, Criteria1:="*" & Trim(buyerQuery) & "*"
End Sub

Public Sub FilterByAuctionPrompt()
    ' Filters table by Auction ID
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    Dim aucQuery As String
    aucQuery = InputBox("Enter Bid Sheet / Auction Number (e.g. 21980, 22005):", "Filter by Auction")
    
    If Trim(aucQuery) = "" Then Exit Sub
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    ws.Range("A3:AF40").AutoFilter Field:=4, Criteria1:="*" & Trim(aucQuery) & "*"
End Sub

Public Sub QuickSearchPrompt()
    ' Universal Search prompt across Buyer, Lot No, Material, Invoice No
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("Lot Details")
    ws.Activate
    
    Dim q As String
    q = InputBox("Enter Search Term (Buyer, Lot No, Material Name, or Invoice No):", "Universal Search")
    If Trim(q) = "" Then Exit Sub
    
    If Not ws.AutoFilterMode Then ws.Range("A3:AF40").AutoFilter
    
    If IsNumeric(q) Then
        ws.Range("A3:AF40").AutoFilter Field:=6, Criteria1:=Val(q)
    Else
        ws.Range("A3:AF40").AutoFilter Field:=7, Criteria1:="*" & Trim(q) & "*"
    End If
End Sub

' ------------------------------------------------------------------------------
' 5. USER DEFINED FUNCTIONS (UDFs) FOR LIVE EXCEL CALCULATION
' ------------------------------------------------------------------------------
Public Function CalculateOutstanding(ByVal totalReceivables As Double, ByVal lateFee As Double, ByVal totalReceived As Double) As Double
    ' Outstanding includes base receivables plus accrued delayed payment charges minus receipts
    CalculateOutstanding = Round(totalReceivables + lateFee - totalReceived, 0)
End Function

Public Function CalculateLateFee(ByVal matValue As Double, ByVal fpDateStr As String, ByVal isSettled As Boolean) As Double
    ' Rule: Delayed Payment Charges @ 1.18% per week or part of week on Material Value from 24th August, 2026
    Dim baseDate As Date
    baseDate = DateSerial(2026, 8, 24)
    
    Dim payDate As Date
    If Trim(fpDateStr) <> "" And Trim(fpDateStr) <> "—" Then
        On Error Resume Next
        payDate = CDate(Replace(fpDateStr, ".", "/"))
        On Error GoTo 0
    End If
    
    If payDate = 0 Then
        If Not isSettled Then
            payDate = DateSerial(2026, 8, 31) ' Current date
        Else
            payDate = baseDate
        End If
    End If
    
    Dim diffDays As Long
    diffDays = payDate - baseDate
    If diffDays <= 0 Then
        CalculateLateFee = 0#
        Exit Function
    End If
    
    Dim weeks As Long
    weeks = Application.WorksheetFunction.RoundUp(diffDays / 7, 0)
    CalculateLateFee = Round(matValue * weeks * 0.0118, 0)
End Function

Public Function CalculateGstTdsRate(ByVal matValue As Double, ByVal unitStr As String) As Double
    ' Default GST TDS rate is 2% when Material Value > 2,50,000 AND Unit is KG or MT
    Dim u As String
    u = UCase(Trim(unitStr))
    
    If matValue > 250000 And (u = "KG" Or u = "MT" Or u = "KGS" Or u = "M.T." Or u = "K.G." Or u = "METRIC TON") Then
        CalculateGstTdsRate = 2#
    Else
        CalculateGstTdsRate = 0#
    End If
End Function

Public Function CalculateMSTCServiceCharge(ByVal matValue As Double) As Double
    ' Net MSTC Service Charge rate is 2.71% of Material Value
    CalculateMSTCServiceCharge = Round(matValue * 0.0271, 0)
End Function

Public Function FormatINR(ByVal numVal As Double) As String
    ' Formats number with Indian comma separation
    FormatINR = "₹ " & Format(numVal, "#,##,##0")
End Function
