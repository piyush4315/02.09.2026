with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update ui initial state
old_ui = "var ui = { groupBy: 'buyer', auction: 'all', settlement: 'all', dashSearch: '', detailSearch: '', freezeDetailField: 'buyer', collapseLotCols: true, collapseChargeCols: true, colFilters: {} };"
new_ui = "var ui = { groupBy: 'buyer', auction: 'all', settlement: 'all', dashSearch: '', detailSearch: '', freezeDetailField: null, freezePivotField: null, collapseLotCols: true, collapseChargeCols: true, colFilters: {} };"
text = text.replace(old_ui, new_ui, 1)

# 2. Update saveState / loadState
text = text.replace(
    "freezeDetailField: ui.freezeDetailField,",
    "freezeDetailField: ui.freezeDetailField, freezePivotField: ui.freezePivotField,"
)
text = text.replace(
    "ui.freezeDetailField = (data.ui.freezeDetailField !== undefined && data.ui.freezeDetailField !== null) ? data.ui.freezeDetailField : 'buyer';",
    "ui.freezeDetailField = data.ui.freezeDetailField || null;\n      ui.freezePivotField = data.ui.freezePivotField || null;"
)

# 3. Add setFreezePivot function
freeze_funcs_old = """function setFreezeDetail(field) {
  if (ui.freezeDetailField === field) ui.freezeDetailField = null;
  else ui.freezeDetailField = field;
  saveState();
  renderDetail();
  /* No scroll adjustment: the sticky pin clamps the frozen block into view at
     the left/right edge from whatever position the table is currently in, so
     toggling freeze never shifts the columns out from under the user's eyes. */
}"""

freeze_funcs_new = """function setFreezeDetail(field) {
  if (ui.freezeDetailField === field) ui.freezeDetailField = null;
  else ui.freezeDetailField = field;
  saveState();
  renderDetail();
  applyFreezePanes(document.getElementById('detailTableDash'));
  showToast(ui.freezeDetailField ? ('Lot Details: Frozen through ' + (fieldLabel(ui.freezeDetailField) || ui.freezeDetailField)) : 'Lot Details: Columns unfrozen.', 'ok');
}

function setFreezePivot(field) {
  if (ui.freezePivotField === field) ui.freezePivotField = null;
  else ui.freezePivotField = field;
  saveState();
  renderPivot();
  applyFreezePanes(document.getElementById('pivotTable'));
  showToast(ui.freezePivotField ? ('Buyer Ledger: Frozen through ' + (fieldLabel(ui.freezePivotField) || ui.freezePivotField)) : 'Buyer Ledger: Columns unfrozen.', 'ok');
}"""

text = text.replace(freeze_funcs_old, freeze_funcs_new, 1)

# 4. Update applyFreezePanes
old_apply_freeze = """function applyFreezePanes(table) {
  if (!table) return;
  var isPivot = (table.id === 'pivotTable');
  var ths = Array.prototype.slice.call(table.querySelectorAll('thead th'));
  var bodyRows = table.querySelectorAll('tbody tr, tfoot tr');
  table.querySelectorAll('.frozen, .frozen-last, .frozen-first').forEach(function (el) {
    el.classList.remove('frozen', 'frozen-last', 'frozen-first');
    el.style.left = '';
    el.style.right = '';
  });

  var fi = -1;
  if (isPivot) {
    if (ui.groupBy === 'default') {
      // In lot-wise pivot view, freeze lot_no and buyer
      fi = Math.min(1, ths.length - 1);
    } else {
      // In grouped pivot view, freeze the group column (buyer, etc.)
      fi = 0;
    }
  } else {
    var field = ui.freezeDetailField || 'buyer';
    ths.forEach(function (th, i) {
      if (th.getAttribute('data-field') === field) fi = i;
    });
    if (fi < 0 && ths.length > 1) {
      // Default to freezing first 2 columns (lot_no and buyer)
      fi = 1;
    }
  }
  if (fi < 0) return;"""

new_apply_freeze = """function applyFreezePanes(table) {
  if (!table) return;
  var isPivot = (table.id === 'pivotTable');
  var ths = Array.prototype.slice.call(table.querySelectorAll('thead th'));
  var bodyRows = table.querySelectorAll('tbody tr, tfoot tr');
  table.querySelectorAll('.frozen, .frozen-last, .frozen-first').forEach(function (el) {
    el.classList.remove('frozen', 'frozen-last', 'frozen-first');
    el.style.left = '';
    el.style.right = '';
  });

  var field = isPivot ? ui.freezePivotField : ui.freezeDetailField;
  if (!field) return; // No columns frozen by default on landing page!

  var fi = -1;
  ths.forEach(function (th, i) {
    var f = th.getAttribute('data-field') || th.getAttribute('data-group');
    if (f === field || (isPivot && field === 'key' && i === 0)) {
      if (fi < 0) fi = i;
    }
  });
  if (fi < 0) return;"""

text = text.replace(old_apply_freeze, new_apply_freeze, 1)

# 5. Update showHeaderContextMenu for Buyer Ledger Analytics freeze action
old_ctx_actions = """    var actions =
      '<div class="xl-head" title="' + escHtml(fieldLabel(field)) + '">Column: ' + escHtml(fieldLabel(field)) + '</div>' +
      '<div class="xl-actions">' +
        (isDetail ?
          '<button type="button" class="cm-item" data-act="freeze"><span class="cm-check">❄</span><span class="cm-label">' + (ui.freezeDetailField === field ? 'Unfreeze columns' : 'Freeze through this column') + '</span></button>' +
          '<button type="button" class="cm-item" data-act="togglelotgroup"><span class="cm-check">' + (ui.collapseLotCols ? '＋' : '−') + '</span><span class="cm-label">' + (ui.collapseLotCols ? 'Expand columns 1–3 (Qty, Rate, Lot Name)' : 'Collapse columns 1–3 under Bid Sheet') + '</span></button>' +
          '<button type="button" class="cm-item" data-act="togglegroup"><span class="cm-check">' + (ui.collapseChargeCols ? '＋' : '−') + '</span><span class="cm-label">' + (ui.collapseChargeCols ? 'Expand bifurcation columns 12–15' : 'Collapse bifurcation columns 12–15') + '</span></button>' +
          '<button type="button" class="cm-item' + (!selectedForBuyer.length ? ' disabled' : '') + '" data-act="consolidatebuyer" title="Move the Ctrl/Shift-selected columns together after Buyer"><span class="cm-check">⇥</span><span class="cm-label">Consolidate ' + selectedForBuyer.length + ' selected column' + (selectedForBuyer.length === 1 ? '' : 's') + ' after Buyer</span></button>' : '') +
        '<button type="button" class="cm-item' + (isSingle ? ' disabled' : '') + '" data-act="hide"><span class="cm-check">✕</span><span class="cm-label">Hide column</span></button>' +
        '<button type="button" class="cm-item" data-act="unhideall"><span class="cm-check">↺</span><span class="cm-label">Unhide all columns</span></button>' +
        '<button type="button" class="cm-item" data-act="resetcols"><span class="cm-check">↺</span><span class="cm-label">Reset column order</span></button>' +
      '</div>';"""

new_ctx_actions = """    var currentFreezeField = isPivot ? ui.freezePivotField : ui.freezeDetailField;
    var freezeBtnLabel = (currentFreezeField === field) ? 'Unfreeze columns' : 'Freeze through this column';
    var actions =
      '<div class="xl-head" title="' + escHtml(fieldLabel(field)) + '">Column: ' + escHtml(fieldLabel(field)) + '</div>' +
      '<div class="xl-actions">' +
        '<button type="button" class="cm-item" data-act="freeze"><span class="cm-check">❄</span><span class="cm-label">' + freezeBtnLabel + '</span></button>' +
        (isDetail ?
          '<button type="button" class="cm-item" data-act="togglelotgroup"><span class="cm-check">' + (ui.collapseLotCols ? '＋' : '−') + '</span><span class="cm-label">' + (ui.collapseLotCols ? 'Expand columns 1–3 (Qty, Rate, Lot Name)' : 'Collapse columns 1–3 under Bid Sheet') + '</span></button>' +
          '<button type="button" class="cm-item" data-act="togglegroup"><span class="cm-check">' + (ui.collapseChargeCols ? '＋' : '−') + '</span><span class="cm-label">' + (ui.collapseChargeCols ? 'Expand bifurcation columns 12–15' : 'Collapse bifurcation columns 12–15') + '</span></button>' +
          '<button type="button" class="cm-item' + (!selectedForBuyer.length ? ' disabled' : '') + '" data-act="consolidatebuyer" title="Move the Ctrl/Shift-selected columns together after Buyer"><span class="cm-check">⇥</span><span class="cm-label">Consolidate ' + selectedForBuyer.length + ' selected column' + (selectedForBuyer.length === 1 ? '' : 's') + ' after Buyer</span></button>' : '') +
        '<button type="button" class="cm-item' + (isSingle ? ' disabled' : '') + '" data-act="hide"><span class="cm-check">✕</span><span class="cm-label">Hide column</span></button>' +
        '<button type="button" class="cm-item" data-act="unhideall"><span class="cm-check">↺</span><span class="cm-label">Unhide all columns</span></button>' +
        '<button type="button" class="cm-item" data-act="resetcols"><span class="cm-check">↺</span><span class="cm-label">Reset column order</span></button>' +
      '</div>';"""

text = text.replace(old_ctx_actions, new_ctx_actions, 1)

# 6. Update context menu freeze click handler
old_ctx_handler = """      if (act === 'freeze') {
        closeHeaderContextMenu(); setFreezeDetail(field);
      }"""

new_ctx_handler = """      if (act === 'freeze') {
        closeHeaderContextMenu();
        if (isPivot) {
          setFreezePivot(field);
        } else {
          setFreezeDetail(field);
        }
      }"""

text = text.replace(old_ctx_handler, new_ctx_handler, 1)

# 7. Update renderColPicker footer for unfreeze in both tables
old_picker_foot = """      (layoutKind === 'detail' ? '<button type="button" class="btn" data-act="unfreeze">' + (ui.freezeDetailField ? 'Unfreeze columns' : 'Freeze: use ⊢ / ⊣ on a header') + '</button>' : '') +"""

new_picker_foot = """      '<button type="button" class="btn" data-act="unfreeze">' + ((layoutKind === 'detail' ? ui.freezeDetailField : ui.freezePivotField) ? 'Unfreeze columns' : 'Freeze: right-click header') + '</button>' +"""

text = text.replace(old_picker_foot, new_picker_foot, 1)

# 8. Update unfreeze action handler in colPicker
old_picker_unfreeze = """      if (act === 'unfreeze') { ui.freezeDetailField = null; saveState(); renderAll(); renderColPicker(panelId, layoutKind); return; }"""

new_picker_unfreeze = """      if (act === 'unfreeze') {
        if (layoutKind === 'detail') ui.freezeDetailField = null;
        else ui.freezePivotField = null;
        saveState();
        renderAll();
        renderColPicker(panelId, layoutKind);
        return;
      }"""

text = text.replace(old_picker_unfreeze, new_picker_unfreeze, 1)

# 9. In init(), ensure no freeze by default on landing page
old_init_reset = """  if (resetBuyerView) {
    ui.groupBy = 'buyer';
    ui.auction = 'all';
    ui.settlement = 'all';
    ui.dashSearch = '';
    ui.detailSearch = '';
    ui.colFilters = {};
    selectedGroup = null;
    buyerViewVersion = 1;
  }"""

new_init_reset = """  if (resetBuyerView) {
    ui.groupBy = 'buyer';
    ui.auction = 'all';
    ui.settlement = 'all';
    ui.dashSearch = '';
    ui.detailSearch = '';
    ui.freezeDetailField = null;
    ui.freezePivotField = null;
    ui.colFilters = {};
    selectedGroup = null;
    buyerViewVersion = 1;
  }"""

text = text.replace(old_init_reset, new_init_reset, 1)

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("Applied unfreeze options for Buyer Ledger Analytics and set default unfrozen state!")
