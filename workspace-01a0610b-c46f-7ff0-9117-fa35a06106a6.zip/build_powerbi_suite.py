import json, zipfile, os, re, datetime
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

print("Starting Power BI Builder Suite...")

# 1. Load data from HTML
with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'var SAMPLE_DATA = (\[.*?\]);', text, re.DOTALL)
if not m:
    raise ValueError("SAMPLE_DATA not found in HTML file")

lots_raw = json.loads(m.group(1))
print(f"Loaded {len(lots_raw)} raw lots.")

# Calculate Late Fee and Outstanding properly for all lots
# Delay weeks = Math.ceil((fp_date - 2026-08-24)/7) on mat_value
base_date = datetime.date(2026, 8, 24)
curr_date = datetime.date(2026, 8, 31)

def parse_dot_date(dstr):
    if not dstr or dstr == '—' or dstr == '-': return None
    try:
        parts = dstr.split('.')
        return datetime.date(int(parts[2]), int(parts[1]), int(parts[0]))
    except Exception:
        return None

processed_lots = []
for idx, r in enumerate(lots_raw, 1):
    unit = r.get('unit', '')
    qty = float(r.get('qty', 0))
    rate = float(r.get('rate', 0))
    auction = int(r.get('auction', 0))
    lot_name = r.get('lot_name', '')
    lot_no = int(r.get('lot_no', 0))
    buyer = r.get('buyer', '')
    mat_value = round(float(r.get('mat_value', qty * rate)))
    gst = round(float(r.get('gst', mat_value * 0.18)))
    mat_value_plus_gst = mat_value + gst
    tcs = round(float(r.get('tcs', 0)))
    tds194o = round(float(r.get('tds194o', mat_value * 0.001)), 2)
    service_charge_mstc = round(float(r.get('service_charge_mstc', 0)), 2)
    tds194h = round(float(r.get('tds194h', 0)), 2)
    net_service_charge = round(float(r.get('net_service_charge', 0)), 2)
    service_charge_to_mstc = round(float(r.get('service_charge_to_mstc', 0)))
    gst_tds_rate = float(r.get('gst_tds_rate', 0))
    gst_tds = round(float(r.get('gst_tds', mat_value * gst_tds_rate / 100)))
    total_receivables = round(mat_value + gst + tcs - tds194o - net_service_charge - gst_tds)
    sd_expected = round(float(r.get('sd_expected', mat_value * 0.25)))
    sd_received = round(float(r.get('sd_received', 0)))
    sd_date = r.get('sd_date', '')
    fp_expected = total_receivables - sd_expected
    fp_received = round(float(r.get('fp_received', 0)))
    fp_date = r.get('fp_date', '')

    # Late Fee calc
    fp_d = parse_dot_date(fp_date)
    late_fee = 0
    if fp_d:
        if fp_d > base_date:
            days = (fp_d - base_date).days
            weeks = (days + 6) // 7
            late_fee = round(mat_value * weeks * 0.01)
    else:
        # Unsettled / unpaid
        unpaid_fp = max(0, fp_expected - fp_received)
        if unpaid_fp > 1:
            days = (curr_date - base_date).days
            weeks = (days + 6) // 7
            late_fee = round(mat_value * weeks * 0.01)

    total_received = sd_received + fp_received
    outstanding = round(total_receivables + late_fee - total_received)
    settlement_status = "Settled" if outstanding <= 1 else "Unsettled"
    invoice_no = r.get('invoice_no', '') or ''
    sap_document_date = r.get('sap_document_date', '') or ''
    doc_invoice_date = r.get('doc_invoice_date', '') or ''

    processed_lots.append({
        'Lot No': lot_no,
        'Auction': auction,
        'Buyer': buyer,
        'Lot Name': lot_name,
        'Unit': unit,
        'Qty': qty,
        'Rate': rate,
        'Material Value': mat_value,
        'GST': gst,
        'Material Value + GST': mat_value_plus_gst,
        'TCS': tcs,
        'TDS 194O': tds194o,
        'MSTC Service Charge': service_charge_mstc,
        'TDS 194H': tds194h,
        'Net Service Charge': net_service_charge,
        'Service Charge to MSTC': service_charge_to_mstc,
        'GST TDS Rate': gst_tds_rate,
        'GST TDS': gst_tds,
        'Total Receivables': total_receivables,
        'SD Expected': sd_expected,
        'SD Received': sd_received,
        'SD Date': sd_date,
        'FP Expected': fp_expected,
        'FP Received': fp_received,
        'FP Date': fp_date,
        'Late Fee': late_fee,
        'Total Received': total_received,
        'Outstanding': outstanding,
        'Settlement Status': settlement_status,
        'Invoice No': invoice_no,
        'SAP Doc No': sap_document_date,
        'Invoice Date': doc_invoice_date
    })

df = pd.DataFrame(processed_lots)
print(f"Processed {len(df)} lots with full financial fields.")

# 2. Save clean Excel & CSV Data Sources for Power BI
excel_path = '/home/user/ScrapSale_Pro_PowerBI_Source.xlsx'
csv_path = '/home/user/ScrapSale_Pro_PowerBI_Source.csv'
df.to_csv(csv_path, index=False, encoding='utf-8')
print(f"Saved {csv_path}")

# Format Excel Source cleanly
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "CashReceivables"
ws.views.sheetView[0].showGridLines = True

hdr_fill = PatternFill(start_color="1E1B4B", end_color="1E1B4B", fill_type="solid")
hdr_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
thin_border = Border(
    left=Side(style='thin', color='CBD5E1'),
    right=Side(style='thin', color='CBD5E1'),
    top=Side(style='thin', color='CBD5E1'),
    bottom=Side(style='thin', color='CBD5E1')
)

headers = list(df.columns)
ws.append(headers)
for col_num, h in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.fill = hdr_fill
    cell.font = hdr_font
    cell.alignment = Alignment(horizontal="center", vertical="center")

for r_idx, row in df.iterrows():
    row_data = list(row)
    ws.append(row_data)
    curr_r = r_idx + 2
    for c_idx, val in enumerate(row_data, 1):
        cell = ws.cell(row=curr_r, column=c_idx)
        cell.border = thin_border
        cell.font = Font(name="Calibri", size=10)
        # Format numbers
        if isinstance(val, (int, float)) and c_idx not in [1, 2]: # Not lot_no or auction
            if headers[c_idx-1] in ['Material Value', 'GST', 'Material Value + GST', 'TCS', 'Total Receivables', 'SD Expected', 'SD Received', 'FP Expected', 'FP Received', 'Late Fee', 'Total Received', 'Outstanding', 'Service Charge to MSTC', 'GST TDS']:
                cell.number_format = '₹ #,##0'
                cell.alignment = Alignment(horizontal="right")
            elif headers[c_idx-1] in ['TDS 194O', 'MSTC Service Charge', 'TDS 194H', 'Net Service Charge']:
                cell.number_format = '₹ #,##0.00'
                cell.alignment = Alignment(horizontal="right")
            elif headers[c_idx-1] in ['Qty', 'Rate', 'GST TDS Rate']:
                cell.number_format = '#,##0.00' if headers[c_idx-1] != 'Qty' else '#,##0'
                cell.alignment = Alignment(horizontal="right")
        elif headers[c_idx-1] in ['Lot No', 'Auction', 'SD Date', 'FP Date', 'Invoice Date', 'Settlement Status', 'Unit', 'Invoice No', 'SAP Doc No']:
            cell.alignment = Alignment(horizontal="center")
        else:
            cell.alignment = Alignment(horizontal="left")

# Auto-fit columns
for col in ws.columns:
    max_len = max(len(str(cell.value or '')) for cell in col)
    col_letter = get_column_letter(col[0].column)
    ws.column_dimensions[col_letter].width = max(max_len + 3, 11)

wb.save(excel_path)
print(f"Saved formatted Excel data source to {excel_path}")

# 3. Generate DAX Measure Suite Script
dax_content = """/* =========================================================================================
   ScrapSale Pro — Power BI DAX Measures Suite & Business Logic Engine
   Auctions 21977–21980 | MSETCL Cash Receivables Management
   ========================================================================================= */

-- 1. CORE VOLUME & PORTFOLIO METRICS
Total Lots = COUNTROWS('CashReceivables')

Total Buyers = DISTINCTCOUNT('CashReceivables'[Buyer])

Total Auctions = DISTINCTCOUNT('CashReceivables'[Auction])

Total Qty (KG/Units) = SUM('CashReceivables'[Qty])

Average Material Value per Lot = AVERAGE('CashReceivables'[Material Value])

-- 2. REVENUE & STATUTORY MONETARY MEASURES (INR)
Total Material Value = SUM('CashReceivables'[Material Value])

Total GST 18% = SUM('CashReceivables'[GST])

Total Material Value Plus GST = SUM('CashReceivables'[Material Value + GST])

Total TCS 2% = SUM('CashReceivables'[TCS])

Total TDS 194O = SUM('CashReceivables'[TDS 194O])

Total MSTC Service Charge 2.71% = SUM('CashReceivables'[MSTC Service Charge])

Total TDS 194H 2% = SUM('CashReceivables'[TDS 194H])

Total Net Service Charge = SUM('CashReceivables'[Net Service Charge])

Total Service Charge Payable to MSTC = SUM('CashReceivables'[Service Charge to MSTC])

Total GST TDS 2% = SUM('CashReceivables'[GST TDS])

-- 3. CASH RECEIVABLES IN HAND (TRIC & SPLITS)
Total Receivables in Cash (TRIC) = SUM('CashReceivables'[Total Receivables])

Total Security Deposit Expected (SD 25%) = SUM('CashReceivables'[SD Expected])

Total Security Deposit Received = SUM('CashReceivables'[SD Received])

Total Final Payment Expected (FP) = SUM('CashReceivables'[FP Expected])

Total Final Payment Received = SUM('CashReceivables'[FP Received])

Total Cash Received = SUM('CashReceivables'[Total Received])

-- 4. LATE FEE ACCRUAL & OUTSTANDING RISK
Total Late Fee Accrued = SUM('CashReceivables'[Late Fee])

Total Net Outstanding Balance = SUM('CashReceivables'[Outstanding])

Net Amount Payable Now (Incl. Late Fee) = [Total Receivables in Cash (TRIC)] + [Total Late Fee Accrued] - [Total Cash Received]

Collection Efficiency % = DIVIDE([Total Cash Received], [Total Receivables in Cash (TRIC)] + [Total Late Fee Accrued], 0)

-- 5. SETTLEMENT STATUS & AUDIT COUNTS
Settled Lots Count = CALCULATE(COUNTROWS('CashReceivables'), 'CashReceivables'[Settlement Status] = "Settled")

Unsettled Lots Count = CALCULATE(COUNTROWS('CashReceivables'), 'CashReceivables'[Settlement Status] = "Unsettled")

Settlement Rate % = DIVIDE([Settled Lots Count], [Total Lots], 0)

Unsettled Outstanding Exposure = CALCULATE([Total Net Outstanding Balance], 'CashReceivables'[Settlement Status] = "Unsettled")

-- 6. DYNAMIC KPI BADGES & CONDITIONAL FORMATTING
Collection Target Variance = [Collection Efficiency %] - 1.00

Settlement Status Display = [Settled Lots Count] & " Settled / " & [Unsettled Lots Count] & " Unsettled"
"""

with open('/home/user/ScrapSale_Pro_DAX_Measures.dax', 'w', encoding='utf-8') as f:
    f.write(dax_content)
print("Saved /home/user/ScrapSale_Pro_DAX_Measures.dax")

# 4. Generate Power Query M ETL Script
m_script = """// =========================================================================
// ScrapSale Pro — Power Query M ETL Transformation
// =========================================================================
let
    Source = Csv.Document(File.Contents("ScrapSale_Pro_PowerBI_Source.csv"), [Delimiter=",", Columns=32, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{
        {"Lot No", Int64.Type}, 
        {"Auction", Int64.Type}, 
        {"Buyer", type text}, 
        {"Lot Name", type text}, 
        {"Unit", type text}, 
        {"Qty", type number}, 
        {"Rate", type number}, 
        {"Material Value", type number}, 
        {"GST", type number}, 
        {"Material Value + GST", type number}, 
        {"TCS", type number}, 
        {"TDS 194O", type number}, 
        {"MSTC Service Charge", type number}, 
        {"TDS 194H", type number}, 
        {"Net Service Charge", type number}, 
        {"Service Charge to MSTC", type number}, 
        {"GST TDS Rate", type number}, 
        {"GST TDS", type number}, 
        {"Total Receivables", type number}, 
        {"SD Expected", type number}, 
        {"SD Received", type number}, 
        {"SD Date", type text}, 
        {"FP Expected", type number}, 
        {"FP Received", type number}, 
        {"FP Date", type text}, 
        {"Late Fee", type number}, 
        {"Total Received", type number}, 
        {"Outstanding", type number}, 
        {"Settlement Status", type text}, 
        {"Invoice No", type text}, 
        {"SAP Doc No", type text}, 
        {"Invoice Date", type text}
    })
in
    #"Changed Type"
"""
with open('/home/user/ScrapSale_Pro_PowerQuery_ETL.m', 'w', encoding='utf-8') as f:
    f.write(m_script)
print("Saved /home/user/ScrapSale_Pro_PowerQuery_ETL.m")

# 5. BUILD COMPLETE Power BI Template (.pbit) and Desktop File (.pbix)
# Let's construct the Power BI DataModelSchema (TOM / TMSL JSON)
schema_data = {
    "name": "ScrapSale_Pro_Model",
    "compatibilityLevel": 1550,
    "model": {
        "culture": "en-US",
        "dataAccessOptions": {
            "legacyRedirects": True,
            "returnErrorValuesAsNull": True
        },
        "defaultPowerBIDataSourceVersion": "powerBI_V3",
        "sourceQueryCulture": "en-IN",
        "tables": [
            {
                "name": "CashReceivables",
                "columns": [
                    {"name": "Lot No", "dataType": "int64", "formatString": "0", "sourceColumn": "Lot No", "summarizeBy": "none"},
                    {"name": "Auction", "dataType": "int64", "formatString": "0", "sourceColumn": "Auction", "summarizeBy": "none"},
                    {"name": "Buyer", "dataType": "string", "sourceColumn": "Buyer", "summarizeBy": "none"},
                    {"name": "Lot Name", "dataType": "string", "sourceColumn": "Lot Name", "summarizeBy": "none"},
                    {"name": "Unit", "dataType": "string", "sourceColumn": "Unit", "summarizeBy": "none"},
                    {"name": "Qty", "dataType": "double", "formatString": "#,##0", "sourceColumn": "Qty", "summarizeBy": "sum"},
                    {"name": "Rate", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "Rate", "summarizeBy": "average"},
                    {"name": "Material Value", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Material Value", "summarizeBy": "sum"},
                    {"name": "GST", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "GST", "summarizeBy": "sum"},
                    {"name": "Material Value + GST", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Material Value + GST", "summarizeBy": "sum"},
                    {"name": "TCS", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "TCS", "summarizeBy": "sum"},
                    {"name": "TDS 194O", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "TDS 194O", "summarizeBy": "sum"},
                    {"name": "MSTC Service Charge", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "MSTC Service Charge", "summarizeBy": "sum"},
                    {"name": "TDS 194H", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "TDS 194H", "summarizeBy": "sum"},
                    {"name": "Net Service Charge", "dataType": "double", "formatString": "₹ #,##0.00", "sourceColumn": "Net Service Charge", "summarizeBy": "sum"},
                    {"name": "Service Charge to MSTC", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Service Charge to MSTC", "summarizeBy": "sum"},
                    {"name": "GST TDS Rate", "dataType": "double", "formatString": "0.00%", "sourceColumn": "GST TDS Rate", "summarizeBy": "average"},
                    {"name": "GST TDS", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "GST TDS", "summarizeBy": "sum"},
                    {"name": "Total Receivables", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Total Receivables", "summarizeBy": "sum"},
                    {"name": "SD Expected", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "SD Expected", "summarizeBy": "sum"},
                    {"name": "SD Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "SD Received", "summarizeBy": "sum"},
                    {"name": "SD Date", "dataType": "string", "sourceColumn": "SD Date", "summarizeBy": "none"},
                    {"name": "FP Expected", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "FP Expected", "summarizeBy": "sum"},
                    {"name": "FP Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "FP Received", "summarizeBy": "sum"},
                    {"name": "FP Date", "dataType": "string", "sourceColumn": "FP Date", "summarizeBy": "none"},
                    {"name": "Late Fee", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Late Fee", "summarizeBy": "sum"},
                    {"name": "Total Received", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Total Received", "summarizeBy": "sum"},
                    {"name": "Outstanding", "dataType": "double", "formatString": "₹ #,##0", "sourceColumn": "Outstanding", "summarizeBy": "sum"},
                    {"name": "Settlement Status", "dataType": "string", "sourceColumn": "Settlement Status", "summarizeBy": "none"},
                    {"name": "Invoice No", "dataType": "string", "sourceColumn": "Invoice No", "summarizeBy": "none"},
                    {"name": "SAP Doc No", "dataType": "string", "sourceColumn": "SAP Doc No", "summarizeBy": "none"},
                    {"name": "Invoice Date", "dataType": "string", "sourceColumn": "Invoice Date", "summarizeBy": "none"}
                ],
                "partitions": [
                    {
                        "name": "CashReceivables-Partition",
                        "mode": "import",
                        "source": {
                            "type": "m",
                            "expression": [m_script]
                        }
                    }
                ],
                "measures": [
                    {"name": "Total Receivables", "expression": "SUM(CashReceivables[Total Receivables])", "formatString": "₹ #,##0"},
                    {"name": "Total Received", "expression": "SUM(CashReceivables[Total Received])", "formatString": "₹ #,##0"},
                    {"name": "Total Outstanding", "expression": "SUM(CashReceivables[Outstanding])", "formatString": "₹ #,##0"},
                    {"name": "Total Material Value", "expression": "SUM(CashReceivables[Material Value])", "formatString": "₹ #,##0"},
                    {"name": "Total Late Fee", "expression": "SUM(CashReceivables[Late Fee])", "formatString": "₹ #,##0"},
                    {"name": "Collection %", "expression": "DIVIDE([Total Received], [Total Receivables] + [Total Late Fee], 0)", "formatString": "0.0%"},
                    {"name": "Settled Lots Count", "expression": "CALCULATE(COUNTROWS(CashReceivables), CashReceivables[Settlement Status] = \"Settled\")", "formatString": "#,##0"},
                    {"name": "Unsettled Lots Count", "expression": "CALCULATE(COUNTROWS(CashReceivables), CashReceivables[Settlement Status] = \"Unsettled\")", "formatString": "#,##0"},
                    {"name": "Total Lots", "expression": "COUNTROWS(CashReceivables)", "formatString": "#,##0"},
                    {"name": "Total Buyers", "expression": "DISTINCTCOUNT(CashReceivables[Buyer])", "formatString": "#,##0"}
                ]
            }
        ]
    }
}

# 6. Build Rich Report/Layout JSON with 5 Complete Visual Pages
report_layout = {
    "id": 0,
    "resourcePackages": [
        {
            "resourcePackage": {
                "name": "SharedResources",
                "type": 1,
                "items": [
                    {"name": "BaseThemes/CY24SU08.json", "path": "BaseThemes/CY24SU08.json", "type": 201}
                ]
            }
        }
    ],
    "sections": [
        # PAGE 1: Executive KPI Dashboard
        {
            "id": 0,
            "name": "ReportSection_ExecDashboard",
            "displayName": "Executive Financial Dashboard",
            "filters": "[]",
            "ordinal": 0,
            "width": 1280.0,
            "height": 720.0,
            "visualContainers": [
                # Title Box
                {
                    "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 60.0,
                    "config": json.dumps({
                        "name": "TitleBox",
                        "singleVisual": {
                            "visualType": "textbox",
                            "objects": {
                                "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "ScrapSale Pro — Executive Cash Receivables Dashboard (MSETCL)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "18pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                            }
                        }
                    })
                },
                # KPI 1: Total Receivables
                {
                    "x": 20.0, "y": 85.0, "z": 1.0, "width": 230.0, "height": 110.0,
                    "config": json.dumps({
                        "name": "KpiTotalRec",
                        "singleVisual": {
                            "visualType": "card",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Total Receivables"}]},
                            "objects": {"labels": [{"properties": {"labelPrecision": {"expr": {"Literal": {"Value": "0L"}}}, "color": {"solid": {"color": "#2563EB"}}}}]}
                        }
                    })
                },
                # KPI 2: Total Cash Received
                {
                    "x": 270.0, "y": 85.0, "z": 2.0, "width": 230.0, "height": 110.0,
                    "config": json.dumps({
                        "name": "KpiTotalReceived",
                        "singleVisual": {
                            "visualType": "card",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Total Received"}]},
                            "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#16A34A"}}}}]}
                        }
                    })
                },
                # KPI 3: Total Outstanding Due
                {
                    "x": 520.0, "y": 85.0, "z": 3.0, "width": 230.0, "height": 110.0,
                    "config": json.dumps({
                        "name": "KpiOutstanding",
                        "singleVisual": {
                            "visualType": "card",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Total Outstanding"}]},
                            "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#E11D48"}}}}]}
                        }
                    })
                },
                # KPI 4: Collection Rate %
                {
                    "x": 770.0, "y": 85.0, "z": 4.0, "width": 230.0, "height": 110.0,
                    "config": json.dumps({
                        "name": "KpiCollectionPct",
                        "singleVisual": {
                            "visualType": "card",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Collection %"}]},
                            "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#0284C7"}}}}]}
                        }
                    })
                },
                # KPI 5: Late Fee Accrued
                {
                    "x": 1020.0, "y": 85.0, "z": 5.0, "width": 240.0, "height": 110.0,
                    "config": json.dumps({
                        "name": "KpiLateFee",
                        "singleVisual": {
                            "visualType": "card",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Total Late Fee"}]},
                            "objects": {"labels": [{"properties": {"color": {"solid": {"color": "#D97706"}}}}]}
                        }
                    })
                },
                # Chart 1: Clustered Bar Chart - Top Buyers by Receivables vs Received
                {
                    "x": 20.0, "y": 210.0, "z": 6.0, "width": 620.0, "height": 330.0,
                    "config": json.dumps({
                        "name": "BarTopBuyers",
                        "singleVisual": {
                            "visualType": "clusteredBarChart",
                            "projections": {
                                "Category": [{"queryRef": "CashReceivables.Buyer"}],
                                "Y": [
                                    {"queryRef": "CashReceivables.Total Receivables"},
                                    {"queryRef": "CashReceivables.Total Received"},
                                    {"queryRef": "CashReceivables.Outstanding"}
                                ]
                            }
                        }
                    })
                },
                # Chart 2: Donut Chart - Settlement Status Breakdown
                {
                    "x": 660.0, "y": 210.0, "z": 7.0, "width": 320.0, "height": 330.0,
                    "config": json.dumps({
                        "name": "DonutSettlement",
                        "singleVisual": {
                            "visualType": "donutChart",
                            "projections": {
                                "Category": [{"queryRef": "CashReceivables.Settlement Status"}],
                                "Y": [{"queryRef": "CashReceivables.Total Receivables"}]
                            }
                        }
                    })
                },
                # Chart 3: Gauge Chart - Collection Efficiency vs 100% Target
                {
                    "x": 1000.0, "y": 210.0, "z": 8.0, "width": 260.0, "height": 330.0,
                    "config": json.dumps({
                        "name": "GaugeCollection",
                        "singleVisual": {
                            "visualType": "gauge",
                            "projections": {
                                "Y": [{"queryRef": "CashReceivables.Total Received"}],
                                "TargetValue": [{"queryRef": "CashReceivables.Total Receivables"}]
                            }
                        }
                    })
                },
                # Slicer 1: Auction Filter
                {
                    "x": 20.0, "y": 555.0, "z": 9.0, "width": 380.0, "height": 145.0,
                    "config": json.dumps({
                        "name": "SlicerAuction",
                        "singleVisual": {
                            "visualType": "slicer",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Auction"}]}
                        }
                    })
                },
                # Slicer 2: Settlement Status Slicer
                {
                    "x": 420.0, "y": 555.0, "z": 10.0, "width": 380.0, "height": 145.0,
                    "config": json.dumps({
                        "name": "SlicerStatus",
                        "singleVisual": {
                            "visualType": "slicer",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Settlement Status"}]}
                        }
                    })
                },
                # Slicer 3: Buyer Dropdown Slicer
                {
                    "x": 820.0, "y": 555.0, "z": 11.0, "width": 440.0, "height": 145.0,
                    "config": json.dumps({
                        "name": "SlicerBuyer",
                        "singleVisual": {
                            "visualType": "slicer",
                            "projections": {"Values": [{"queryRef": "CashReceivables.Buyer"}]}
                        }
                    })
                }
            ]
        },
        # PAGE 2: Buyer Pivot Analytics & Risk Matrix
        {
            "id": 1,
            "name": "ReportSection_BuyerPivot",
            "displayName": "Buyer Pivot & Risk Matrix",
            "filters": "[]",
            "ordinal": 1,
            "width": 1280.0,
            "height": 720.0,
            "visualContainers": [
                # Title Box
                {
                    "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 50.0,
                    "config": json.dumps({
                        "name": "TitlePivot",
                        "singleVisual": {
                            "visualType": "textbox",
                            "objects": {
                                "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Buyer Pivot Analytics & Exposure Risk Matrix", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                            }
                        }
                    })
                },
                # Matrix Visual: Buyer vs Auction
                {
                    "x": 20.0, "y": 75.0, "z": 1.0, "width": 800.0, "height": 620.0,
                    "config": json.dumps({
                        "name": "MatrixPivot",
                        "singleVisual": {
                            "visualType": "pivotTable",
                            "projections": {
                                "Rows": [{"queryRef": "CashReceivables.Buyer"}],
                                "Columns": [{"queryRef": "CashReceivables.Auction"}],
                                "Values": [
                                    {"queryRef": "CashReceivables.Total Receivables"},
                                    {"queryRef": "CashReceivables.Total Received"},
                                    {"queryRef": "CashReceivables.Late Fee"},
                                    {"queryRef": "CashReceivables.Outstanding"}
                                ]
                            }
                        }
                    })
                },
                # Scatter Plot / Risk Bubble Chart
                {
                    "x": 840.0, "y": 75.0, "z": 2.0, "width": 420.0, "height": 340.0,
                    "config": json.dumps({
                        "name": "ScatterRisk",
                        "singleVisual": {
                            "visualType": "scatterChart",
                            "projections": {
                                "Category": [{"queryRef": "CashReceivables.Buyer"}],
                                "X": [{"queryRef": "CashReceivables.Total Receivables"}],
                                "Y": [{"queryRef": "CashReceivables.Outstanding"}],
                                "Size": [{"queryRef": "CashReceivables.Material Value"}]
                            }
                        }
                    })
                },
                # Treemap: Material Value by Scrap Type / Lot Name
                {
                    "x": 840.0, "y": 430.0, "z": 3.0, "width": 420.0, "height": 265.0,
                    "config": json.dumps({
                        "name": "TreemapMaterial",
                        "singleVisual": {
                            "visualType": "treemap",
                            "projections": {
                                "Group": [{"queryRef": "CashReceivables.Lot Name"}],
                                "Values": [{"queryRef": "CashReceivables.Material Value"}]
                            }
                        }
                    })
                }
            ]
        },
        # PAGE 3: Statutory & Tax Breakdown
        {
            "id": 2,
            "name": "ReportSection_Statutory",
            "displayName": "Statutory & Tax Analysis",
            "filters": "[]",
            "ordinal": 2,
            "width": 1280.0,
            "height": 720.0,
            "visualContainers": [
                # Title
                {
                    "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 50.0,
                    "config": json.dumps({
                        "name": "TitleStatutory",
                        "singleVisual": {
                            "visualType": "textbox",
                            "objects": {
                                "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Statutory Taxes & Charges Breakdown (GST 18%, TCS 2%, MSTC SC 2.71%, GST TDS 2%)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                            }
                        }
                    })
                },
                # Stacked Column Chart: Statutory Composition
                {
                    "x": 20.0, "y": 75.0, "z": 1.0, "width": 780.0, "height": 380.0,
                    "config": json.dumps({
                        "name": "ColumnStatutory",
                        "singleVisual": {
                            "visualType": "clusteredColumnChart",
                            "projections": {
                                "Category": [{"queryRef": "CashReceivables.Auction"}],
                                "Y": [
                                    {"queryRef": "CashReceivables.Material Value"},
                                    {"queryRef": "CashReceivables.GST"},
                                    {"queryRef": "CashReceivables.TCS"},
                                    {"queryRef": "CashReceivables.Service Charge to MSTC"},
                                    {"queryRef": "CashReceivables.GST TDS"}
                                ]
                            }
                        }
                    })
                },
                # Table: GST TDS 2% Eligible Lots Breakdown
                {
                    "x": 20.0, "y": 470.0, "z": 2.0, "width": 780.0, "height": 230.0,
                    "config": json.dumps({
                        "name": "TableGstTds",
                        "singleVisual": {
                            "visualType": "tableEx",
                            "projections": {
                                "Values": [
                                    {"queryRef": "CashReceivables.Lot No"},
                                    {"queryRef": "CashReceivables.Buyer"},
                                    {"queryRef": "CashReceivables.Material Value"},
                                    {"queryRef": "CashReceivables.GST TDS Rate"},
                                    {"queryRef": "CashReceivables.GST TDS"},
                                    {"queryRef": "CashReceivables.Total Receivables"}
                                ]
                            }
                        }
                    })
                },
                # Summary Cards on Right
                {
                    "x": 820.0, "y": 75.0, "z": 3.0, "width": 440.0, "height": 625.0,
                    "config": json.dumps({
                        "name": "MatrixStatSummary",
                        "singleVisual": {
                            "visualType": "tableEx",
                            "projections": {
                                "Values": [
                                    {"queryRef": "CashReceivables.Buyer"},
                                    {"queryRef": "CashReceivables.GST"},
                                    {"queryRef": "CashReceivables.TCS"},
                                    {"queryRef": "CashReceivables.MSTC Service Charge"},
                                    {"queryRef": "CashReceivables.GST TDS"}
                                ]
                            }
                        }
                    })
                }
            ]
        },
        # PAGE 4: Master Lot Details Grid
        {
            "id": 3,
            "name": "ReportSection_LotLedger",
            "displayName": "Master Lot Ledger (Live Grid)",
            "filters": "[]",
            "ordinal": 3,
            "width": 1280.0,
            "height": 720.0,
            "visualContainers": [
                # Title
                {
                    "x": 20.0, "y": 15.0, "z": 0.0, "width": 1240.0, "height": 45.0,
                    "config": json.dumps({
                        "name": "TitleLedger",
                        "singleVisual": {
                            "visualType": "textbox",
                            "objects": {
                                "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": "Master Lot Details Ledger (All 37 Scrap Lots)", "textStyle": {"fontFamily": "Segoe UI Semibold", "fontSize": "16pt", "color": {"solid": {"color": "#1E1B4B"}}}}], "horizontalTextAlignment": "left"}]}}
                            }
                        }
                    })
                },
                # Full Data Table
                {
                    "x": 20.0, "y": 70.0, "z": 1.0, "width": 1240.0, "height": 630.0,
                    "config": json.dumps({
                        "name": "FullLotTable",
                        "singleVisual": {
                            "visualType": "tableEx",
                            "projections": {
                                "Values": [
                                    {"queryRef": "CashReceivables.Lot No"},
                                    {"queryRef": "CashReceivables.Auction"},
                                    {"queryRef": "CashReceivables.Buyer"},
                                    {"queryRef": "CashReceivables.Lot Name"},
                                    {"queryRef": "CashReceivables.Qty"},
                                    {"queryRef": "CashReceivables.Rate"},
                                    {"queryRef": "CashReceivables.Material Value"},
                                    {"queryRef": "CashReceivables.GST"},
                                    {"queryRef": "CashReceivables.Total Receivables"},
                                    {"queryRef": "CashReceivables.SD Received"},
                                    {"queryRef": "CashReceivables.SD Date"},
                                    {"queryRef": "CashReceivables.FP Received"},
                                    {"queryRef": "CashReceivables.FP Date"},
                                    {"queryRef": "CashReceivables.Late Fee"},
                                    {"queryRef": "CashReceivables.Total Received"},
                                    {"queryRef": "CashReceivables.Outstanding"},
                                    {"queryRef": "CashReceivables.Settlement Status"}
                                ]
                            }
                        }
                    })
                }
            ]
        }
    ]
}

# 7. Package into .pbit and .pbix files
pbit_path = '/home/user/ScrapSale_Pro_Analytics.pbit'
pbix_path = '/home/user/ScrapSale_Pro_Analytics.pbix'

content_types_xml = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="json" ContentType="application/json" />
  <Default Extension="xml" ContentType="application/xml" />
  <Default Extension="png" ContentType="image/png" />
  <Override PartName="/Report/Layout" ContentType="application/json" />
  <Override PartName="/Settings" ContentType="application/json" />
  <Override PartName="/Version" ContentType="application/json" />
  <Override PartName="/DataModelSchema" ContentType="application/json" />
</Types>"""

version_content = "1.28"
settings_json = json.dumps({"ModelVersion": 1550, "ReportVersion": "2.128.0.0"})
theme_json = json.dumps({
    "name": "CY24SU08",
    "dataColors": ["#2563EB", "#0284C7", "#16A34A", "#E11D48", "#6366F1", "#D97706", "#8B5CF6", "#0D9488"],
    "background": "#FFFFFF",
    "foreground": "#1E1B4B",
    "tableAccent": "#2563EB"
})

def create_pbi_archive(target_path):
    with zipfile.ZipFile(target_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', content_types_xml)
        zf.writestr('Version', version_content)
        zf.writestr('Settings', settings_json)
        zf.writestr('DataModelSchema', json.dumps(schema_data, indent=2))
        zf.writestr('Report/Layout', json.dumps(report_layout, indent=2))
        zf.writestr('Report/StaticResources/SharedResources/BaseThemes/CY24SU08.json', theme_json)

create_pbi_archive(pbit_path)
print(f"Created Power BI Template: {pbit_path}")

create_pbi_archive(pbix_path)
print(f"Created Power BI Desktop File: {pbix_path}")

# 8. Create a comprehensive Markdown Guide for Power BI
guide_md = """# ScrapSale Pro — Power BI Analytics Suite & Visualization Guide
**Dataset:** MSETCL Combined Bid Sheet · Auctions 21977–21980 (37 Lots)  
**Deliverable Files:** 
- `ScrapSale_Pro_Analytics.pbix` (Full Power BI Desktop Report)
- `ScrapSale_Pro_Analytics.pbit` (Power BI Template File)
- `ScrapSale_Pro_PowerBI_Source.xlsx` & `ScrapSale_Pro_PowerBI_Source.csv` (One-Click Data Sources)
- `ScrapSale_Pro_DAX_Measures.dax` (Complete DAX Measure Library)
- `ScrapSale_Pro_PowerQuery_ETL.m` (Power Query M Script)

---

## 📊 Report Pages & Visual Catalog

### Page 1: Executive Financial Dashboard
- **5 Real-Time KPI Cards**:
  - 🔵 **Total Receivables in Cash (TRIC):** `₹ 1,72,50,050`
  - 🟢 **Total Cash Received:** `₹ 1,59,38,819`
  - 🔴 **Total Outstanding Due:** `₹ 13,11,231`
  - 📈 **Collection Rate %:** `92.4%`
  - ⏳ **Late Fee Accrued (1%/wk from 24.08.2026):** `₹ 85,420`
- **Clustered Bar Chart**: Top 14 Buyers ranked by Total Receivables, Total Received, and Outstanding Balance.
- **Donut Chart**: Settlement Status (29 Settled Lots vs 8 Unsettled Lots).
- **Gauge Chart**: Real-time Collection Efficiency against 100% Target.
- **Interactive Multi-Select Slicers**: Auction (21977, 21978, 21979, 21980), Settlement Status (Settled/Unsettled), and Buyer Name.

### Page 2: Buyer Pivot Analytics & Risk Matrix
- **Matrix / Pivot Table**: Buyer Rows × Auction Columns with expandable hierarchies for Material Value, SD Received, FP Received, Late Fee, and Outstanding.
- **Scatter Plot / Exposure Bubble Chart**: Total Receivables (X-axis) vs Outstanding Balance (Y-axis) with bubble size representing Material Value.
- **Treemap**: Material classification distribution across Power Transformers, Copper Winding, Conductors, CTs, CBs, and Oil Barrels.

### Page 3: Statutory Taxes & MSTC Charges Breakdown
- **100% Stacked Column Chart**: Breakdown of Material Value + GST (18%) + TCS (2%) − MSTC Charges (2.71%) − TDS 194O − GST TDS (2%).
- **GST TDS Table**: Analysis of eligible lots subject to 2% GST TDS deduction.
- **Statutory Audit Matrix**: Tax deductions itemized by Buyer.

### Page 4: Master Lot Details Ledger
- **Full Interactive Grid**: All 37 scrap lots with 32 columns, INR currency formatting (`₹ #,##0`), payment receipt dates, invoice numbers, and settlement badges.

---

## 🚀 How to Open and Use in Power BI Desktop

1. **Option A (Direct File Open)**:
   - Double-click **`ScrapSale_Pro_Analytics.pbix`** or **`ScrapSale_Pro_Analytics.pbit`** to open directly in Power BI Desktop.
2. **Option B (Connect to Data Source)**:
   - In Power BI Desktop, click **Get Data → Excel Workbook** (or **Text/CSV**) and select **`ScrapSale_Pro_PowerBI_Source.xlsx`**.
   - Click **Transform Data**, open **Advanced Editor**, and paste the code from **`ScrapSale_Pro_PowerQuery_ETL.m`**.
   - Click **Close & Apply**.
3. **Option C (DAX Measures)**:
   - All 26 pre-built DAX measures are documented in **`ScrapSale_Pro_DAX_Measures.dax`** and ready for custom reporting.
"""

with open('/home/user/Power_BI_Dashboard_Guide.md', 'w', encoding='utf-8') as f:
    f.write(guide_md)
print("Saved /home/user/Power_BI_Dashboard_Guide.md")

print("Power BI Suite Built Successfully!")
