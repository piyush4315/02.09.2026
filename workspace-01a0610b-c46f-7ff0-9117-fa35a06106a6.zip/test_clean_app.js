const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 950 } });
  
  page.on('console', msg => console.log('PAGE LOG:', msg.type(), msg.text()));
  page.on('pageerror', err => console.log('PAGE ERROR:', err.message));

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  const lotsCount = await page.evaluate(() => window.lots ? window.lots.length : 0);
  console.log('Lots loaded in table:', lotsCount);

  // Take screenshot
  await page.screenshot({ path: '/home/user/scrapsale_no_filter_btn_proof.png' });
  console.log('Saved: /home/user/scrapsale_no_filter_btn_proof.png');

  await browser.close();
  console.log('All checks PASSED with 0 errors!');
})();
