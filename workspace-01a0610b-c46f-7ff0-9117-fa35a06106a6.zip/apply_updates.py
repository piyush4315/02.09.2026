with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Remove "+ " from hidden column button
old_col_toggle = """  html += hiddenCols.map(function (c) {
    return '<button type="button" class="col-toggle off" data-key="' + escHtml(c.key) + '" title="Click to show “' + escHtml(c.label) + '” column">+ ' + escHtml(c.label) + '</button>';
  }).join('');"""

new_col_toggle = """  html += hiddenCols.map(function (c) {
    return '<button type="button" class="col-toggle off" data-key="' + escHtml(c.key) + '" title="Click to show “' + escHtml(c.label) + '” column">' + escHtml(c.label) + '</button>';
  }).join('');"""

if old_col_toggle in text:
    text = text.replace(old_col_toggle, new_col_toggle, 1)
    print("1. Removed + from hidden column buttons")
else:
    print("1. old_col_toggle not found!")

# 2. Update Dark Mode settled row and badge styling
old_dark_settled = """tbody tr.settled td,tbody tr.settled td.left,tbody tr.settled td.strong,tbody tr.settled td.pos,tbody tr.settled td.neg,tbody tr.settled td.zero,tbody tr.settled td.date{
  color:#69d791!important;
  text-shadow:none;
}
tbody tr.settled td.edit input{color:#69d791}"""

new_dark_settled = """tbody tr.settled td:not(.status),
tbody tr.settled td:not(.status) *,
tbody tr.settled td.left,
tbody tr.settled td.strong,
tbody tr.settled td.pos,
tbody tr.settled td.neg,
tbody tr.settled td.zero,
tbody tr.settled td.date,
tbody tr.settled td.invno,
tbody tr.settled .inv-link,
tbody tr.settled td.edit input {
  color: #69d791 !important;
  text-shadow: none;
}
tbody tr.settled {
  background: rgba(105, 215, 145, 0.04);
}
tbody tr.settled:hover {
  background: rgba(105, 215, 145, 0.09) !important;
}"""

if old_dark_settled in text:
    text = text.replace(old_dark_settled, new_dark_settled, 1)
    print("2. Updated dark mode settled row styling")
else:
    print("2. old_dark_settled not found!")

# 3. Update Dark Mode badges styling
old_badges_css = """.settled-counts{display:inline-flex;align-items:center;gap:4px;justify-content:flex-end;width:100%}
.settled-counts .seg{display:inline-flex;align-items:center;gap:3px;font-size:10.5px;font-weight:800;letter-spacing:.4px;text-transform:uppercase;border-radius:999px;padding:2px 7px;line-height:1.1;white-space:nowrap}
.settled-counts .seg.s{background:linear-gradient(135deg,#10b981 0%,#22c55e 100%);color:#fff;box-shadow:0 0 14px rgba(34,197,94,.55),inset 0 0 0 1px rgba(167,243,208,.55)}
.settled-counts .seg.u{background:#f72585;color:#fff;box-shadow:0 0 12px rgba(247,37,133,.35)}
/* Full-word pill (used when the opposite side is 0): keep the same colour as the
   counting count chip; just widen padding for the longer label */
.settled-counts .seg.zero{padding:2px 11px;letter-spacing:.6px}
td.left{text-align:left;font-weight:400}
td.strong{color:var(--cyan);font-weight:400}
td.pos{color:#f9a8d4;font-weight:400}
td.neg{color:#86efac;font-weight:400}
td.zero{color:var(--dim)}
/* Unsettled & partially settled rows: every field value stays pure white —
   the cyan (totals), pink/green (outstanding) and dim (dates/zeros) cues are
   suppressed outside Settled rows; Settled rows keep their #69d791 colour. */
tbody tr:not(.settled) td{color:#e2e8f0}
td.status{text-align:center}
.lbl-settled,.lbl-unsettled{
  display:inline-block;text-align:center;font-size:9.5px;font-weight:800;
  letter-spacing:.6px;text-transform:uppercase;border-radius:999px;padding:3px 9px;line-height:1.15
}
.lbl-settled{background:linear-gradient(135deg,#10b981 0%,#22c55e 100%);color:#fff;box-shadow:0 0 14px rgba(34,197,94,.55),inset 0 0 0 1px rgba(167,243,208,.55)}
.lbl-unsettled{background:#f72585;color:#fff;box-shadow:0 0 12px rgba(247,37,133,.35)}"""

new_badges_css = """.settled-counts{display:inline-flex;align-items:center;gap:4px;justify-content:flex-end;width:100%}
.lbl-settled,.lbl-unsettled,.settled-counts .seg{
  display:inline-flex;align-items:center;justify-content:center;
  font-size:9.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;
  border-radius:999px;padding:2.5px 9px;line-height:1.15;white-space:nowrap;
}
.settled-counts .seg{gap:3px;padding:2.5px 8px}
.settled-counts .seg.zero{padding:2.5px 10px;letter-spacing:.6px}
.lbl-settled,.settled-counts .seg.s{
  background:linear-gradient(135deg,#10b981 0%,#22c55e 100%);
  color:#ffffff;
  box-shadow:0 0 14px rgba(34,197,94,.4),inset 0 0 0 1px rgba(167,243,208,.4);
}
.lbl-unsettled,.settled-counts .seg.u{
  background:#f72585;
  color:#ffffff;
  box-shadow:0 0 12px rgba(247,37,133,.35);
}
td.left{text-align:left;font-weight:400}
td.strong{color:var(--cyan);font-weight:400}
td.pos{color:#f9a8d4;font-weight:400}
td.neg{color:#86efac;font-weight:400}
td.zero{color:var(--dim)}
tbody tr:not(.settled) td{color:#e2e8f0}
td.status{text-align:center}"""

if old_badges_css in text:
    text = text.replace(old_badges_css, new_badges_css, 1)
    print("3. Updated dark mode badges & chips styling")
else:
    print("3. old_badges_css not found, trying flexible replace...")

# 4. Update Light Mode settled row and badge styling
old_light_settled = """[data-theme="light"] tbody tr:not(.settled) td {
  color: #0f172a;
}
[data-theme="light"] tbody tr.settled td {
  color: #16a34a;
}
[data-theme="light"] td.strong {
  color: #0284c7;
}
[data-theme="light"] td.pos {
  color: #e11d48;
}
[data-theme="light"] td.neg {
  color: #16a34a;
}
[data-theme="light"] td.zero {
  color: #64748b;
}
[data-theme="light"] td.date {
  color: #64748b;
}

/* Status Chips & Badges */
[data-theme="light"] .settled-counts .seg.s {
  background: #16a34a;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(22, 163, 74, 0.25);
}
[data-theme="light"] .settled-counts .seg.u {
  background: #e11d48;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(225, 29, 72, 0.25);
}
[data-theme="light"] .lbl-settled {
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  color: #15803d;
}
[data-theme="light"] .lbl-unsettled {
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
}"""

new_light_settled = """[data-theme="light"] tbody tr:not(.settled) td {
  color: #0f172a;
}
[data-theme="light"] td.strong {
  color: #0284c7;
}
[data-theme="light"] td.pos {
  color: #e11d48;
}
[data-theme="light"] td.neg {
  color: #16a34a;
}
[data-theme="light"] td.zero {
  color: #64748b;
}
[data-theme="light"] td.date {
  color: #64748b;
}
[data-theme="light"] tbody tr.settled td:not(.status),
[data-theme="light"] tbody tr.settled td:not(.status) *,
[data-theme="light"] tbody tr.settled td.left,
[data-theme="light"] tbody tr.settled td.strong,
[data-theme="light"] tbody tr.settled td.pos,
[data-theme="light"] tbody tr.settled td.neg,
[data-theme="light"] tbody tr.settled td.zero,
[data-theme="light"] tbody tr.settled td.date,
[data-theme="light"] tbody tr.settled td.invno,
[data-theme="light"] tbody tr.settled .inv-link,
[data-theme="light"] tbody tr.settled td.edit input {
  color: #16a34a !important;
  text-shadow: none;
}
[data-theme="light"] tbody tr.settled {
  background: rgba(22, 163, 74, 0.04);
}
[data-theme="light"] tbody tr.settled:hover {
  background: rgba(22, 163, 74, 0.08) !important;
}

/* Status Chips & Badges */
[data-theme="light"] .lbl-settled,
[data-theme="light"] .settled-counts .seg.s {
  background: #f0fdf4 !important;
  border: 1px solid #bbf7d0 !important;
  color: #15803d !important;
  box-shadow: none !important;
}
[data-theme="light"] .lbl-unsettled,
[data-theme="light"] .settled-counts .seg.u {
  background: #fff1f2 !important;
  border: 1px solid #fecdd3 !important;
  color: #be123c !important;
  box-shadow: none !important;
}"""

if old_light_settled in text:
    text = text.replace(old_light_settled, new_light_settled, 1)
    print("4. Updated light mode settled row and badge styling")
else:
    print("4. old_light_settled not found, checking...")

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("Updates applied to index.html successfully!")
