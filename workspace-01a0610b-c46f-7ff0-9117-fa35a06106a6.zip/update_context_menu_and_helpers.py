import re

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

# Let's define the new functions: renderActiveFiltersBar and openTableFilterModal
new_helper_functions = '''
/* ── ACTIVE FILTERS BAR & MOBILE FILTER MODAL ── */
function renderActiveFiltersBar() {
  var pBar = document.getElementById('pivotActiveFiltersBar');
  var dBar = document.getElementById('detailActiveFiltersBar');
  var pBadge = document.getElementById('pivotFilterCountBadge');
  var dBadge = document.getElementById('detailFilterCountBadge');
  
  // Pivot active filters
  var pCount = 0;
  var pChips = [];
  if (ui.auction && ui.auction !== 'all') {
    pCount++;
    pChips.push({ label: 'Auction: ' + ui.auction, clear: function() { ui.auction = 'all'; var el = document.getElementById('auctionFilter'); if (el) el.value = 'all'; renderAll(); saveState(); } });
  }
  if (ui.dashSearch) {
    pCount++;
    pChips.push({ label: 'Search: "' + ui.dashSearch + '"', clear: function() { ui.dashSearch = ''; var el = document.getElementById('search'); if (el) el.value = ''; renderAll(); saveState(); } });
  }
  if (ui.colFilters) {
    for (var k in ui.colFilters) {
      if (ui.colFilters[k] && ui.colFilters[k].length) {
        var cleanK = k.startsWith('pivot_') ? k.slice(6) : k;
        var fLabel = fieldLabel(cleanK);
        pCount++;
        (function(colKey, labelName) {
          pChips.push({
            label: labelName + ': ' + ui.colFilters[colKey].length + ' val' + (ui.colFilters[colKey].length === 1 ? '' : 's'),
            clear: function() { delete ui.colFilters[colKey]; renderAll(); saveState(); }
          });
        })(k, fLabel);
      }
    }
  }
  
  if (pBadge) {
    pBadge.textContent = pCount;
    pBadge.style.display = pCount > 0 ? 'inline-flex' : 'none';
  }
  
  if (pBar) {
    if (pChips.length > 0) {
      pBar.style.display = 'flex';
      pBar.innerHTML = '<span class="af-label">Active filters:</span>' +
        pChips.map(function(c, i) {
          return '<span class="af-chip">' + escHtml(c.label) + ' <button type="button" class="af-chip-del" data-af-p="' + i + '" title="Remove this filter">✕</button></span>';
        }).join('') +
        '<button type="button" class="af-clear-all" id="clearAllPivotAfBtn">Clear all</button>';
      
      pBar.querySelectorAll('.af-chip-del').forEach(function(btn) {
        btn.addEventListener('click', function(ev) {
          ev.stopPropagation();
          var idx = +btn.getAttribute('data-af-p');
          if (pChips[idx]) pChips[idx].clear();
        });
      });
      var clearAllBtn = pBar.querySelector('#clearAllPivotAfBtn');
      if (clearAllBtn) clearAllBtn.addEventListener('click', resetPivotFilters);
    } else {
      pBar.style.display = 'none';
      pBar.innerHTML = '';
    }
  }

  // Lot Detail active filters
  var dCount = 0;
  var dChips = [];
  if (ui.detailSearch) {
    dCount++;
    dChips.push({ label: 'Search: "' + ui.detailSearch + '"', clear: function() { ui.detailSearch = ''; var el = document.getElementById('detailSearch'); if (el) el.value = ''; renderDetail(); saveState(); } });
  }
  if (selectedGroup) {
    dCount++;
    dChips.push({ label: 'Drilldown: ' + selectedGroup.value, clear: function() { selectedGroup = null; renderAll(); saveState(); } });
  }
  if (ui.colFilters) {
    for (var dk in ui.colFilters) {
      if (!dk.startsWith('pivot_') && ui.colFilters[dk] && ui.colFilters[dk].length) {
        var dfLabel = fieldLabel(dk);
        dCount++;
        (function(colKey, labelName) {
          dChips.push({
            label: labelName + ': ' + ui.colFilters[colKey].length + ' val' + (ui.colFilters[colKey].length === 1 ? '' : 's'),
            clear: function() { delete ui.colFilters[colKey]; renderDetail(); saveState(); }
          });
        })(dk, dfLabel);
      }
    }
  }

  if (dBadge) {
    dBadge.textContent = dCount;
    dBadge.style.display = dCount > 0 ? 'inline-flex' : 'none';
  }

  if (dBar) {
    if (dChips.length > 0) {
      dBar.style.display = 'flex';
      dBar.innerHTML = '<span class="af-label">Active filters:</span>' +
        dChips.map(function(c, i) {
          return '<span class="af-chip">' + escHtml(c.label) + ' <button type="button" class="af-chip-del" data-af-d="' + i + '" title="Remove this filter">✕</button></span>';
        }).join('') +
        '<button type="button" class="af-clear-all" id="clearAllDetailAfBtn">Clear all</button>';
      
      dBar.querySelectorAll('.af-chip-del').forEach(function(btn) {
        btn.addEventListener('click', function(ev) {
          ev.stopPropagation();
          var idx = +btn.getAttribute('data-af-d');
          if (dChips[idx]) dChips[idx].clear();
        });
      });
      var dClearAllBtn = dBar.querySelector('#clearAllDetailAfBtn');
      if (dClearAllBtn) dClearAllBtn.addEventListener('click', resetDetailFilters);
    } else {
      dBar.style.display = 'none';
      dBar.innerHTML = '';
    }
  }
}

function openTableFilterModal(tableKind) {
  var isPivot = tableKind === 'pivot';
  var title = isPivot ? 'Pivot Analytics — Column Filters' : 'Lot Details — Column Filters';
  var layoutKind = isPivot ? (ui.groupBy === 'default' ? 'pivotLot' : 'pivotMetric') : 'detail';
  var catalog = allAssignableFields(layoutKind);
  
  var body = '<div style="margin-bottom:12px">' +
    '<input type="search" id="modalColSearch" class="xl-search" placeholder="Search columns by name…" style="width:100%;margin-bottom:10px" autocomplete="off"/>' +
    '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">' +
      '<span style="font-size:12px;color:var(--dim)">Tap any column to filter its unique values:</span>' +
      '<button type="button" class="btn" id="modalResetFilterBtn" style="font-size:11px;padding:4px 10px">↺ Clear All Filters</button>' +
    '</div>' +
  '</div>' +
  '<div class="col-filter-list" id="modalColFilterList">' +
  '</div>';

  openModal({
    title: title,
    wide: true,
    body: body,
    actions: false
  });

  var searchInput = document.getElementById('modalColSearch');
  var listEl = document.getElementById('modalColFilterList');
  var resetBtn = document.getElementById('modalResetFilterBtn');

  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      if (isPivot) resetPivotFilters(); else resetDetailFilters();
      renderModalColList();
    });
  }

  function renderModalColList() {
    if (!listEl) return;
    var q = searchInput ? searchInput.value.trim().toLowerCase() : '';
    var fieldsToShow = catalog.filter(function (c) {
      if (!q) return true;
      return c.label.toLowerCase().indexOf(q) !== -1 || c.key.toLowerCase().indexOf(q) !== -1;
    });

    if (!fieldsToShow.length) {
      listEl.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:20px;color:var(--dim)">No matching columns</div>';
      return;
    }

    listEl.innerHTML = fieldsToShow.map(function (c) {
      var filterKey = (isPivot && ui.groupBy !== 'default' && c.key !== ui.groupBy && c.key !== 'key' && c.key !== 'settlement_status' && c.key !== 'settled_breakdown')
        ? ('pivot_' + c.key)
        : (c.key === 'key' ? ui.groupBy : c.key);
      var hasFilter = colFilterOn(filterKey);
      var currentSel = colFilterKeys(filterKey);
      var statusText = hasFilter ? (currentSel.length + ' selected') : 'All values';

      return '<button type="button" class="col-filter-card' + (hasFilter ? ' filtered' : '') + '" data-pick-col="' + escHtml(c.key) + '">' +
        '<span class="col-filter-card-name">' + escHtml(c.label) + '</span>' +
        '<span class="col-filter-card-status">' + (hasFilter ? '● ' : '') + statusText + ' ›</span>' +
      '</button>';
    }).join('');

    listEl.querySelectorAll('[data-pick-col]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-pick-col');
        var mockTh = document.createElement('th');
        mockTh.dataset.field = key;
        mockTh.dataset.table = tableKind;
        mockTh.dataset.layout = layoutKind;
        document.getElementById('modalRoot').innerHTML = ''; // close modal
        var btnRect = btn.getBoundingClientRect();
        showHeaderContextMenu(btnRect.left, btnRect.top, mockTh);
      });
    });
  }

  renderModalColList();
  if (searchInput) searchInput.addEventListener('input', renderModalColList);
}
'''

# Find showHeaderContextMenu and update it
old_ctx_fn_start = text.find('function showHeaderContextMenu(x, y, th) {')
assert old_ctx_fn_start != -1, "showHeaderContextMenu not found"

# Insert helper functions before showHeaderContextMenu
text = text[:old_ctx_fn_start] + new_helper_functions + '\n' + text[old_ctx_fn_start:]

# Now let's update showHeaderContextMenu positioning and backdrop
old_positioning = '''    var rect = th.getBoundingClientRect();
    var mw = Math.max(menu.offsetWidth, 320);
    var mh = menu.offsetHeight;
    var left = Math.min(Math.max(8, x), Math.max(8, window.innerWidth - mw - 8));
    var top = y + 4;
    if (top + mh > window.innerHeight - 8) top = Math.max(8, window.innerHeight - mh - 8);
    menu.style.top = top + 'px';
    menu.style.left = left + 'px';
    menu.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });

    function closeHeaderContextMenu() {
      var m = document.getElementById('thCtxMenu');
      if (m) m.remove();
      document.removeEventListener('mousedown', outsideHandler, true);
      document.removeEventListener('scroll', outsideHandler, true);
      document.removeEventListener('keydown', escHandler);
    }'''

new_positioning = '''    var isMobile = (window.innerWidth <= 640 || document.body.getAttribute('data-view-mode') === 'mobile');
    if (isMobile) {
      menu.classList.add('mobile-sheet');
      menu.style.top = '';
      menu.style.left = '';
      menu.style.right = '';
      menu.style.bottom = '';
    } else {
      var rect = th.getBoundingClientRect();
      var mw = Math.max(menu.offsetWidth, 320);
      var mh = menu.offsetHeight;
      var left = Math.min(Math.max(8, x), Math.max(8, window.innerWidth - mw - 8));
      var top = y + 4;
      if (top + mh > window.innerHeight - 8) top = Math.max(8, window.innerHeight - mh - 8);
      menu.style.top = top + 'px';
      menu.style.left = left + 'px';
    }
    menu.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });
    menu.addEventListener('touchstart', function (ev) { ev.stopPropagation(); });

    var backdrop = document.getElementById('thCtxBackdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'thCtxBackdrop';
      backdrop.className = 'col-menu-backdrop';
      document.body.appendChild(backdrop);
    }
    backdrop.style.display = 'block';
    backdrop.onclick = closeHeaderContextMenu;

    function closeHeaderContextMenu() {
      var m = document.getElementById('thCtxMenu');
      if (m) m.remove();
      var bd = document.getElementById('thCtxBackdrop');
      if (bd) bd.remove();
      document.removeEventListener('mousedown', outsideHandler, true);
      document.removeEventListener('touchstart', outsideHandler, true);
      document.removeEventListener('scroll', outsideHandler, true);
      document.removeEventListener('keydown', escHandler);
    }'''

if old_positioning in text:
    text = text.replace(old_positioning, new_positioning)
    print("Updated showHeaderContextMenu positioning successfully")
else:
    print("Warning: old_positioning not matched directly")

# Also add renderActiveFiltersBar calls in renderAll, renderPivot, renderDetail
text = text.replace('function renderAll() {', 'function renderAll() {\n  renderActiveFiltersBar();')
text = text.replace('function renderPivot() {', 'function renderPivot() {\n  renderActiveFiltersBar();')
text = text.replace('function renderDetail() {', 'function renderDetail() {\n  renderActiveFiltersBar();')

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'w', encoding='utf-8') as f:
    f.write(text)

print("Step 2 done.")
