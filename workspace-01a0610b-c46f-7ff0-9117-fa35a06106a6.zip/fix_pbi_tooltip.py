with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

pos = text.find("/* ==========================================================================\n   POWER BI ANALYTICS ENGINE")
pos_end = text.find("/* ---------------- export ---------------- */", pos)

clean_analytics_engine = """/* ==========================================================================
   POWER BI ANALYTICS ENGINE (Pure SVG, 100% Offline, Zero AI Slop)
   ========================================================================== */
var pbiSlicers = {
  auction: 'all',
  buyer: 'all',
  status: 'all',
  material: 'all'
};

function initPbiSlicers() {
  var aSel = document.getElementById('pbiAuctionFilter');
  var bSel = document.getElementById('pbiBuyerFilter');
  var sSel = document.getElementById('pbiStatusFilter');
  var mSel = document.getElementById('pbiMaterialFilter');
  if (!aSel || !bSel || !sSel || !mSel) return;

  var auctions = new Set(), buyers = new Set(), materials = new Set();
  lots.forEach(function (r) {
    if (r.auction) auctions.add(r.auction);
    if (r.buyer) buyers.add(r.buyer);
    if (r.lot_name) materials.add(r.lot_name);
  });

  aSel.innerHTML = '<option value="all">All Auctions (' + auctions.size + ')</option>' +
    Array.from(auctions).sort().map(function (a) {
      return '<option value="' + escHtml(a) + '"' + (pbiSlicers.auction === a ? ' selected' : '') + '>' + escHtml(a) + '</option>';
    }).join('');

  bSel.innerHTML = '<option value="all">All Buyers (' + buyers.size + ')</option>' +
    Array.from(buyers).sort().map(function (b) {
      return '<option value="' + escHtml(b) + '"' + (pbiSlicers.buyer === b ? ' selected' : '') + '>' + escHtml(b) + '</option>';
    }).join('');

  mSel.innerHTML = '<option value="all">All Materials (' + materials.size + ')</option>' +
    Array.from(materials).sort().map(function (m) {
      return '<option value="' + escHtml(m) + '"' + (pbiSlicers.material === m ? ' selected' : '') + '>' + escHtml(m) + '</option>';
    }).join('');

  sSel.value = pbiSlicers.status;

  aSel.onchange = function () { pbiSlicers.auction = aSel.value; renderAnalyticsCharts(); };
  bSel.onchange = function () { pbiSlicers.buyer = bSel.value; renderAnalyticsCharts(); };
  sSel.onchange = function () { pbiSlicers.status = sSel.value; renderAnalyticsCharts(); };
  mSel.onchange = function () { pbiSlicers.material = mSel.value; renderAnalyticsCharts(); };

  var resetBtn = document.getElementById('pbiResetBtn');
  if (resetBtn) {
    resetBtn.onclick = function () {
      pbiSlicers = { auction: 'all', buyer: 'all', status: 'all', material: 'all' };
      initPbiSlicers();
      renderAnalyticsCharts();
    };
  }
}

function getPbiFilteredLots() {
  return lots.filter(function (r) {
    if (pbiSlicers.auction !== 'all' && String(r.auction) !== String(pbiSlicers.auction)) return false;
    if (pbiSlicers.buyer !== 'all' && r.buyer !== pbiSlicers.buyer) return false;
    if (pbiSlicers.material !== 'all' && r.lot_name !== pbiSlicers.material) return false;
    if (pbiSlicers.status === 'settled' && r.outstanding > SETTLEMENT_TOLERANCE) return false;
    if (pbiSlicers.status === 'unsettled' && r.outstanding <= SETTLEMENT_TOLERANCE) return false;
    return true;
  });
}

function showPbiTooltip(e, html) {
  var tip = document.getElementById('pbiTooltip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'pbiTooltip';
    tip.className = 'pbi-tooltip';
    document.body.appendChild(tip);
  }
  tip.innerHTML = html;
  tip.style.display = 'block';
  tip.style.opacity = '1';
  var x = e.pageX + 12, y = e.pageY - 28;
  if (x + 240 > window.innerWidth) x = e.pageX - 250;
  tip.style.left = x + 'px';
  tip.style.top = y + 'px';
}

function hidePbiTooltip() {
  var tip = document.getElementById('pbiTooltip');
  if (tip) {
    tip.style.opacity = '0';
    tip.style.display = 'none';
  }
}

// Tooltip event delegation
document.addEventListener('mouseover', function (e) {
  var target = e.target && e.target.closest ? e.target.closest('[data-pbi-tip]') : null;
  if (target) {
    showPbiTooltip(e, target.getAttribute('data-pbi-tip'));
  }
});
document.addEventListener('mousemove', function (e) {
  var target = e.target && e.target.closest ? e.target.closest('[data-pbi-tip]') : null;
  if (target) {
    showPbiTooltip(e, target.getAttribute('data-pbi-tip'));
  }
});
document.addEventListener('mouseout', function (e) {
  var target = e.target && e.target.closest ? e.target.closest('[data-pbi-tip]') : null;
  if (target) {
    hidePbiTooltip();
  }
});

function renderAnalyticsCharts() {
  initPbiSlicers();
  var rows = getPbiFilteredLots();

  // 1. Render KPI Grid
  renderPbiKpis(rows);

  // 2. Render Charts
  renderBuyerMatrixChart(rows);
  renderCashInflowDonut(rows);
  renderWaterfallChart(rows);
  renderMaterialParetoChart(rows);
  renderAuctionPerfChart(rows);
  renderAgeingChart(rows);
  renderBuyerLeaderboardTable(rows);
}

function renderPbiKpis(rows) {
  var grid = document.getElementById('pbiKpiGrid');
  if (!grid) return;

  var totMat = rows.reduce(function (a, r) { return a + (r.mat_value || 0); }, 0);
  var totRec = rows.reduce(function (a, r) { return a + (r.total_receivables || 0); }, 0);
  var totRcv = rows.reduce(function (a, r) { return a + (r.total_received || 0); }, 0);
  var totOut = rows.reduce(function (a, r) { return a + (r.outstanding || 0); }, 0);
  var totLate = rows.reduce(function (a, r) { return a + (r.late_fee || 0); }, 0);
  var totQty = rows.reduce(function (a, r) { return a + (r.qty || 0); }, 0);

  var settledCount = rows.filter(function (r) { return (r.outstanding || 0) <= SETTLEMENT_TOLERANCE; }).length;
  var unsettledCount = rows.length - settledCount;
  var recRate = totRec > 0 ? Math.min(100, Math.round((totRcv / totRec) * 100)) : 0;
  var stlRate = rows.length > 0 ? Math.round((settledCount / rows.length) * 100) : 0;

  var kpis = [
    {
      label: 'Material Value',
      val: '₹ ' + inr(totMat),
      sub: numFmt(totQty) + ' MT across ' + rows.length + ' lots',
      barVal: 100,
      color: '#0284c7'
    },
    {
      label: 'Total Receivables',
      val: '₹ ' + inr(totRec),
      sub: 'Net invoice cash value',
      barVal: 100,
      color: '#6366f1'
    },
    {
      label: 'Total Cash Realized',
      val: '₹ ' + inr(totRcv),
      sub: recRate + '% realized of total due',
      barVal: recRate,
      color: '#10b981'
    },
    {
      label: 'Net Outstanding Due',
      val: '₹ ' + inr(totOut),
      sub: unsettledCount + ' unsettled lot(s) pending',
      barVal: Math.min(100, totRec > 0 ? Math.round((totOut / totRec) * 100) : 0),
      color: totOut > 1 ? '#f43f5e' : '#10b981'
    },
    {
      label: 'Delayed Payment Charges',
      val: '₹ ' + inr(totLate),
      sub: 'Accrued @ 1.18%/wk on Mat Value',
      barVal: Math.min(100, totMat > 0 ? Math.round((totLate / totMat) * 100 * 5) : 0),
      color: '#d97706'
    },
    {
      label: 'Settlement Realization',
      val: stlRate + '%',
      sub: settledCount + ' of ' + rows.length + ' lots settled',
      barVal: stlRate,
      color: '#10b981'
    }
  ];

  grid.innerHTML = kpis.map(function (k) {
    return '<div class="pbi-kpi-card">' +
      '<div class="pbi-kpi-label">' + escHtml(k.label) + '</div>' +
      '<div class="pbi-kpi-val" style="color:' + k.color + '">' + escHtml(k.val) + '</div>' +
      '<div class="pbi-kpi-sub">' + escHtml(k.sub) + '</div>' +
      '<div class="pbi-kpi-progress"><div class="pbi-kpi-bar" style="width:' + k.barVal + '%;background:' + k.color + '"></div></div>' +
    '</div>';
  }).join('');
}

// Chart 1: Buyer Realization Matrix (Grouped Horizontal Bars)
function renderBuyerMatrixChart(rows) {
  var el = document.getElementById('chartBuyerMatrix');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data matching slicers</p>'; return; }

  var bMap = {};
  rows.forEach(function (r) {
    var b = r.buyer || 'Unknown';
    if (!bMap[b]) bMap[b] = { buyer: b, rec: 0, rcv: 0, out: 0, lots: 0 };
    bMap[b].rec += (r.total_receivables || 0);
    bMap[b].rcv += (r.total_received || 0);
    bMap[b].out += (r.outstanding || 0);
    bMap[b].lots++;
  });

  var buyers = Object.values(bMap).sort(function (a, b) { return b.rec - a.rec; }).slice(0, 8);
  var maxVal = Math.max.apply(null, buyers.map(function (b) { return Math.max(b.rec, b.rcv); })) || 1;

  var w = 760, rowH = 46, padTop = 20, padLeft = 190, padRight = 60, padBottom = 25;
  var h = padTop + buyers.length * rowH + padBottom;
  var barW = w - padLeft - padRight;

  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="font-family:Inter,system-ui,sans-serif">';
  
  // Gridlines
  for (var i = 0; i <= 4; i++) {
    var gx = padLeft + (barW * (i / 4));
    var gVal = (maxVal * (i / 4));
    svg += '<line x1="' + gx + '" y1="' + padTop + '" x2="' + gx + '" y2="' + (h - padBottom) + '" stroke="currentColor" stroke-opacity="0.08" stroke-dasharray="2,2"/>';
    svg += '<text x="' + gx + '" y="' + (h - 8) + '" font-size="9.5" fill="currentColor" fill-opacity="0.45" text-anchor="middle">₹ ' + (gVal >= 10000000 ? (Math.round(gVal/100000)/100 + ' Cr') : (Math.round(gVal/1000) + 'k')) + '</text>';
  }

  buyers.forEach(function (b, idx) {
    var y = padTop + idx * rowH;
    var wRec = Math.max(2, (b.rec / maxVal) * barW);
    var wRcv = Math.max(2, (b.rcv / maxVal) * barW);
    var wOut = (b.out > 1) ? Math.max(2, (b.out / maxVal) * barW) : 0;
    var bName = b.buyer.length > 22 ? (b.buyer.slice(0, 20) + '…') : b.buyer;

    svg += '<text x="' + (padLeft - 10) + '" y="' + (y + 16) + '" font-size="11" font-weight="600" fill="currentColor" text-anchor="end">' + escHtml(bName) + '</text>';
    svg += '<text x="' + (padLeft - 10) + '" y="' + (y + 29) + '" font-size="9" fill="currentColor" fill-opacity="0.5" text-anchor="end">' + b.lots + ' lot(s)</text>';

    // Bars with data-pbi-tip
    var tipRec = '<b>' + escHtml(b.buyer) + '</b><br/>Total Receivables: <b>₹ ' + inr(b.rec) + '</b>';
    var tipRcv = '<b>' + escHtml(b.buyer) + '</b><br/>Total Received: <b>₹ ' + inr(b.rcv) + '</b> (' + Math.round((b.rcv / (b.rec || 1)) * 100) + '%)';
    var tipOut = '<b>' + escHtml(b.buyer) + '</b><br/>Outstanding Due: <b>₹ ' + inr(b.out) + '</b>';

    svg += '<rect x="' + padLeft + '" y="' + y + '" width="' + wRec + '" height="9" rx="2" fill="#0284c7" opacity="0.9" data-pbi-tip="' + escHtml(tipRec) + '" style="cursor:pointer"/>';
    svg += '<rect x="' + padLeft + '" y="' + (y + 11) + '" width="' + wRcv + '" height="9" rx="2" fill="#10b981" opacity="0.9" data-pbi-tip="' + escHtml(tipRcv) + '" style="cursor:pointer"/>';
    if (wOut > 0) {
      svg += '<rect x="' + padLeft + '" y="' + (y + 22) + '" width="' + wOut + '" height="6" rx="2" fill="#f43f5e" opacity="0.9" data-pbi-tip="' + escHtml(tipOut) + '" style="cursor:pointer"/>';
    }

    svg += '<text x="' + (padLeft + Math.max(wRec, wRcv) + 8) + '" y="' + (y + 16) + '" font-size="10" font-weight="700" fill="currentColor">₹ ' + inr(b.rcv) + '</text>';
  });

  svg += '</svg>';
  el.innerHTML = svg;
}

// Chart 2: Cash Inflow Composition (Donut SVG)
function renderCashInflowDonut(rows) {
  var el = document.getElementById('chartCashInflow');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var totSd = rows.reduce(function (a, r) { return a + (r.sd_received || 0); }, 0);
  var totFp = rows.reduce(function (a, r) { return a + (r.fp_received || 0); }, 0);
  var totOut = rows.reduce(function (a, r) { return a + (r.outstanding || 0); }, 0);
  var totAll = totSd + totFp + totOut;
  if (totAll <= 0) totAll = 1;

  var pSd = (totSd / totAll);
  var pFp = (totFp / totAll);
  var pOut = (totOut / totAll);

  var size = 260, r = 85, cx = 130, cy = 130, strokeW = 34;
  var circ = 2 * Math.PI * r;

  var offSd = 0;
  var dashSd = (pSd * circ) + ' ' + circ;
  var offFp = -(pSd * circ);
  var dashFp = (pFp * circ) + ' ' + circ;
  var offOut = -((pSd + pFp) * circ);
  var dashOut = (pOut * circ) + ' ' + circ;

  var tipSd = '<b>Security Deposit (SD)</b><br/>₹ ' + inr(totSd) + ' (' + Math.round(pSd * 100) + '%)';
  var tipFp = '<b>Final Payment (FP)</b><br/>₹ ' + inr(totFp) + ' (' + Math.round(pFp * 100) + '%)';
  var tipOut = '<b>Outstanding Balance</b><br/>₹ ' + inr(totOut) + ' (' + Math.round(pOut * 100) + '%)';

  var svg = '<svg viewBox="0 0 ' + size + ' ' + size + '" xmlns="http://www.w3.org/2000/svg" style="transform:rotate(-90deg);font-family:Inter,system-ui,sans-serif">' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="currentColor" stroke-opacity="0.06" stroke-width="' + strokeW + '"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="#38bdf8" stroke-width="' + strokeW + '" stroke-dasharray="' + dashSd + '" stroke-dashoffset="' + offSd + '" data-pbi-tip="' + escHtml(tipSd) + '" style="cursor:pointer"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="#10b981" stroke-width="' + strokeW + '" stroke-dasharray="' + dashFp + '" stroke-dashoffset="' + offFp + '" data-pbi-tip="' + escHtml(tipFp) + '" style="cursor:pointer"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="#f43f5e" stroke-width="' + strokeW + '" stroke-dasharray="' + dashOut + '" stroke-dashoffset="' + offOut + '" data-pbi-tip="' + escHtml(tipOut) + '" style="cursor:pointer"/>' +
  '</svg>' +
  '<div style="position:absolute;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center">' +
    '<div style="font-size:10px;font-weight:700;color:var(--dim);text-transform:uppercase">Collections</div>' +
    '<div style="font-size:15px;font-weight:800;color:var(--text);font-family:JetBrains Mono,monospace">₹ ' + inr(totSd + totFp) + '</div>' +
    '<div style="font-size:10.5px;color:#10b981;font-weight:700">' + Math.round(((totSd + totFp) / totAll) * 100) + '% Inflow</div>' +
  '</div>';

  var legendHtml = '<div style="display:flex;justify-content:center;gap:14px;margin-top:10px;flex-wrap:wrap">' +
    '<span class="pbi-leg-item"><span class="pbi-dot" style="background:#38bdf8"></span> SD: ₹ ' + inr(totSd) + ' (' + Math.round(pSd * 100) + '%)</span>' +
    '<span class="pbi-leg-item"><span class="pbi-dot" style="background:#10b981"></span> FP: ₹ ' + inr(totFp) + ' (' + Math.round(pFp * 100) + '%)</span>' +
    '<span class="pbi-leg-item"><span class="pbi-dot" style="background:#f43f5e"></span> Due: ₹ ' + inr(totOut) + ' (' + Math.round(pOut * 100) + '%)</span>' +
  '</div>';

  el.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;width:100%">' + svg + legendHtml + '</div>';
}

// Chart 3: Statutory Tax & Charges Waterfall
function renderWaterfallChart(rows) {
  var el = document.getElementById('chartWaterfall');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var totMat = rows.reduce(function (a, r) { return a + (r.mat_value || 0); }, 0);
  var totGst = rows.reduce(function (a, r) { return a + (r.gst || 0); }, 0);
  var totTcs = rows.reduce(function (a, r) { return a + (r.tcs || 0); }, 0);
  var totSc = rows.reduce(function (a, r) { return a + (r.service_charge_to_mstc || 0); }, 0);
  var tot194h = rows.reduce(function (a, r) { return a + (r.tds194h || 0); }, 0);
  var totGstTds = rows.reduce(function (a, r) { return a + (r.gst_tds || 0); }, 0);
  var totRec = rows.reduce(function (a, r) { return a + (r.total_receivables || 0); }, 0);

  var items = [
    { label: 'Base Material', val: totMat, type: 'base', color: '#0284c7' },
    { label: '+ GST 18%', val: totGst, type: 'add', color: '#6366f1' },
    { label: '+ TCS 1%', val: totTcs, type: 'add', color: '#8b5cf6' },
    { label: '+ MSTC SC', val: totSc, type: 'add', color: '#ec4899' },
    { label: '- TDS 194H', val: tot194h, type: 'sub', color: '#f59e0b' },
    { label: '- GST TDS 2%', val: totGstTds, type: 'sub', color: '#eab308' },
    { label: '= Net Receivables', val: totRec, type: 'total', color: '#10b981' }
  ];

  var maxVal = Math.max(totMat + totGst + totTcs + totSc, totRec) * 1.15 || 1;
  var w = 420, h = 230, padB = 40, padT = 20, padL = 35, padR = 15;
  var plotW = w - padL - padR, plotH = h - padT - padB;
  var colW = (plotW / items.length) - 6;

  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="font-family:Inter,system-ui,sans-serif">';
  
  var currH = 0;
  items.forEach(function (it, idx) {
    var x = padL + idx * (plotW / items.length) + 3;
    var barHeight = Math.max(3, (it.val / maxVal) * plotH);
    var y = (h - padB) - barHeight;

    if (it.type === 'base' || it.type === 'total') {
      currH = barHeight;
      y = (h - padB) - barHeight;
    } else if (it.type === 'add') {
      y = (h - padB) - (currH + barHeight);
      currH += barHeight;
    } else if (it.type === 'sub') {
      y = (h - padB) - currH;
      currH -= barHeight;
    }

    var tip = '<b>' + escHtml(it.label) + '</b><br/>Amount: <b>₹ ' + inr(it.val) + '</b>';
    svg += '<rect x="' + x + '" y="' + y + '" width="' + colW + '" height="' + barHeight + '" rx="2" fill="' + it.color + '" opacity="0.9" data-pbi-tip="' + escHtml(tip) + '" style="cursor:pointer"/>';
    svg += '<text x="' + (x + colW / 2) + '" y="' + (y - 4) + '" font-size="8.5" font-weight="700" fill="currentColor" text-anchor="middle">₹ ' + (Math.round(it.val/1000) + 'k') + '</text>';
    svg += '<text x="' + (x + colW / 2) + '" y="' + (h - padB + 14) + '" font-size="8" fill="currentColor" fill-opacity="0.65" text-anchor="middle">' + escHtml(it.label.split(' ')[0]) + '</text>';
  });

  svg += '</svg>';
  el.innerHTML = svg;
}

// Chart 4: Material Revenue Pareto (Dual Axis SVG)
function renderMaterialParetoChart(rows) {
  var el = document.getElementById('chartMaterialPareto');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var mMap = {};
  var totAll = 0;
  rows.forEach(function (r) {
    var m = r.lot_name || 'Scrap Material';
    if (!mMap[m]) mMap[m] = { name: m, val: 0, count: 0 };
    mMap[m].val += (r.mat_value || 0);
    mMap[m].count++;
    totAll += (r.mat_value || 0);
  });
  if (totAll <= 0) totAll = 1;

  var mats = Object.values(mMap).sort(function (a, b) { return b.val - a.val; }).slice(0, 6);
  var maxVal = mats[0] ? mats[0].val * 1.15 : 1;

  var w = 420, h = 230, padB = 40, padT = 20, padL = 35, padR = 35;
  var plotW = w - padL - padR, plotH = h - padT - padB;
  var colW = (plotW / mats.length) - 8;

  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="font-family:Inter,system-ui,sans-serif">';
  
  var linePts = [];
  var cumVal = 0;

  mats.forEach(function (m, idx) {
    var x = padL + idx * (plotW / mats.length) + 4;
    var barHeight = Math.max(3, (m.val / maxVal) * plotH);
    var y = (h - padB) - barHeight;

    cumVal += m.val;
    var cumPct = Math.min(100, Math.round((cumVal / totAll) * 100));
    var lineY = (h - padB) - (cumPct / 100) * plotH;
    var lineX = x + colW / 2;
    linePts.push({ x: lineX, y: lineY, pct: cumPct });

    var tip = '<b>' + escHtml(m.name) + '</b><br/>Revenue: <b>₹ ' + inr(m.val) + '</b><br/>Cumulative Contribution: <b>' + cumPct + '%</b>';
    svg += '<rect x="' + x + '" y="' + y + '" width="' + colW + '" height="' + barHeight + '" rx="2" fill="#0284c7" opacity="0.85" data-pbi-tip="' + escHtml(tip) + '" style="cursor:pointer"/>';
    svg += '<text x="' + (x + colW / 2) + '" y="' + (h - padB + 14) + '" font-size="8" fill="currentColor" fill-opacity="0.65" text-anchor="middle">' + escHtml(m.name.slice(0, 7)) + '…</text>';
  });

  // Cumulative percentage line
  if (linePts.length > 1) {
    var d = 'M ' + linePts.map(function (p) { return p.x + ' ' + p.y; }).join(' L ');
    svg += '<path d="' + d + '" fill="none" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round"/>';
    linePts.forEach(function (p) {
      svg += '<circle cx="' + p.x + '" cy="' + p.y + '" r="3.5" fill="#f59e0b" stroke="#ffffff" stroke-width="1.5"/>';
      svg += '<text x="' + p.x + '" y="' + (p.y - 7) + '" font-size="8.5" font-weight="800" fill="#f59e0b" text-anchor="middle">' + p.pct + '%</text>';
    });
  }

  svg += '</svg>';
  el.innerHTML = svg;
}

// Chart 5: Auction Financial Realization
function renderAuctionPerfChart(rows) {
  var el = document.getElementById('chartAuctionPerf');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var aMap = {};
  rows.forEach(function (r) {
    var a = r.auction || 'General Auction';
    if (!aMap[a]) aMap[a] = { name: a, rec: 0, rcv: 0, lots: 0 };
    aMap[a].rec += (r.total_receivables || 0);
    aMap[a].rcv += (r.total_received || 0);
    aMap[a].lots++;
  });

  var aucs = Object.values(aMap).slice(0, 5);
  var maxVal = Math.max.apply(null, aucs.map(function (a) { return Math.max(a.rec, a.rcv); })) * 1.15 || 1;

  var w = 420, h = 230, padB = 40, padT = 20, padL = 40, padR = 20;
  var plotW = w - padL - padR, plotH = h - padT - padB;
  var groupW = plotW / aucs.length;
  var barW = (groupW / 2) - 4;

  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="font-family:Inter,system-ui,sans-serif">';

  aucs.forEach(function (a, idx) {
    var gx = padL + idx * groupW + 3;
    var hRec = Math.max(3, (a.rec / maxVal) * plotH);
    var hRcv = Math.max(3, (a.rcv / maxVal) * plotH);
    var yRec = (h - padB) - hRec;
    var yRcv = (h - padB) - hRcv;

    var tipRec = '<b>Auction ' + escHtml(a.name) + '</b><br/>Total Receivables: <b>₹ ' + inr(a.rec) + '</b>';
    var tipRcv = '<b>Auction ' + escHtml(a.name) + '</b><br/>Total Realized: <b>₹ ' + inr(a.rcv) + '</b> (' + Math.round((a.rcv / (a.rec || 1)) * 100) + '%)';

    svg += '<rect x="' + gx + '" y="' + yRec + '" width="' + barW + '" height="' + hRec + '" rx="2" fill="#0284c7" data-pbi-tip="' + escHtml(tipRec) + '" style="cursor:pointer"/>';
    svg += '<rect x="' + (gx + barW + 2) + '" y="' + yRcv + '" width="' + barW + '" height="' + hRcv + '" rx="2" fill="#10b981" data-pbi-tip="' + escHtml(tipRcv) + '" style="cursor:pointer"/>';

    svg += '<text x="' + (gx + groupW / 2 - 2) + '" y="' + (h - padB + 14) + '" font-size="8.5" fill="currentColor" fill-opacity="0.65" text-anchor="middle">' + escHtml(a.name.slice(0, 8)) + '</text>';
  });

  svg += '</svg>';
  el.innerHTML = svg;
}

// Chart 6: Payment Delay & Ageing Analysis
function renderAgeingChart(rows) {
  var el = document.getElementById('chartAgeing');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var b0 = { label: 'On Time (≤ 24 Aug)', count: 0, mat: 0, late: 0, color: '#10b981' };
  var b1 = { label: '1–7 Days (1.18%)', count: 0, mat: 0, late: 0, color: '#38bdf8' };
  var b2 = { label: '8–14 Days (2.36%)', count: 0, mat: 0, late: 0, color: '#f59e0b' };
  var b3 = { label: '> 14 Days (> 3.54%)', count: 0, mat: 0, late: 0, color: '#f43f5e' };

  rows.forEach(function (r) {
    var wks = calcLateFeeWeeks(r);
    var fee = r.late_fee || 0;
    if (wks <= 0) { b0.count++; b0.mat += (r.mat_value || 0); b0.late += fee; }
    else if (wks === 1) { b1.count++; b1.mat += (r.mat_value || 0); b1.late += fee; }
    else if (wks === 2) { b2.count++; b2.mat += (r.mat_value || 0); b2.late += fee; }
    else { b3.count++; b3.mat += (r.mat_value || 0); b3.late += fee; }
  });

  var buckets = [b0, b1, b2, b3];
  var maxMat = Math.max.apply(null, buckets.map(function (b) { return b.mat; })) * 1.15 || 1;

  var w = 420, h = 230, padB = 40, padT = 20, padL = 40, padR = 20;
  var plotW = w - padL - padR, plotH = h - padT - padB;
  var colW = (plotW / buckets.length) - 10;

  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="font-family:Inter,system-ui,sans-serif">';

  buckets.forEach(function (b, idx) {
    var x = padL + idx * (plotW / buckets.length) + 5;
    var barH = Math.max(3, (b.mat / maxMat) * plotH);
    var y = (h - padB) - barH;

    var tip = '<b>' + escHtml(b.label) + '</b><br/>Lots: <b>' + b.count + '</b><br/>Material Value: <b>₹ ' + inr(b.mat) + '</b><br/>Delayed Charges: <b>₹ ' + inr(b.late) + '</b>';
    svg += '<rect x="' + x + '" y="' + y + '" width="' + colW + '" height="' + barH + '" rx="2" fill="' + b.color + '" opacity="0.9" data-pbi-tip="' + escHtml(tip) + '" style="cursor:pointer"/>';
    svg += '<text x="' + (x + colW / 2) + '" y="' + (y - 5) + '" font-size="8.5" font-weight="700" fill="currentColor" text-anchor="middle">' + b.count + ' lots</text>';
    svg += '<text x="' + (x + colW / 2) + '" y="' + (h - padB + 14) + '" font-size="8" fill="currentColor" fill-opacity="0.65" text-anchor="middle">' + escHtml(b.label.split(' ')[0]) + '</text>';
  });

  svg += '</svg>';
  el.innerHTML = svg;
}

// Chart 7: Top Buyers Realization Leaderboard Table
function renderBuyerLeaderboardTable(rows) {
  var el = document.getElementById('tableBuyerLeaderboard');
  if (!el) return;
  if (rows.length === 0) { el.innerHTML = '<p class="muted" style="padding:40px;text-align:center">No data</p>'; return; }

  var bMap = {};
  rows.forEach(function (r) {
    var b = r.buyer || 'Unknown Buyer';
    if (!bMap[b]) bMap[b] = { buyer: b, lots: 0, mat: 0, rec: 0, rcv: 0, out: 0 };
    bMap[b].lots++;
    bMap[b].mat += (r.mat_value || 0);
    bMap[b].rec += (r.total_receivables || 0);
    bMap[b].rcv += (r.total_received || 0);
    bMap[b].out += (r.outstanding || 0);
  });

  var buyers = Object.values(bMap).sort(function (a, b) { return b.rec - a.rec; });

  var html = '<table class="pbi-table">' +
    '<thead>' +
      '<tr>' +
        '<th style="width:40px">#</th>' +
        '<th>Buyer Name</th>' +
        '<th style="text-align:right">Lots</th>' +
        '<th style="text-align:right">Material Value</th>' +
        '<th style="text-align:right">Receivables</th>' +
        '<th style="text-align:right">Received</th>' +
        '<th style="text-align:right">Outstanding</th>' +
        '<th style="width:140px">Realization %</th>' +
        '<th style="text-align:center">Status</th>' +
      '</tr>' +
    '</thead>' +
    '<tbody>' +
      buyers.map(function (b, idx) {
        var pct = b.rec > 0 ? Math.min(100, Math.round((b.rcv / b.rec) * 100)) : 0;
        var isStl = b.out <= SETTLEMENT_TOLERANCE;
        var chipHtml = isStl ?
          '<span class="badge" style="color:#10b981;border:1px solid rgba(16,185,129,0.3);background:rgba(16,185,129,0.08);padding:2px 8px;border-radius:99px;font-size:10.5px">Settled</span>' :
          '<span class="badge" style="color:#f43f5e;border:1px solid rgba(244,63,94,0.3);background:rgba(244,63,94,0.08);padding:2px 8px;border-radius:99px;font-size:10.5px">Unsettled</span>';

        return '<tr>' +
          '<td style="color:var(--dim);font-weight:700">' + (idx + 1) + '</td>' +
          '<td style="font-weight:600;color:var(--text)">' + escHtml(b.buyer) + '</td>' +
          '<td style="text-align:right">' + b.lots + '</td>' +
          '<td style="text-align:right">₹ ' + inr(b.mat) + '</td>' +
          '<td style="text-align:right;font-weight:700;color:#0284c7">₹ ' + inr(b.rec) + '</td>' +
          '<td style="text-align:right;font-weight:700;color:#10b981">₹ ' + inr(b.rcv) + '</td>' +
          '<td style="text-align:right;font-weight:700;color:' + (b.out > 1 ? '#f43f5e' : '#10b981') + '">₹ ' + inr(b.out) + '</td>' +
          '<td>' +
            '<div class="pbi-bar-cell">' +
              '<div class="pbi-mini-track"><div class="pbi-mini-fill" style="width:' + pct + '%;background:' + (pct >= 99 ? '#10b981' : '#0284c7') + '"></div></div>' +
              '<span style="font-size:11px;font-weight:700">' + pct + '%</span>' +
            '</div>' +
          '</td>' +
          '<td style="text-align:center">' + chipHtml + '</td>' +
        '</tr>';
      }).join('') +
    '</tbody>' +
  '</table>';

  el.innerHTML = html;
}
"""

if pos != -1 and pos_end != -1:
    text = text[:pos] + clean_analytics_engine + "\n" + text[pos_end:]
    print("Replaced analytics engine with clean tooltip data attributes!")
else:
    print("Warning: analytics engine position not found!")

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("index.html saved successfully!")
