with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add toolbar filter buttons listeners
old_reset_listener = """var resetPivotBtn = document.getElementById('resetPivotFiltersBtn');
  if (resetPivotBtn) {
    resetPivotBtn.addEventListener('click', resetPivotFilters);
  }
  var resetDetailBtn = document.getElementById('resetDetailFiltersBtn');
  if (resetDetailBtn) {
    resetDetailBtn.addEventListener('click', resetDetailFilters);
  }"""

new_reset_listener = """var resetPivotBtn = document.getElementById('resetPivotFiltersBtn');
  if (resetPivotBtn) {
    resetPivotBtn.addEventListener('click', resetPivotFilters);
  }
  var pivotColFilterBtn = document.getElementById('pivotColFilterBtn');
  if (pivotColFilterBtn) {
    pivotColFilterBtn.addEventListener('click', function () {
      openTableFilterModal('pivot');
    });
  }
  var resetDetailBtn = document.getElementById('resetDetailFiltersBtn');
  if (resetDetailBtn) {
    resetDetailBtn.addEventListener('click', resetDetailFilters);
  }
  var detailColFilterBtn = document.getElementById('detailColFilterBtn');
  if (detailColFilterBtn) {
    detailColFilterBtn.addEventListener('click', function () {
      openTableFilterModal('detail');
    });
  }"""

if old_reset_listener in text:
    text = text.replace(old_reset_listener, new_reset_listener)
    print("Added toolbar filter buttons listeners")
else:
    print("Warning: old_reset_listener not matched")

# 2. Add .th-filt-btn click handler in delegated click listener
old_frz_block = """    var frz = (e.target && e.target.closest) ? e.target.closest('.th-freeze') : null;
    if (frz) {
      e.preventDefault();
      e.stopPropagation();
      setFreezeDetail(frz.getAttribute('data-freeze'));
      return;
    }"""

new_frz_block = """    var filtBtn = (e.target && e.target.closest) ? e.target.closest('.th-filt-btn, [data-filter-field]') : null;
    if (filtBtn) {
      e.preventDefault();
      e.stopPropagation();
      var targetTh = filtBtn.closest('th[data-field]');
      if (targetTh) {
        var rect = filtBtn.getBoundingClientRect();
        showHeaderContextMenu(rect.left, rect.bottom + 4, targetTh);
      }
      return;
    }
    var frz = (e.target && e.target.closest) ? e.target.closest('.th-freeze') : null;
    if (frz) {
      e.preventDefault();
      e.stopPropagation();
      setFreezeDetail(frz.getAttribute('data-freeze'));
      return;
    }"""

if old_frz_block in text:
    text = text.replace(old_frz_block, new_frz_block)
    print("Added .th-filt-btn delegated click listener")
else:
    print("Warning: old_frz_block not matched")

# 3. Add touch long press listener
long_press_code = """
  /* Mobile touch long-press on table headers to open context / filter menu */
  (function () {
    var longPressTimer = null;
    var longPressStartX = 0, longPressStartY = 0;
    var longPressTh = null;

    document.addEventListener('touchstart', function (e) {
      if (!e.touches || !e.touches[0]) return;
      var th = e.target.closest && e.target.closest('th[data-field]');
      if (th && (th.dataset.table === 'detail' || th.dataset.table === 'pivot')) {
        longPressTh = th;
        var touch = e.touches[0];
        longPressStartX = touch.clientX;
        longPressStartY = touch.clientY;
        if (longPressTimer) clearTimeout(longPressTimer);
        longPressTimer = setTimeout(function () {
          if (longPressTh === th) {
            if (navigator.vibrate) { try { navigator.vibrate(30); } catch (ignore) {} }
            showHeaderContextMenu(longPressStartX, longPressStartY, th);
            longPressTimer = null;
          }
        }, 420);
      }
    }, { passive: true });

    document.addEventListener('touchmove', function (e) {
      if (longPressTimer && e.touches && e.touches[0]) {
        var touch = e.touches[0];
        if (Math.abs(touch.clientX - longPressStartX) > 10 || Math.abs(touch.clientY - longPressStartY) > 10) {
          clearTimeout(longPressTimer);
          longPressTimer = null;
        }
      }
    }, { passive: true });

    document.addEventListener('touchend', function () {
      if (longPressTimer) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
      }
    }, { passive: true });
  })();
"""

if '/* Mobile touch long-press on table headers' not in text:
    target_pos = text.find("document.addEventListener('contextmenu', function (e) {")
    if target_pos != -1:
        text = text[:target_pos] + long_press_code + '\n  ' + text[target_pos:]
        print("Added mobile touch long-press listener")
    else:
        print("Warning: contextmenu listener target position not found")

with open('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'w', encoding='utf-8') as f:
    f.write(text)

# Also synchronize to index.html and uploads
with open('/home/user/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

with open('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html', 'w', encoding='utf-8') as f:
    f.write(text)

print("Step 3 complete. Synchronized all copies.")
