const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  // Click on a lot no. in Lot Details
  const firstLotCell = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (firstLotCell) {
    console.log('Clicking on lot no...');
    await firstLotCell.click();
    await page.waitForTimeout(400);
    await page.screenshot({ path: '/home/user/mobile_lot_modal_test.png' });
    console.log('Saved mobile_lot_modal_test.png');
  } else {
    console.log('firstLotCell not found');
  }

  await browser.close();
})();
