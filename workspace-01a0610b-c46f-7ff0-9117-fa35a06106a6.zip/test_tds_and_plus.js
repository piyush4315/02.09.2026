const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 950 } });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);

  console.log('=== 1. Checking TDS 194(H) Header in Lot Details ===');
  // Expand bifurcation columns 12-15 by clicking parent header (Col 16) or evaluating
  await page.evaluate(() => {
    if (ui.collapseChargeCols) toggleChargeGroup();
  });
  await page.waitForTimeout(300);

  const tdsHeader = await page.evaluate(() => {
    const th = document.querySelector('#detailTableDash thead th[data-field="tds194h"] .th-label');
    return th ? th.textContent.trim() : 'not found';
  });
  console.log('TDS 194(H) Column Header:', JSON.stringify(tdsHeader));

  console.log('\n=== 2. Checking TDS 194(H) Cell values in Lot Details ===');
  const tdsCells = await page.evaluate(() => {
    const cells = Array.from(document.querySelectorAll('#detailTableDash tbody td[data-field="tds194h"]')).map(td => td.textContent.trim());
    const tfootCell = document.querySelector('#detailTableDash tfoot td[data-field="tds194h"]')?.textContent.trim();
    return { sampleCells: cells.slice(0, 5), tfootCell };
  });
  console.log('TDS 194(H) Data Cells sample:', tdsCells.sampleCells);
  console.log('TDS 194(H) Total Row Cell:', tdsCells.tfootCell);

  const allHaveMinus = tdsCells.sampleCells.every(c => c.startsWith('-') || c === '—');
  if (allHaveMinus && tdsCells.tfootCell.startsWith('-')) {
    console.log('PASS: All TDS 194(H) cells and footer total display with - sign!');
  } else {
    console.error('FAIL: TDS 194(H) cells missing - sign:', tdsCells);
    process.exit(1);
  }

  console.log('\n=== 3. Checking TDS 194(H) in Lot Inspector Modal ===');
  const firstLotCell = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (firstLotCell) {
    await firstLotCell.click();
    await page.waitForTimeout(400);

    const modalTdsInfo = await page.evaluate(() => {
      const modal = document.querySelector('.modal');
      if (!modal) return null;
      const rows = Array.from(modal.querySelectorAll('.lic-row')).map(r => ({
        k: r.querySelector('.lic-k')?.textContent.trim(),
        v: r.querySelector('.lic-v')?.textContent.trim()
      })).filter(r => r.k && r.k.includes('194(H)'));
      return rows;
    });
    console.log('Lot Inspector Modal TDS 194(H) rows:', modalTdsInfo);

    // Close modal
    await page.click('.modal-foot .btn:has-text("Close"), .modal .xclose');
    await page.waitForTimeout(300);
  }

  console.log('\n=== 4. Checking Hidden Column Buttons (No + icon) ===');
  await page.evaluate(() => {
    colLayout.detail = colLayout.detail.filter(k => k !== 'mat_value' && k !== 'gst');
    colLayout.pivotMetric = colLayout.pivotMetric.filter(k => k !== 'tcs' && k !== 'gst');
    renderAll();
  });
  await page.waitForTimeout(300);

  const detailToggles = await page.$$eval('#dashColToggles .col-toggle.off', els => els.map(e => e.textContent.trim()));
  const pivotToggles = await page.$$eval('#pivotColToggles .col-toggle.off', els => els.map(e => e.textContent.trim()));

  console.log('Lot Details Hidden Buttons:', detailToggles);
  console.log('Pivot Analytics Hidden Buttons:', pivotToggles);

  const anyPlus = detailToggles.concat(pivotToggles).some(t => t.startsWith('+') || t.includes('＋'));
  if (anyPlus) {
    console.error('FAIL: Hidden button still contains + icon!');
    process.exit(1);
  } else {
    console.log('PASS: All hidden buttons are completely clean with NO + icon!');
  }

  await page.screenshot({ path: '/home/user/tds_194h_minus_proof.png' });
  console.log('Saved proof screenshot.');

  await browser.close();
  console.log('\nALL CHECKS PASSED SUCCESSFULLY!');
})();
