const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(500);

  // Open Payment Advice modal for the first buyer
  await page.evaluate(() => {
    openPaymentAdvice(0);
  });
  await page.waitForTimeout(500);

  // Check action buttons in modal
  const actionButtons = await page.evaluate(() => {
    const modal = document.querySelector(".modal, .modal-wrap");
    if (!modal) return [];
    const btns = Array.from(modal.querySelectorAll(".modal-foot button, .modal-actions button, button"));
    return btns.map(b => b.innerText.trim()).filter(t => t.length > 0);
  });
  console.log("Modal Buttons:", actionButtons);

  // Verify WhatsApp and Email buttons are not present
  const hasWhatsapp = actionButtons.some(t => t.toLowerCase().includes("whatsapp"));
  const hasEmail = actionButtons.some(t => t.toLowerCase().includes("email"));

  console.log("Has WhatsApp Advice Button:", hasWhatsapp);
  console.log("Has Email Format Button:", hasEmail);

  await page.screenshot({ path: "/home/user/payment_advice_clean_buttons_proof.png" });

  await browser.close();
  if (hasWhatsapp || hasEmail) {
    console.error("FAILED: WhatsApp or Email button still found!");
    process.exit(1);
  } else {
    console.log("SUCCESS: Both Copy WhatsApp Advice and Copy Email Format buttons removed.");
  }
})();
