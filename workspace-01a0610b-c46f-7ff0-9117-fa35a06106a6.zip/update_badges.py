with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Dark mode badges and settled styling
idx1 = text.find(".settled-counts{display:inline-flex;")
idx2 = text.find("td.date{text-align:center;color:var(--dim);font-size:10.5px}")

print("Found dark block:", idx1, idx2)
if idx1 != -1 and idx2 != -1:
    new_dark_block = """.settled-counts{display:inline-flex;align-items:center;gap:4px;justify-content:flex-end;width:100%}
.lbl-settled,.lbl-unsettled,.settled-counts .seg{
  display:inline-flex;align-items:center;justify-content:center;
  font-size:9.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;
  border-radius:999px;padding:2.5px 9px;line-height:1.15;white-space:nowrap;
}
.settled-counts .seg{gap:3px;padding:2.5px 8px}
.settled-counts .seg.zero{padding:2.5px 10px;letter-spacing:.6px}
.lbl-settled,.settled-counts .seg.s{
  background:linear-gradient(135deg,#10b981 0%,#22c55e 100%);
  color:#ffffff;
  box-shadow:0 0 14px rgba(34,197,94,.4),inset 0 0 0 1px rgba(167,243,208,.4);
}
.lbl-unsettled,.settled-counts .seg.u{
  background:#f72585;
  color:#ffffff;
  box-shadow:0 0 12px rgba(247,37,133,.35);
}
td.left{text-align:left;font-weight:400}
td.strong{color:var(--cyan);font-weight:400}
td.pos{color:#f9a8d4;font-weight:400}
td.neg{color:#86efac;font-weight:400}
td.zero{color:var(--dim)}
tbody tr:not(.settled) td{color:#e2e8f0}
td.status{text-align:center}
"""
    text = text[:idx1] + new_dark_block + text[idx2:]
    print("Updated dark mode badges block")

# 2. Light mode badges and settled styling
idx3 = text.find("/* Status Chips & Badges */")
idx4 = text.find("/* Menus, Popups, Date Picker & Modals */")

print("Found light block:", idx3, idx4)
if idx3 != -1 and idx4 != -1:
    new_light_block = """/* Status Chips & Badges */
[data-theme="light"] .lbl-settled,
[data-theme="light"] .settled-counts .seg.s {
  background: #f0fdf4 !important;
  border: 1px solid #bbf7d0 !important;
  color: #15803d !important;
  box-shadow: none !important;
}
[data-theme="light"] .lbl-unsettled,
[data-theme="light"] .settled-counts .seg.u {
  background: #fff1f2 !important;
  border: 1px solid #fecdd3 !important;
  color: #be123c !important;
  box-shadow: none !important;
}

[data-theme="light"] tbody tr.settled td:not(.status),
[data-theme="light"] tbody tr.settled td:not(.status) *,
[data-theme="light"] tbody tr.settled td.left,
[data-theme="light"] tbody tr.settled td.strong,
[data-theme="light"] tbody tr.settled td.pos,
[data-theme="light"] tbody tr.settled td.neg,
[data-theme="light"] tbody tr.settled td.zero,
[data-theme="light"] tbody tr.settled td.date,
[data-theme="light"] tbody tr.settled td.invno,
[data-theme="light"] tbody tr.settled .inv-link,
[data-theme="light"] tbody tr.settled td.edit input {
  color: #16a34a !important;
  text-shadow: none;
}
[data-theme="light"] tbody tr.settled {
  background: rgba(22, 163, 74, 0.04);
}
[data-theme="light"] tbody tr.settled:hover {
  background: rgba(22, 163, 74, 0.08) !important;
}

"""
    text = text[:idx3] + new_light_block + text[idx4:]
    print("Updated light mode badges block")

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("Saved index.html successfully")
