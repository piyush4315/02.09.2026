import re

def add_hand_tool(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Add CSS for Hand Tool and Panning
    hand_css = """
/* ── HAND PAN TOOL (Mobile-like Touch Drag & Pan) ── */
.hand-tool-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
.hand-tool-btn .hand-icon {
  font-size: 14px;
  display: inline-block;
  transition: transform 0.2s ease;
}
.hand-tool-btn:hover .hand-icon {
  transform: scale(1.2) rotate(-5deg);
}
.hand-tool-btn.active {
  background: rgba(0, 245, 255, 0.16) !important;
  border-color: rgba(0, 245, 255, 0.6) !important;
  color: var(--cyan) !important;
  box-shadow: 0 0 16px rgba(0, 245, 255, 0.35), inset 0 0 8px rgba(0, 245, 255, 0.2) !important;
}
[data-theme="light"] .hand-tool-btn.active {
  background: #eff6ff !important;
  border-color: #2563eb !important;
  color: #1d4ed8 !important;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.2), inset 0 0 0 1px #2563eb !important;
}

/* Hand Mode active state on Table Wrappers */
body.hand-mode-active .table-wrap,
body.hand-mode-active table,
body.hand-mode-active td,
body.hand-mode-active th,
body.hand-mode-active tr,
body.hand-mode-active table input {
  cursor: grab !important;
  user-select: none !important;
  -webkit-user-select: none !important;
}
body.hand-mode-active.hand-panning .table-wrap,
body.hand-mode-active.hand-panning table,
body.hand-mode-active.hand-panning td,
body.hand-mode-active.hand-panning th,
body.hand-mode-active.hand-panning tr,
body.hand-mode-active.hand-panning table input {
  cursor: grabbing !important;
  user-select: none !important;
  -webkit-user-select: none !important;
}

/* Floating Hand Mode Quick Toast Indicator */
#handModeBadge {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  z-index: 150;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  background: rgba(13, 13, 36, 0.95);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(0, 245, 255, 0.4);
  color: var(--cyan);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6), 0 0 20px rgba(0, 245, 255, 0.25);
  pointer-events: none;
  opacity: 0;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
#handModeBadge.show {
  transform: translateX(-50%) translateY(0);
  opacity: 1;
}
[data-theme="light"] #handModeBadge {
  background: #ffffff;
  border-color: #93c5fd;
  color: #1d4ed8;
  box-shadow: 0 12px 32px rgba(15, 23, 42, 0.15), 0 2px 8px rgba(37, 99, 235, 0.15);
}
"""

    if '/* ── HAND PAN TOOL' not in content:
        content = content.replace('/* Theme Toggle Button Component */', hand_css + '\n/* Theme Toggle Button Component */')

    # 2. Add Hand Tool Button in Topbar (.top-actions)
    button_html = """          <button class="btn hand-tool-btn" id="handToolBtn" type="button" title="Touch / Hand Pan Tool (Shortcut: H or hold Space) — Click and drag to smoothly glide and pan across table cells" aria-label="Toggle Hand Pan Mode">
            <span class="hand-icon">✋</span>
            <span id="handToolText">Hand Pan</span>
          </button>
"""
    if 'id="handToolBtn"' not in content:
        content = content.replace(
            '<button class="btn" id="undoBtn"',
            button_html + '          <button class="btn" id="undoBtn"'
        )

    # 3. Add #handModeBadge DOM element
    badge_html = """<div id="handModeBadge"><span>✋</span> Hand Pan Mode active — Drag to glide across cells <span style="font-size:10px;opacity:0.75">(Press H or click Hand to exit)</span></div>\n"""
    if 'id="handModeBadge"' not in content:
        content = content.replace('<div id="gridSelInfo"></div>', badge_html + '<div id="gridSelInfo"></div>')

    # 4. Add JavaScript Hand Pan Controller
    js_hand_engine = """
/* ==========================================================================
   HAND PAN TOOL (Mobile-like Touch Drag & Kinetic Inertia Panning)
   ========================================================================== */
var handPanState = {
  active: false,
  isDragging: false,
  startX: 0,
  startY: 0,
  startScrollLeft: 0,
  startScrollTop: 0,
  activeWrap: null,
  lastX: 0,
  lastY: 0,
  lastTime: 0,
  velocityX: 0,
  velocityY: 0,
  animId: null,
  hasMoved: false,
  spacePressed: false
};

function setHandMode(active, showNotice) {
  handPanState.active = !!active;
  if (ui) ui.handModeActive = handPanState.active;
  var btn = document.getElementById('handToolBtn');
  var badge = document.getElementById('handModeBadge');
  
  if (handPanState.active) {
    document.body.classList.add('hand-mode-active');
    if (btn) {
      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');
    }
    if (badge && showNotice !== false) {
      badge.classList.add('show');
      clearTimeout(badge._timer);
      badge._timer = setTimeout(function() {
        if (badge) badge.classList.remove('show');
      }, 3000);
    }
  } else {
    document.body.classList.remove('hand-mode-active', 'hand-panning');
    if (btn) {
      btn.classList.remove('active');
      btn.setAttribute('aria-pressed', 'false');
    }
    if (badge) badge.classList.remove('show');
    if (handPanState.animId) {
      cancelAnimationFrame(handPanState.animId);
      handPanState.animId = null;
    }
  }
}

function toggleHandMode() {
  setHandMode(!handPanState.active, true);
  showToast(handPanState.active ? '✋ Hand Pan Mode ON — Drag to glide across cells (H to toggle)' : '👆 Cursor Mode — Normal cell selection & editing', 'ok');
}

window.setHandMode = setHandMode;
window.toggleHandMode = toggleHandMode;

function initHandPanEngine() {
  var btn = document.getElementById('handToolBtn');
  if (btn) btn.addEventListener('click', toggleHandMode);

  // Keyboard shortcut: 'H' toggles hand mode; holding 'Space' temporarily activates it
  document.addEventListener('keydown', function (e) {
    var tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
    var isInput = tag === 'input' || tag === 'textarea' || tag === 'select' || (e.target && e.target.isContentEditable);
    if (isInput) return;

    if (e.key === 'h' || e.key === 'H') {
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        toggleHandMode();
        return;
      }
    }

    if (e.code === 'Space' && !handPanState.spacePressed && !e.ctrlKey && !e.metaKey && !e.altKey) {
      handPanState.spacePressed = true;
      if (!handPanState.active) {
        document.body.classList.add('hand-mode-active');
        var b = document.getElementById('handToolBtn');
        if (b) b.classList.add('active');
      }
    }
  });

  document.addEventListener('keyup', function (e) {
    if (e.code === 'Space' && handPanState.spacePressed) {
      handPanState.spacePressed = false;
      if (!handPanState.active) {
        document.body.classList.remove('hand-mode-active', 'hand-panning');
        var b = document.getElementById('handToolBtn');
        if (b) b.classList.remove('active');
      }
    }
  });

  // Touch & Pointer Drag Listeners on all table wrappers
  function isHandActive() {
    return handPanState.active || handPanState.spacePressed;
  }

  function handlePanStart(e) {
    if (!isHandActive() && e.type !== 'touchstart') return;
    var target = e.target;
    var wrap = target.closest ? target.closest('.table-wrap') : null;
    if (!wrap) return;

    // If in hand mode or space held down, initiate drag panning
    if (isHandActive() || (e.touches && e.touches.length === 1)) {
      if (handPanState.animId) {
        cancelAnimationFrame(handPanState.animId);
        handPanState.animId = null;
      }

      var clientX = e.touches ? e.touches[0].clientX : e.clientX;
      var clientY = e.touches ? e.touches[0].clientY : e.clientY;

      handPanState.isDragging = true;
      handPanState.hasMoved = false;
      handPanState.activeWrap = wrap;
      handPanState.startX = clientX;
      handPanState.startY = clientY;
      handPanState.lastX = clientX;
      handPanState.lastY = clientY;
      handPanState.lastTime = performance.now();
      handPanState.startScrollLeft = wrap.scrollLeft;
      handPanState.startScrollTop = window.pageYOffset || document.documentElement.scrollTop;
      handPanState.velocityX = 0;
      handPanState.velocityY = 0;

      if (isHandActive()) {
        document.body.classList.add('hand-panning');
        if (e.type === 'mousedown') e.preventDefault();
      }
    }
  }

  function handlePanMove(e) {
    if (!handPanState.isDragging || !handPanState.activeWrap) return;

    var clientX = e.touches ? e.touches[0].clientX : e.clientX;
    var clientY = e.touches ? e.touches[0].clientY : e.clientY;
    var deltaX = clientX - handPanState.startX;
    var deltaY = clientY - handPanState.startY;

    if (Math.abs(deltaX) > 3 || Math.abs(deltaY) > 3) {
      handPanState.hasMoved = true;
    }

    if (handPanState.hasMoved) {
      if (e.cancelable && isHandActive()) e.preventDefault();

      // Pan horizontally inside the table-wrap
      handPanState.activeWrap.scrollLeft = handPanState.startScrollLeft - deltaX;

      // Pan vertically (page scroll)
      var now = performance.now();
      var dt = Math.max(1, now - handPanState.lastTime);
      var moveX = clientX - handPanState.lastX;
      var moveY = clientY - handPanState.lastY;

      window.scrollBy(0, -moveY);

      handPanState.velocityX = moveX / dt;
      handPanState.velocityY = moveY / dt;
      handPanState.lastX = clientX;
      handPanState.lastY = clientY;
      handPanState.lastTime = now;
    }
  }

  function handlePanEnd(e) {
    if (!handPanState.isDragging) return;
    handPanState.isDragging = false;
    document.body.classList.remove('hand-panning');

    var wrap = handPanState.activeWrap;
    if (!wrap) return;

    // Apply kinetic momentum inertia if flicked
    var vx = handPanState.velocityX;
    var vy = handPanState.velocityY;
    var speed = Math.sqrt(vx * vx + vy * vy);

    if (speed > 0.15 && handPanState.hasMoved) {
      var friction = 0.94;
      function stepMomentum() {
        if (Math.abs(vx) < 0.05 && Math.abs(vy) < 0.05) {
          handPanState.animId = null;
          return;
        }
        if (wrap) wrap.scrollLeft -= vx * 16;
        window.scrollBy(0, -vy * 16);
        vx *= friction;
        vy *= friction;
        handPanState.animId = requestAnimationFrame(stepMomentum);
      }
      handPanState.animId = requestAnimationFrame(stepMomentum);
    }
  }

  // Intercept click events on table cells if a pan just occurred
  document.addEventListener('click', function (e) {
    if (handPanState.hasMoved && (isHandActive() || e.target.closest('.table-wrap'))) {
      e.preventDefault();
      e.stopPropagation();
      handPanState.hasMoved = false;
    }
  }, true);

  // Global move & up handlers
  document.addEventListener('mousedown', handlePanStart, { passive: false });
  document.addEventListener('mousemove', handlePanMove, { passive: false });
  document.addEventListener('mouseup', handlePanEnd);

  document.addEventListener('touchstart', handlePanStart, { passive: true });
  document.addEventListener('touchmove', handlePanMove, { passive: false });
  document.addEventListener('touchend', handlePanEnd);
  document.addEventListener('touchcancel', handlePanEnd);
}
"""

    if 'function initHandPanEngine' not in content:
        content = content.replace('init();', js_hand_engine + '\ninitHandPanEngine();\ninit();')

    # 5. Suppress grid selection when hand mode is active
    old_grid_pointer = "function gridHandlePointer(e, isMove) {"
    new_grid_pointer = """function gridHandlePointer(e, isMove) {
  if (typeof handPanState !== 'undefined' && (handPanState.active || handPanState.spacePressed || handPanState.isDragging)) return;"""
    if old_grid_pointer in content and "handPanState.active" not in content:
        content = content.replace(old_grid_pointer, new_grid_pointer)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Hand tool added to {file_path}")

add_hand_tool('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
add_hand_tool('/home/user/index.html')
add_hand_tool('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
