with open('/home/user/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Remove the old misplaced definition of renderActiveFiltersBar & openTableFilterModal
old_block_start = text.find('/* ── ACTIVE FILTERS BAR & MOBILE FILTER MODAL ── */')
if old_block_start != -1:
    old_block_end = text.find('function showHeaderContextMenu(x, y, th) {', old_block_start)
    if old_block_end != -1:
        text = text[:old_block_start] + text[old_block_end:]
        print("Removed misplaced helper functions before showHeaderContextMenu")

# 2. Helper functions to place right before renderAll()
helper_functions_code = '''
/* ── ACTIVE FILTERS BAR & MOBILE FILTER MODAL ── */
function renderActiveFiltersBar() {
  var pBar = document.getElementById('pivotActiveFiltersBar');
  var dBar = document.getElementById('detailActiveFiltersBar');
  var pBadge = document.getElementById('pivotFilterCountBadge');
  var dBadge = document.getElementById('detailFilterCountBadge');
  
  // Pivot active filters
  var pCount = 0;
  var pChips = [];
  if (ui && ui.auction && ui.auction !== 'all') {
    pCount++;
    pChips.push({ label: 'Auction: ' + ui.auction, clear: function() { ui.auction = 'all'; var el = document.getElementById('auctionFilter'); if (el) el.value = 'all'; renderAll(); saveState(); } });
  }
  if (ui && ui.dashSearch) {
    pCount++;
    pChips.push({ label: 'Search: "' + ui.dashSearch + '"', clear: function() { ui.dashSearch = ''; var el = document.getElementById('search'); if (el) el.value = ''; renderAll(); saveState(); } });
  }
  if (ui && ui.colFilters) {
    for (var k in ui.colFilters) {
      if (ui.colFilters[k] && ui.colFilters[k].length) {
        var cleanK = k.startsWith('pivot_') ? k.slice(6) : k;
        var fLabel = fieldLabel(cleanK);
        pCount++;
        (function(colKey, labelName) {
          pChips.push({
            label: labelName + ': ' + ui.colFilters[colKey].length + ' val' + (ui.colFilters[colKey].length === 1 ? '' : 's'),
            clear: function() { delete ui.colFilters[colKey]; renderAll(); saveState(); }
          });
        })(k, fLabel);
      }
    }
  }
  
  if (pBadge) {
    pBadge.textContent = pCount;
    pBadge.style.display = pCount > 0 ? 'inline-flex' : 'none';
  }
  
  if (pBar) {
    if (pChips.length > 0) {
      pBar.style.display = 'flex';
      pBar.innerHTML = '<span class="af-label">Active filters:</span>' +
        pChips.map(function(c, i) {
          return '<span class="af-chip">' + escHtml(c.label) + ' <button type="button" class="af-chip-del" data-af-p="' + i + '" title="Remove this filter">✕</button></span>';
        }).join('') +
        '<button type="button" class="af-clear-all" id="clearAllPivotAfBtn">Clear all</button>';
      
      pBar.querySelectorAll('.af-chip-del').forEach(function(btn) {
        btn.addEventListener('click', function(ev) {
          ev.stopPropagation();
          var idx = +btn.getAttribute('data-af-p');
          if (pChips[idx]) pChips[idx].clear();
        });
      });
      var clearAllBtn = pBar.querySelector('#clearAllPivotAfBtn');
      if (clearAllBtn) clearAllBtn.addEventListener('click', resetPivotFilters);
    } else {
      pBar.style.display = 'none';
      pBar.innerHTML = '';
    }
  }

  // Lot Detail active filters
  var dCount = 0;
  var dChips = [];
  if (ui && ui.detailSearch) {
    dCount++;
    dChips.push({ label: 'Search: "' + ui.detailSearch + '"', clear: function() { ui.detailSearch = ''; var el = document.getElementById('detailSearch'); if (el) el.value = ''; renderDetail(); saveState(); } });
  }
  if (selectedGroup) {
    dCount++;
    dChips.push({ label: 'Drilldown: ' + selectedGroup.value, clear: function() { selectedGroup = null; renderAll(); saveState(); } });
  }
  if (ui && ui.colFilters) {
    for (var dk in ui.colFilters) {
      if (!dk.startsWith('pivot_') && ui.colFilters[dk] && ui.colFilters[dk].length) {
        var dfLabel = fieldLabel(dk);
        dCount++;
        (function(colKey, labelName) {
          dChips.push({
            label: labelName + ': ' + ui.colFilters[colKey].length + ' val' + (ui.colFilters[colKey].length === 1 ? '' : 's'),
            clear: function() { delete ui.colFilters[colKey]; renderDetail(); saveState(); }
          });
        })(dk, dfLabel);
      }
    }
  }

  if (dBadge) {
    dBadge.textContent = dCount;
    dBadge.style.display = dCount > 0 ? 'inline-flex' : 'none';
  }

  if (dBar) {
    if (dChips.length > 0) {
      dBar.style.display = 'flex';
      dBar.innerHTML = '<span class="af-label">Active filters:</span>' +
        dChips.map(function(c, i) {
          return '<span class="af-chip">' + escHtml(c.label) + ' <button type="button" class="af-chip-del" data-af-d="' + i + '" title="Remove this filter">✕</button></span>';
        }).join('') +
        '<button type="button" class="af-clear-all" id="clearAllDetailAfBtn">Clear all</button>';
      
      dBar.querySelectorAll('.af-chip-del').forEach(function(btn) {
        btn.addEventListener('click', function(ev) {
          ev.stopPropagation();
          var idx = +btn.getAttribute('data-af-d');
          if (dChips[idx]) dChips[idx].clear();
        });
      });
      var dClearAllBtn = dBar.querySelector('#clearAllDetailAfBtn');
      if (dClearAllBtn) dClearAllBtn.addEventListener('click', resetDetailFilters);
    } else {
      dBar.style.display = 'none';
      dBar.innerHTML = '';
    }
  }
}

function openTableFilterModal(tableKind) {
  var isPivot = tableKind === 'pivot';
  var title = isPivot ? 'Pivot Analytics — Column Filters' : 'Lot Details — Column Filters';
  var layoutKind = isPivot ? (ui.groupBy === 'default' ? 'pivotLot' : 'pivotMetric') : 'detail';
  var catalog = allAssignableFields(layoutKind);
  
  var body = '<div style="margin-bottom:12px">' +
    '<input type="search" id="modalColSearch" class="xl-search" placeholder="Search columns by name…" style="width:100%;margin-bottom:10px" autocomplete="off"/>' +
    '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">' +
      '<span style="font-size:12px;color:var(--dim)">Tap any column to filter its unique values:</span>' +
      '<button type="button" class="btn" id="modalResetFilterBtn" style="font-size:11px;padding:4px 10px">↺ Clear All Filters</button>' +
    '</div>' +
  '</div>' +
  '<div class="col-filter-list" id="modalColFilterList">' +
  '</div>';

  openModal({
    title: title,
    wide: true,
    body: body,
    actions: false
  });

  var searchInput = document.getElementById('modalColSearch');
  var listEl = document.getElementById('modalColFilterList');
  var resetBtn = document.getElementById('modalResetFilterBtn');

  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      if (isPivot) resetPivotFilters(); else resetDetailFilters();
      renderModalColList();
    });
  }

  function renderModalColList() {
    if (!listEl) return;
    var q = searchInput ? searchInput.value.trim().toLowerCase() : '';
    var fieldsToShow = catalog.filter(function (c) {
      if (!q) return true;
      return c.label.toLowerCase().indexOf(q) !== -1 || c.key.toLowerCase().indexOf(q) !== -1;
    });

    if (!fieldsToShow.length) {
      listEl.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:20px;color:var(--dim)">No matching columns</div>';
      return;
    }

    listEl.innerHTML = fieldsToShow.map(function (c) {
      var filterKey = (isPivot && ui.groupBy !== 'default' && c.key !== ui.groupBy && c.key !== 'key' && c.key !== 'settlement_status' && c.key !== 'settled_breakdown')
        ? ('pivot_' + c.key)
        : (c.key === 'key' ? ui.groupBy : c.key);
      var hasFilter = colFilterOn(filterKey);
      var currentSel = colFilterKeys(filterKey);
      var statusText = hasFilter ? (currentSel.length + ' selected') : 'All values';

      return '<button type="button" class="col-filter-card' + (hasFilter ? ' filtered' : '') + '" data-pick-col="' + escHtml(c.key) + '">' +
        '<span class="col-filter-card-name">' + escHtml(c.label) + '</span>' +
        '<span class="col-filter-card-status">' + (hasFilter ? '● ' : '') + statusText + ' ›</span>' +
      '</button>';
    }).join('');

    listEl.querySelectorAll('[data-pick-col]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-pick-col');
        var mockTh = document.createElement('th');
        mockTh.dataset.field = key;
        mockTh.dataset.table = tableKind;
        mockTh.dataset.layout = layoutKind;
        document.getElementById('modalRoot').innerHTML = ''; // close modal
        var btnRect = btn.getBoundingClientRect();
        showHeaderContextMenu(btnRect.left, btnRect.top, mockTh);
      });
    });
  }

  renderModalColList();
  if (searchInput) searchInput.addEventListener('input', renderModalColList);
}
'''

# Insert helper functions right before function renderAll()
text = text.replace('function renderAll() {', helper_functions_code + '\nfunction renderAll() {', 1)

# Save to all copies
for path in [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html'
]:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)

print("Saved fixed scope across all files.")
