const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  
  // 1. Desktop Screenshot
  const page = await browser.newPage({ viewport: { width: 1440, height: 1050 } });
  await page.goto('http://127.0.0.1:8080/', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);
  await page.screenshot({ path: '/home/user/scrapsale_desktop_proof.png', fullPage: false });
  console.log('Desktop screenshot taken: /home/user/scrapsale_desktop_proof.png');

  // Full page screenshot
  await page.screenshot({ path: '/home/user/scrapsale_full_page_proof.png', fullPage: true });
  console.log('Full page screenshot taken: /home/user/scrapsale_full_page_proof.png');

  // 2. Mobile View Screenshot
  const mobilePage = await browser.newPage({ viewport: { width: 430, height: 932 } });
  await mobilePage.goto('http://127.0.0.1:8080/', { waitUntil: 'networkidle' });
  const mobileBtn = await mobilePage.$('#viewModeToggleBtn');
  if (mobileBtn) await mobileBtn.click();
  await mobilePage.waitForTimeout(600);
  await mobilePage.screenshot({ path: '/home/user/scrapsale_mobile_proof.png', fullPage: false });
  console.log('Mobile screenshot taken: /home/user/scrapsale_mobile_proof.png');

  await browser.close();
})();
