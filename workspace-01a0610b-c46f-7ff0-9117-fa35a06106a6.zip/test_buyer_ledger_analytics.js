const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(500);

  // Check section heading
  const heading = await page.evaluate(() => {
    const el = document.querySelector(".panel h2");
    return el ? el.innerText.trim() : null;
  });
  console.log("Panel Heading:", heading);

  // Check Group By options
  const groupByOptions = await page.evaluate(() => {
    const sel = document.getElementById("groupBy");
    if (!sel) return [];
    return Array.from(sel.options).map(o => ({ value: o.value, text: o.text }));
  });
  console.log("Group By Options:", groupByOptions);

  // Screenshot Buyer Ledger Analytics section
  const pivotPanel = await page.$(".panel");
  if (pivotPanel) {
    await pivotPanel.scrollIntoViewIfNeeded();
    await page.waitForTimeout(300);
    await page.screenshot({ path: "/home/user/buyer_ledger_analytics_proof.png" });
  }

  // Switch to Lot details option
  await page.selectOption("#groupBy", "default");
  await page.waitForTimeout(400);
  const lotDetailsFirstRow = await page.evaluate(() => {
    const ths = Array.from(document.querySelectorAll("#pivotTable thead th")).map(th => th.innerText.trim());
    return ths.slice(0, 5);
  });
  console.log("Headers under Lot details mode:", lotDetailsFirstRow);
  await page.screenshot({ path: "/home/user/buyer_ledger_lot_details_mode_proof.png" });

  // Switch back to Buyer option
  await page.selectOption("#groupBy", "buyer");
  await page.waitForTimeout(400);
  const buyerFirstRow = await page.evaluate(() => {
    const ths = Array.from(document.querySelectorAll("#pivotTable thead th")).map(th => th.innerText.trim());
    return ths.slice(0, 5);
  });
  console.log("Headers under Buyer mode:", buyerFirstRow);
  await page.screenshot({ path: "/home/user/buyer_ledger_buyer_mode_proof.png" });

  await browser.close();
  console.log("Verification completed successfully!");
})();
