const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);

  console.log('--- Testing Pivot Hidden Buttons in Grouped View (Buyer) ---');
  // In Buyer grouped view, metric columns are: lots, mat_value, gst, tcs, total_receivables, total_received, outstanding, settled_breakdown
  // Let's hide a column in Pivot Analytics by evaluating colLayout.pivotMetric
  await page.evaluate(() => {
    // Hide 'gst' and 'tcs' from pivotMetric
    colLayout.pivotMetric = colLayout.pivotMetric.filter(k => k !== 'gst' && k !== 'tcs');
    renderAll();
  });
  await page.waitForTimeout(300);

  let pivotTogglesHtml = await page.evaluate(() => {
    const el = document.getElementById('pivotColToggles');
    return el ? { innerHTML: el.innerHTML, display: getComputedStyle(el).display } : null;
  });
  console.log('pivotColToggles after hiding gst & tcs:', JSON.stringify(pivotTogglesHtml, null, 2));

  // Take screenshot of Pivot Analytics with hidden button bar
  await page.screenshot({ path: '/home/user/pivot_hidden_buttons_proof.png' });

  // Click on the "+ GST" button in pivotColToggles
  console.log('Clicking + GST in pivotColToggles...');
  await page.click('#pivotColToggles button[data-key="gst"]');
  await page.waitForTimeout(300);

  let pivotCols = await page.evaluate(() => colLayout.pivotMetric);
  console.log('colLayout.pivotMetric after clicking + GST:', pivotCols);

  // Click on "↺ Show all" in pivotColToggles
  console.log('Clicking Show all in pivotColToggles...');
  const unhideAll = await page.$('#pivotColToggles .unhide-all-btn, #pivotColToggles #unhideAllColsBtn');
  if (unhideAll) {
    await unhideAll.click();
    await page.waitForTimeout(300);
  }
  pivotCols = await page.evaluate(() => colLayout.pivotMetric);
  console.log('colLayout.pivotMetric after clicking Show all:', pivotCols);

  console.log('--- Testing Pivot Hidden Buttons in Default View (lot-wise) ---');
  await page.selectOption('#groupBy', 'default');
  await page.waitForTimeout(400);

  // In default view, check hidden buttons if any or hide one
  await page.evaluate(() => {
    colLayout.pivotLot = colLayout.pivotLot.filter(k => k !== 'late_fee' && k !== 'fp_received');
    renderAll();
  });
  await page.waitForTimeout(300);

  pivotTogglesHtml = await page.evaluate(() => {
    const el = document.getElementById('pivotColToggles');
    return el ? { innerHTML: el.innerHTML, display: getComputedStyle(el).display } : null;
  });
  console.log('pivotColToggles in default view after hiding late_fee & fp_received:', JSON.stringify(pivotTogglesHtml, null, 2));

  // Unhide late_fee
  await page.click('#pivotColToggles button[data-key="late_fee"]');
  await page.waitForTimeout(300);
  let pivotLotCols = await page.evaluate(() => colLayout.pivotLot);
  console.log('colLayout.pivotLot after unhiding late_fee:', pivotLotCols);

  await browser.close();
  console.log('Pivot Hidden Button Tests PASSED!');
})();
