import re

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

comprehensive_light_theme_css = """
/* ==========================================================================
   THEME SYSTEM: ENTERPRISE LIGHT THEME (Crisp, High-Contrast FinTech UX)
   ========================================================================== */
[data-theme="light"] {
  --theme: light;
  --cyan: #0284c7;
  --violet: #6366f1;
  --pink: #e11d48;
  --green: #16a34a;
  --amber: #d97706;
  --bg: #f8fafc;
  --bg2: #ffffff;
  --surface: #ffffff;
  --surface-hover: #f1f5f9;
  --border: #e2e8f0;
  --border-strong: #cbd5e1;
  --text: #0f172a;
  --text-bright: #020617;
  --muted: #475569;
  --dim: #64748b;
  --deep: #94a3b8;
  --accent: #2563eb;
  --accent-2: #6366f1;
  --panel: #ffffff;
  --panel-border: #e2e8f0;
  --panel-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05), 0 1px 3px rgba(15, 23, 42, 0.03);
  --line: #e2e8f0;
  --card-bg: #ffffff;
  --card-border: #e2e8f0;
  --card-shadow: 0 2px 10px rgba(15, 23, 42, 0.04), 0 1px 3px rgba(15, 23, 42, 0.02);
  --topbar-bg: rgba(255, 255, 255, 0.92);
  --topbar-border: #e2e8f0;
  --table-head-bg: #f8fafc;
  --table-head-color: #475569;
  --table-border: #e2e8f0;
  --table-zebra: #f8fafc;
  --table-row-hover: #f1f5f9;
  --table-frozen-bg: #ffffff;
  --table-tfoot-bg: #f8fafc;
  --table-unsettled-color: #0f172a;
  --input-bg: #ffffff;
  --input-border: #cbd5e1;
  --input-color: #0f172a;
  --modal-bg: #ffffff;
  --modal-border: #cbd5e1;
  --modal-shadow: 0 25px 60px rgba(15, 23, 42, 0.18);
  --btn-bg: #ffffff;
  --btn-border: #cbd5e1;
  --btn-color: #334155;
  --btn-hover-bg: #f1f5f9;
  --btn-hover-color: #0f172a;
  --cell-rng-border: #2563eb;
  --hud-bg: rgba(255, 255, 255, 0.96);
  --hud-border: #cbd5e1;
  --hud-text: #0f172a;
  --pop-bg: #ffffff;
  --pop-border: #cbd5e1;
  --pop-shadow: 0 16px 40px rgba(15, 23, 42, 0.12);
  --status-settled-color: #16a34a;
  --status-unsettled-color: #e11d48;
  color-scheme: light;
}

[data-theme="light"] body {
  background: #f8fafc;
  color: #0f172a;
}

[data-theme="light"] ::-webkit-scrollbar-track {
  background: #f1f5f9;
}
[data-theme="light"] ::-webkit-scrollbar-thumb {
  background: #cbd5e1;
}
[data-theme="light"] ::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}
[data-theme="light"] ::-webkit-scrollbar-corner {
  background: #f1f5f9;
}
[data-theme="light"] html {
  scrollbar-color: #cbd5e1 #f1f5f9;
}

[data-theme="light"] #hscrollPod {
  background: #f1f5f9;
  border-color: #cbd5e1;
  box-shadow: 0 -4px 14px rgba(15, 23, 42, 0.08);
}

[data-theme="light"] .bg-fx {
  background:
    radial-gradient(ellipse 80% 50% at 50% -20%, rgba(37, 99, 235, 0.05) 0%, transparent 60%),
    radial-gradient(ellipse 60% 40% at 85% 10%, rgba(99, 102, 241, 0.04) 0%, transparent 55%),
    #f8fafc;
}

[data-theme="light"] .hero h1 {
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #2563eb 85%, #0284c7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
[data-theme="light"] .eyebrow {
  color: #2563eb;
}
[data-theme="light"] .hero-sub {
  color: #475569;
}

[data-theme="light"] .bc {
  border-color: #bfdbfe;
  background: #eff6ff;
  color: #1d4ed8;
}
[data-theme="light"] .bv {
  border-color: #ddd6fe;
  background: #f5f3ff;
  color: #6d28d9;
}
[data-theme="light"] .bp {
  border-color: #fecdd3;
  background: #fff1f2;
  color: #be123c;
}
[data-theme="light"] .bg-b {
  border-color: #bbf7d0;
  background: #f0fdf4;
  color: #15803d;
}

[data-theme="light"] #topbar {
  background: rgba(255, 255, 255, 0.92);
  border-bottom: 1px solid #e2e8f0;
  box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.04);
}
[data-theme="light"] .nav-row {
  border-bottom: 1px solid #f1f5f9;
}
[data-theme="light"] .nav-btn {
  color: #64748b;
}
[data-theme="light"] .nav-btn:hover {
  color: #0f172a;
  border-bottom-color: #cbd5e1;
}
[data-theme="light"] .nav-btn.active {
  color: #2563eb;
  border-bottom-color: #2563eb;
}
[data-theme="light"] .nav-btn .nbadge {
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  color: #2563eb;
}
[data-theme="light"] #topbar h1 {
  color: #0f172a;
}
[data-theme="light"] #topbar p {
  color: #64748b;
}
[data-theme="light"] #topbar .toolbar-title p {
  color: #2563eb;
}

[data-theme="light"] .card,
[data-theme="light"] .kpi {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04), 0 1px 3px rgba(15, 23, 42, 0.02);
}
[data-theme="light"] .card:hover,
[data-theme="light"] .kpi:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 25px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.04);
  border-color: #cbd5e1;
}
[data-theme="light"] .card-label,
[data-theme="light"] .kpi-label {
  color: #64748b;
}
[data-theme="light"] .card.c .card-value, [data-theme="light"] .c .kpi-val { color: #0284c7; }
[data-theme="light"] .card.v .card-value, [data-theme="light"] .v .kpi-val { color: #6366f1; }
[data-theme="light"] .card.g .card-value, [data-theme="light"] .card.good .card-value, [data-theme="light"] .g .kpi-val { color: #16a34a; }
[data-theme="light"] .card.p .card-value, [data-theme="light"] .card.warn .card-value, [data-theme="light"] .p .kpi-val { color: #e11d48; }
[data-theme="light"] .card.a .card-value, [data-theme="light"] .a .kpi-val { color: #d97706; }

[data-theme="light"] .panel {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05), 0 1px 3px rgba(15, 23, 42, 0.03);
}
[data-theme="light"] .panel h2 {
  color: #0f172a;
}
[data-theme="light"] .controls label {
  color: #64748b;
}
[data-theme="light"] select,
[data-theme="light"] input[type=text],
[data-theme="light"] input[type=search],
[data-theme="light"] input[type=number],
[data-theme="light"] input[type=date] {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #0f172a;
}
[data-theme="light"] input:focus,
[data-theme="light"] select:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}
[data-theme="light"] option {
  background: #ffffff;
  color: #0f172a;
}
[data-theme="light"] .hint {
  color: #64748b;
}
[data-theme="light"] .hint b {
  color: #334155;
}

[data-theme="light"] .btn {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #334155;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.05);
}
[data-theme="light"] .btn:hover {
  background: #f8fafc;
  color: #0f172a;
  border-color: #94a3b8;
  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.08);
}
[data-theme="light"] .btn.primary {
  background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
  color: #ffffff;
  border-color: #1d4ed8;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.25);
}
[data-theme="light"] .btn.primary:hover {
  background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.35);
}
[data-theme="light"] .btn.danger {
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
}
[data-theme="light"] .btn.danger:hover {
  background: #ffe4e6;
  border-color: #fda4af;
  color: #9f1239;
}
[data-theme="light"] .count-pill {
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  color: #2563eb;
}

/* Table Light Theme */
[data-theme="light"] .table-wrap {
  border: 1px solid #e2e8f0;
  background: #ffffff;
}
[data-theme="light"] thead th {
  background: #f8fafc;
  color: #475569;
  border-bottom: 2px solid #e2e8f0;
}
[data-theme="light"] thead th:hover {
  background: #f1f5f9;
  color: #0f172a;
}
[data-theme="light"] th.frozen,
[data-theme="light"] td.frozen {
  background: #ffffff;
  box-shadow: inset -1px 0 0 #e2e8f0;
}
[data-theme="light"] thead th.frozen {
  background: #f8fafc;
}
[data-theme="light"] tfoot td {
  background: #f8fafc;
  border-top: 2px solid #cbd5e1;
  color: #0f172a;
}
[data-theme="light"] tfoot td.frozen {
  background: #f1f5f9;
}
[data-theme="light"] tbody tr {
  border-bottom: 1px solid #f1f5f9;
}
[data-theme="light"] tbody tr:nth-child(even) {
  background: #f8fafc;
}
[data-theme="light"] tbody tr:hover {
  background: #f1f5f9 !important;
}
[data-theme="light"] tbody tr:not(.settled) td {
  color: #0f172a;
}
[data-theme="light"] tbody tr.settled td {
  color: #16a34a;
}
[data-theme="light"] td.strong {
  color: #0284c7;
}
[data-theme="light"] td.pos {
  color: #e11d48;
}
[data-theme="light"] td.neg {
  color: #16a34a;
}
[data-theme="light"] td.zero {
  color: #94a3b8;
}
[data-theme="light"] .invoice-link {
  color: #2563eb;
}
[data-theme="light"] .invoice-link:hover {
  color: #1d4ed8;
  text-decoration: underline;
}
[data-theme="light"] table.lots-table td.edit input {
  background: #ffffff;
  color: #0f172a;
  border: 1px solid #cbd5e1;
}
[data-theme="light"] table.lots-table td.edit input:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
}

/* Cell Range Selection Boxes in Light Mode */
[data-theme="light"] td.rng.rng-top {
  box-shadow: inset 0 2px 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-bottom {
  box-shadow: inset 0 -2px 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-left {
  box-shadow: inset 2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-right {
  box-shadow: inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-bottom {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 0 -2px 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-left.rng-right {
  box-shadow: inset 2px 0 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-left {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-right {
  box-shadow: inset 0 2px 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-bottom.rng-left {
  box-shadow: inset 0 -2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-bottom.rng-right {
  box-shadow: inset 0 -2px 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-bottom.rng-left {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 0 -2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-bottom.rng-right {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 0 -2px 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-left.rng-right {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-bottom.rng-left.rng-right {
  box-shadow: inset 0 -2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}
[data-theme="light"] td.rng.rng-top.rng-bottom.rng-left.rng-right {
  box-shadow: inset 0 2px 0 0 #2563eb, inset 0 -2px 0 0 #2563eb, inset 2px 0 0 0 #2563eb, inset -2px 0 0 0 #2563eb !important;
}

/* Status Chips & Badges */
[data-theme="light"] .settled-counts .seg.s {
  background: #16a34a;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(22, 163, 74, 0.25);
}
[data-theme="light"] .settled-counts .seg.u {
  background: #e11d48;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(225, 29, 72, 0.25);
}
[data-theme="light"] .lbl-settled {
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  color: #15803d;
}
[data-theme="light"] .lbl-unsettled {
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
}

/* Menus, Popups, Date Picker & Modals */
[data-theme="light"] .menu,
[data-theme="light"] .col-filter-pop,
[data-theme="light"] #rightClickMenu,
[data-theme="light"] #datePickerPopup {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  box-shadow: 0 16px 40px -4px rgba(15, 23, 42, 0.15), 0 4px 12px rgba(15, 23, 42, 0.08);
  color: #0f172a;
}
[data-theme="light"] .menu-item {
  color: #334155;
}
[data-theme="light"] .menu-item:hover {
  background: #f1f5f9;
  color: #0f172a;
}
[data-theme="light"] .menu-item.on {
  background: #eff6ff;
  outline-color: #2563eb;
}
[data-theme="light"] .format-check {
  color: #2563eb;
}
[data-theme="light"] .col-filter-title {
  color: #0f172a;
}
[data-theme="light"] .filter-search-wrap input {
  background: #f8fafc;
  border-color: #cbd5e1;
  color: #0f172a;
}
[data-theme="light"] .col-filter-item {
  color: #334155;
}
[data-theme="light"] .col-filter-item:hover {
  background: #f1f5f9;
}
[data-theme="light"] .modal {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  box-shadow: 0 25px 60px -15px rgba(15, 23, 42, 0.25);
  color: #0f172a;
}
[data-theme="light"] .modal-head {
  border-bottom: 1px solid #e2e8f0;
}
[data-theme="light"] .modal-title {
  color: #0f172a;
}
[data-theme="light"] .modal-close {
  color: #64748b;
}
[data-theme="light"] .modal-close:hover {
  color: #0f172a;
  background: #f1f5f9;
}
[data-theme="light"] .modal-foot {
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}
[data-theme="light"] .lic-table,
[data-theme="light"] .lot-inspect-col {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
}
[data-theme="light"] .lic-row {
  border-bottom: 1px solid #e2e8f0;
}
[data-theme="light"] .lic-k {
  color: #64748b;
}
[data-theme="light"] .lic-v {
  color: #0f172a;
}
[data-theme="light"] .lic-head {
  color: #0f172a;
}
[data-theme="light"] .lot-kpi-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
}
[data-theme="light"] .lot-kpi-card .lk-lbl {
  color: #64748b;
}
[data-theme="light"] .lot-kpi-card .lk-val {
  color: #0f172a;
}
[data-theme="light"] .calc-hud {
  background: rgba(255, 255, 255, 0.96);
  border: 1px solid #cbd5e1;
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.12);
  color: #0f172a;
}
[data-theme="light"] .calc-hud .hud-val {
  color: #2563eb;
}
[data-theme="light"] .calc-hud .hud-lbl {
  color: #64748b;
}

/* Date Picker Light */
[data-theme="light"] .dt-cal-head {
  border-bottom: 1px solid #e2e8f0;
  color: #0f172a;
}
[data-theme="light"] .dt-wkday {
  color: #64748b;
}
[data-theme="light"] .dt-day-btn {
  color: #0f172a;
}
[data-theme="light"] .dt-day-btn:hover {
  background: #eff6ff;
  color: #2563eb;
}
[data-theme="light"] .dt-day-btn.today {
  border-color: #2563eb;
  color: #2563eb;
  font-weight: 800;
}
[data-theme="light"] .dt-day-btn.selected {
  background: #2563eb;
  color: #ffffff;
  font-weight: 800;
}

/* Buyer Advice Modal Light Overrides */
[data-theme="light"] .buyer-advice-modal {
  color: #0f172a;
}
[data-theme="light"] .buyer-advice-modal div[style*="linear-gradient(135deg,rgba(0,245,255"] {
  background: linear-gradient(135deg, #eff6ff 0%, #f5f3ff 100%) !important;
  border-color: #bfdbfe !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="color:#ffffff"] {
  color: #0f172a !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(13,13,26"] {
  background: #ffffff !important;
  border-color: #e2e8f0 !important;
  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04) !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(255,255,255,0.03)"] {
  background: #ffffff !important;
  border-color: #e2e8f0 !important;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.03) !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(0,245,255,0.05)"],
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(0,245,255,0.06)"],
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(0,245,255,0.08)"] {
  background: #f0f9ff !important;
  border-color: #bae6fd !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(124,58,237,0.08)"],
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(124,58,237,0.12)"] {
  background: #f5f3ff !important;
  border-color: #ddd6fe !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(247,37,133,0.08)"],
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(247,37,133,0.06)"] {
  background: #fff1f2 !important;
  border-color: #fecdd3 !important;
}
[data-theme="light"] .buyer-advice-modal div[style*="background:rgba(0,0,0,0.3)"] {
  background: #f8fafc !important;
  border: 1px dashed #cbd5e1 !important;
}
[data-theme="light"] .buyer-advice-modal thead[style*="background:#0a0a19"] {
  background: #f1f5f9 !important;
}
[data-theme="light"] .buyer-advice-modal thead th {
  color: #475569 !important;
  border-bottom: 2px solid #e2e8f0 !important;
}
[data-theme="light"] .buyer-advice-modal tbody tr {
  border-bottom: 1px solid #f1f5f9 !important;
}
[data-theme="light"] .buyer-advice-modal tbody tr:nth-child(even) {
  background: #f8fafc !important;
}
[data-theme="light"] .buyer-advice-modal tfoot {
  background: #f8fafc !important;
  border-top: 2px solid #cbd5e1 !important;
  color: #0f172a !important;
}
[data-theme="light"] .buyer-advice-modal .lic-row {
  border-color: #e2e8f0 !important;
}

/* Theme Toggle Button Component */
.theme-toggle-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 11px;
  border-radius: 8px;
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  user-select: none;
}
.theme-toggle-btn .theme-icon {
  font-size: 13px;
  line-height: 1;
  display: inline-block;
  transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
.theme-toggle-btn:hover .theme-icon {
  transform: rotate(20deg) scale(1.15);
}
[data-theme="dark"] .theme-toggle-btn {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: #f1f5f9;
}
[data-theme="dark"] .theme-toggle-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.25);
  color: #ffffff;
}
[data-theme="light"] .theme-toggle-btn {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #1e293b;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.05);
}
[data-theme="light"] .theme-toggle-btn:hover {
  background: #f1f5f9;
  border-color: #94a3b8;
  color: #0f172a;
}
"""

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replace existing THEME SYSTEM CSS block
    pattern = r"/\* ==========================================================================\s+THEME SYSTEM:[\s\S]*?</style>"
    if re.search(pattern, content):
        content = re.sub(pattern, comprehensive_light_theme_css.strip() + "\n</style>", content)
    else:
        content = content.replace("</style>", comprehensive_light_theme_css + "\n</style>")

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"Updated full CSS theme system in {fpath} successfully!")
