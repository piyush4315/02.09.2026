import re

def apply_smooth_scroll_fix(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update .table-wrap and table CSS for 120fps GPU-composited buttery smooth Apple touch scroll
    old_table_wrap_css = """.table-wrap{
  overflow-x:auto;overflow-y:hidden;border:1px solid rgba(255,255,255,.06);border-radius:13px;max-height:none;
  -webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;max-width:100%
}"""

    new_table_wrap_css = """.table-wrap{
  overflow-x: auto !important;
  overflow-y: auto !important;
  border: 1px solid rgba(255, 255, 255, 0.06);
  border-radius: 13px;
  max-height: none;
  -webkit-overflow-scrolling: touch !important;
  touch-action: pan-x pan-y !important;
  overscroll-behavior: contain !important;
  overscroll-behavior-x: contain !important;
  overscroll-behavior-y: auto !important;
  scroll-behavior: auto !important;
  max-width: 100%;
  transform: translateZ(0);
  -webkit-transform: translateZ(0);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
  will-change: scroll-position;
  contain: paint;
}
.table-wrap table {
  transform: translateZ(0);
  -webkit-transform: translateZ(0);
}"""

    if old_table_wrap_css in content:
        content = content.replace(old_table_wrap_css, new_table_wrap_css)
        print("Updated .table-wrap CSS.")
    else:
        # Replace using regex if exact string differed slightly
        content = re.sub(
            r'\.table-wrap\s*\{[^}]*\}',
            new_table_wrap_css,
            content,
            count=1
        )
        print("Updated .table-wrap CSS via regex.")

    # 2. Fix initHandPanEngine: DO NOT hijack native touch gestures on mobile!
    # Let native iOS WebKit / ProMotion handle touches at 120Hz with zero JS friction!
    # Mouse drag panning is active when Hand Mode is toggled or Space held.
    old_pan_engine_start = "function initHandPanEngine() {"
    new_pan_engine = """function initHandPanEngine() {
  var btn = document.getElementById('handToolBtn');
  if (btn) btn.addEventListener('click', toggleHandMode);

  // Keyboard shortcut: 'H' toggles hand mode; holding 'Space' temporarily activates it
  document.addEventListener('keydown', function (e) {
    var tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
    var isInput = tag === 'input' || tag === 'textarea' || tag === 'select' || (e.target && e.target.isContentEditable);
    if (isInput) return;

    if (e.key === 'm' || e.key === 'M') {
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        toggleViewMode();
        return;
      }
    }
    if (e.key === 'h' || e.key === 'H') {
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        toggleHandMode();
        return;
      }
    }

    if (e.code === 'Space' && !handPanState.spacePressed && !e.ctrlKey && !e.metaKey && !e.altKey) {
      handPanState.spacePressed = true;
      if (!handPanState.active) {
        document.body.classList.add('hand-mode-active');
        var b = document.getElementById('handToolBtn');
        if (b) b.classList.add('active');
      }
    }
  });

  document.addEventListener('keyup', function (e) {
    if (e.code === 'Space' && handPanState.spacePressed) {
      handPanState.spacePressed = false;
      if (!handPanState.active) {
        document.body.classList.remove('hand-mode-active', 'hand-panning');
        var b = document.getElementById('handToolBtn');
        if (b) b.classList.remove('active');
      }
    }
  });

  function isHandActive() {
    return handPanState.active || handPanState.spacePressed;
  }

  // Pure Mouse-Drag Pan (when Hand Tool is active). Touch gestures use native 120Hz GPU momentum!
  function handlePanStart(e) {
    if (e.type.startsWith('touch')) return; // Let Apple / Mobile native 120Hz compositor handle touch!
    if (!isHandActive()) return;
    if (e.button !== 0) return; // Left click only

    var target = e.target;
    var wrap = target.closest ? target.closest('.table-wrap') : null;
    if (!wrap) return;

    if (handPanState.animId) {
      cancelAnimationFrame(handPanState.animId);
      handPanState.animId = null;
    }

    var clientX = e.clientX;
    var clientY = e.clientY;

    handPanState.isDragging = true;
    handPanState.hasMoved = false;
    handPanState.activeWrap = wrap;
    handPanState.startX = clientX;
    handPanState.startY = clientY;
    handPanState.lastX = clientX;
    handPanState.lastY = clientY;
    handPanState.lastTime = performance.now();
    handPanState.startScrollLeft = wrap.scrollLeft;
    handPanState.startScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    handPanState.velocityX = 0;
    handPanState.velocityY = 0;

    document.body.classList.add('hand-panning');
    e.preventDefault();
  }

  function handlePanMove(e) {
    if (e.type.startsWith('touch')) return;
    if (!handPanState.isDragging || !handPanState.activeWrap) return;

    var clientX = e.clientX;
    var clientY = e.clientY;
    var deltaX = clientX - handPanState.startX;
    var deltaY = clientY - handPanState.startY;

    if (Math.abs(deltaX) > 3 || Math.abs(deltaY) > 3) {
      handPanState.hasMoved = true;
    }

    if (handPanState.hasMoved) {
      e.preventDefault();

      // Pan horizontally inside table-wrap
      handPanState.activeWrap.scrollLeft = handPanState.startScrollLeft - deltaX;

      // Pan vertically (window scroll)
      var now = performance.now();
      var dt = Math.max(1, now - handPanState.lastTime);
      var moveY = clientY - handPanState.lastY;
      var moveX = clientX - handPanState.lastX;

      window.scrollBy(0, -moveY);

      handPanState.velocityX = moveX / dt;
      handPanState.velocityY = moveY / dt;
      handPanState.lastX = clientX;
      handPanState.lastY = clientY;
      handPanState.lastTime = now;
    }
  }

  function handlePanEnd(e) {
    if (e.type.startsWith('touch')) return;
    if (!handPanState.isDragging) return;
    handPanState.isDragging = false;
    document.body.classList.remove('hand-panning');

    var wrap = handPanState.activeWrap;
    if (!wrap) return;

    var vx = handPanState.velocityX;
    var vy = handPanState.velocityY;
    var speed = Math.sqrt(vx * vx + vy * vy);

    if (speed > 0.15 && handPanState.hasMoved) {
      var friction = 0.94;
      function stepMomentum() {
        if (Math.abs(vx) < 0.05 && Math.abs(vy) < 0.05) {
          handPanState.animId = null;
          return;
        }
        if (wrap) wrap.scrollLeft -= vx * 16;
        window.scrollBy(0, -vy * 16);
        vx *= friction;
        vy *= friction;
        handPanState.animId = requestAnimationFrame(stepMomentum);
      }
      handPanState.animId = requestAnimationFrame(stepMomentum);
    }
  }

  // Intercept click on cells if a drag pan just occurred
  document.addEventListener('click', function (e) {
    if (handPanState.hasMoved && isHandActive()) {
      e.preventDefault();
      e.stopPropagation();
      handPanState.hasMoved = false;
    }
  }, true);

  // Mouse pan listeners
  document.addEventListener('mousedown', handlePanStart, { passive: false });
  document.addEventListener('mousemove', handlePanMove, { passive: false });
  document.addEventListener('mouseup', handlePanEnd);
}"""

    # Replace old initHandPanEngine with optimized one
    pan_engine_pattern = r'function initHandPanEngine\(\)\s*\{[\s\S]*?document\.addEventListener\(\'touchcancel\', handlePanEnd\);\s*\}'
    if re.search(pan_engine_pattern, content):
        content = re.sub(pan_engine_pattern, new_pan_engine, content)
        print("Replaced initHandPanEngine with native-touch-optimized version.")
    else:
        print("Warning: pan_engine_pattern not matched directly.")

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"File {file_path} successfully updated with Apple Smooth Scroll Fix.")

apply_smooth_scroll_fix('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
apply_smooth_scroll_fix('/home/user/index.html')
apply_smooth_scroll_fix('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
