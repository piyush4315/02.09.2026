const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(500);

  // Check Dark Theme chip styles
  const darkSettled = await page.evaluate(() => {
    const el = document.querySelector("#detailTableDash .lbl-settled");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundImage || cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Dark Settled Chip:", darkSettled);

  const darkUnsettled = await page.evaluate(() => {
    const el = document.querySelector("#detailTableDash .lbl-unsettled");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Dark Unsettled Chip:", darkUnsettled);

  await page.screenshot({ path: "/home/user/dark_theme_chips_proof.png" });

  // Switch to Light Theme
  await page.click("#themeToggleBtn");
  await page.waitForTimeout(300);

  const lightSettled = await page.evaluate(() => {
    const el = document.querySelector("#detailTableDash .lbl-settled");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Light Settled Chip:", lightSettled);

  const lightUnsettled = await page.evaluate(() => {
    const el = document.querySelector("#detailTableDash .lbl-unsettled");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Light Unsettled Chip:", lightUnsettled);

  const lightPivotSegS = await page.evaluate(() => {
    const el = document.querySelector("#pivotTable .seg.s");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Light Pivot Seg S:", lightPivotSegS);

  const lightPivotSegU = await page.evaluate(() => {
    const el = document.querySelector("#pivotTable .seg.u");
    const cs = window.getComputedStyle(el);
    return { bg: cs.backgroundColor, color: cs.color, border: cs.border, shadow: cs.boxShadow };
  });
  console.log("Light Pivot Seg U:", lightPivotSegU);

  await page.screenshot({ path: "/home/user/light_theme_chips_proof.png" });

  await browser.close();
  console.log("Theme chip tests completed successfully!");
})();
