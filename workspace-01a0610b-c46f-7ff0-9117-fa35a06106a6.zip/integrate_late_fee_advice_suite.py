import re

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update generateWhatsAppAdviceText
    new_wa_func = """function generateWhatsAppAdviceText(lotsList, buyerTitle) {
  var isMulti = lotsList.length > 1;
  var bName = buyerTitle || (lotsList[0] ? lotsList[0].buyer : 'Valued Buyer');
  var b = computeAdviceBreakdown(lotsList);
  
  var lotDetailsText = '';
  if (!isMulti && lotsList[0]) {
    var r = lotsList[0];
    lotDetailsText = 
      '📋 *Lot No.:* ' + r.lot_no + ' | *Bid Sheet:* ' + (r.auction || '—') + '\\n' +
      '📦 *Material:* ' + r.lot_name + '\\n' +
      '⚖️ *Quantity:* ' + numFmt(r.qty) + ' ' + (r.unit || 'NO') + ' @ ₹ ' + inr(r.rate) + ' / ' + (r.unit || 'NO') + '\\n';
  } else {
    lotDetailsText = '📊 *Total Lots:* ' + lotsList.length + ' Lot(s) (' + lotsList.map(function(x){ return '#' + x.lot_no; }).join(', ') + ')\\n';
  }

  var sdRecLine = '   • SD Received: ₹ ' + inr(b.totSdRec) + (b.totSdRec > 0 && b.sdDatesStr ? (' _(Rec Date: ' + b.sdDatesStr + ')_') : '') + '\\n';
  var fpRecLine = '   • FP Received: ₹ ' + inr(b.totFpRec) + (b.totFpRec > 0 && b.fpDatesStr ? (' _(Rec Date: ' + b.fpDatesStr + ')_') : '') + '\\n';
  var lateFeeLine = '3️⃣ *Late Fee @ 1%/wk (from 24.08.2026):*\\n' +
    '   • Delay Basis: 1% per week or part thereof after 24.08.2026\\n' +
    '   • *Late Fee Payable:* ₹ ' + inr(b.totLateFee) + (b.totLateFee > 0 ? '  ⏳ [DUE]' : '  ✅ [NIL / ON TIME]') + '\\n';

  var msg = 
    '🏛️ *MSETCL LIMITED — PAYMENT DEMAND ADVICE*\\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '👤 *Buyer Name:* ' + bName + '\\n' +
    lotDetailsText +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '💰 *VALUATION & STATUTORY CHARGES:*\\n' +
    '• Material Value: ₹ ' + inr(b.totMat) + '\\n' +
    '• GST @ 18%: ₹ ' + inr(b.totGst) + '\\n' +
    '• Material Value + GST: ₹ ' + inr(b.totMatGst) + '\\n' +
    '• TCS @ 2% of Material Value: ₹ ' + inr(b.totTcs) + '\\n' +
    '• Gross Consideration (Mat. Value + GST + TCS): ₹ ' + inr(b.totGrossValuation) + '\\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '⚡ *MSTC SERVICE CHARGE BREAKUP:*\\n' +
    '1️⃣ Service Charge to MSTC (2.25% of Mat. Value): ₹ ' + inr(b.totScBasic) + '\\n' +
    '2️⃣ GST @ 18% on Service Charge: ₹ ' + inr(b.totScGst) + '\\n' +
    '3️⃣ Service Charge + GST (2.655%): ₹ ' + inr(b.totScWithGst) + '\\n' +
    '4️⃣ TDS u/s 194(O) (0.1% of Mat. Value): ₹ ' + inr(b.totTds194o) + '\\n' +
    '5️⃣ TDS u/s 194(H) (2% of Service Charge): ₹ ' + inr(b.totTds194h) + '\\n' +
    '6️⃣ *Net Service Charge to MSTC (3+4-5 = 2.71%):* ₹ ' + inr(b.totSc271) + '\\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '⚡ *TOTAL BEFORE GST TDS:* ₹ ' + inr(b.totBeforeGstTds) + '\\n' +
    '• Less GST TDS Deductions: ₹ ' + inr(b.totGstTds) + '\\n' +
    '💵 *TOTAL CASH RECEIVABLE (BASE):* ₹ ' + inr(b.totRec) + '\\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '📅 *PAYMENT SCHEDULE & STATUS:*\\n' +
    '1️⃣ *Security Deposit (SD - 25%):*\\n' +
    '   • SD Expected: ₹ ' + inr(b.totSdExp) + '\\n' +
    sdRecLine +
    '   • *SD Balance Due:* ₹ ' + inr(b.totSdDue) + (b.totSdDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\\n\\n' +
    '2️⃣ *Final Payment (FP - after GST TDS):*\\n' +
    '   • FP Expected: ₹ ' + inr(b.totFpExp) + '\\n' +
    fpRecLine +
    '   • *FP Balance Due:* ₹ ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\\n\\n' +
    lateFeeLine +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '📥 *Total Received to Date:* ₹ ' + inr(b.totReceived) + '\\n' +
    '🔴 *NET AMOUNT PAYABLE NOW (INCL. LATE FEE):* ₹ ' + inr(b.totOut) + '\\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━\\n' +
    '🏦 *Remittance Instructions:*\\n' +
    'Please transfer payment via RTGS/NEFT to MSETCL designated bank account with reference to the Buyer Name & Lot No.\\n' +
    'Thank you for your business.';

  return msg;
}"""

    content = re.sub(
        r"function generateWhatsAppAdviceText\(lotsList, buyerTitle\) \{[\s\S]*?\n\}\n\nfunction generateEmailAdviceText",
        new_wa_func + "\n\nfunction generateEmailAdviceText",
        content
    )

    # 2. Update generateEmailAdviceText
    new_email_func = """function generateEmailAdviceText(lotsList, buyerTitle) {
  var isMulti = lotsList.length > 1;
  var bName = buyerTitle || (lotsList[0] ? lotsList[0].buyer : 'Valued Buyer');
  var b = computeAdviceBreakdown(lotsList);

  var sdRecEmail = '- Received     : Rs. ' + inr(b.totSdRec) + (b.totSdRec > 0 && b.sdDatesStr ? (' (Date: ' + b.sdDatesStr + ')') : '');
  var fpRecEmail = '- Received     : Rs. ' + inr(b.totFpRec) + (b.totFpRec > 0 && b.fpDatesStr ? (' (Date: ' + b.fpDatesStr + ')') : '');

  var txt = 
    'PAYMENT DEMAND ADVICE — MSETCL LIMITED\\n' +
    '======================================================\\n' +
    'To: ' + bName + '\\n' +
    'Scope: ' + (isMulti ? (lotsList.length + ' Lots Consolidated') : ('Lot No. ' + lotsList[0].lot_no + ' (' + (lotsList[0].lot_name || 'Material') + ')')) + '\\n\\n' +
    'VALUATION & STATUTORY CHARGES BREAKDOWN:\\n' +
    '------------------------------------------------------\\n' +
    'Material Value (Qty x Rate)        : Rs. ' + inr(b.totMat) + '\\n' +
    'GST @ 18%                          : Rs. ' + inr(b.totGst) + '\\n' +
    'Material Value + GST               : Rs. ' + inr(b.totMatGst) + '\\n' +
    'TCS @ 2% of Material Value         : Rs. ' + inr(b.totTcs) + '\\n' +
    'Gross Material Consideration       : Rs. ' + inr(b.totGrossValuation) + '\\n\\n' +
    'MSTC SERVICE CHARGE BREAKUP:\\n' +
    '------------------------------------------------------\\n' +
    '1. Service Charge to MSTC (2.25%)  : Rs. ' + inr(b.totScBasic) + '\\n' +
    '2. GST @ 18% on Service Charge     : Rs. ' + inr(b.totScGst) + '\\n' +
    '3. Service Charge + GST (2.655%)   : Rs. ' + inr(b.totScWithGst) + '\\n' +
    '4. TDS u/s 194(O) (0.1% of Mat)    : Rs. ' + inr(b.totTds194o) + '\\n' +
    '5. TDS u/s 194(H) (2% of SC)       : Rs. ' + inr(b.totTds194h) + '\\n' +
    '6. Net SC to MSTC (3+4-5 = 2.71%)  : Rs. ' + inr(b.totSc271) + '\\n' +
    '------------------------------------------------------\\n' +
    'TOTAL BEFORE GST TDS               : Rs. ' + inr(b.totBeforeGstTds) + '\\n' +
    'Less: GST TDS Deductions           : Rs. ' + inr(b.totGstTds) + '\\n' +
    '------------------------------------------------------\\n' +
    'TOTAL CASH RECEIVABLE (BASE)       : Rs. ' + inr(b.totRec) + '\\n' +
    '======================================================\\n\\n' +
    'PAYMENT SCHEDULE & STATUS:\\n' +
    '1. Security Deposit (SD - 25%):\\n' +
    '   - Expected : Rs. ' + inr(b.totSdExp) + '\\n' +
    '   ' + sdRecEmail + '\\n' +
    '   - Balance Due : Rs. ' + inr(b.totSdDue) + (b.totSdDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\\n\\n' +
    '2. Final Payment (FP - after GST TDS):\\n' +
    '   - Expected : Rs. ' + inr(b.totFpExp) + '\\n' +
    '   ' + fpRecEmail + '\\n' +
    '   - Balance Due : Rs. ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\\n\\n' +
    '3. Late Fee @ 1% per week (from 24.08.2026):\\n' +
    '   - Accrued Late Fee : Rs. ' + inr(b.totLateFee) + (b.totLateFee > 0 ? ' (PAYABLE)' : ' (NIL / ON TIME)') + '\\n\\n' +
    '------------------------------------------------------\\n' +
    'Total Amount Received to Date      : Rs. ' + inr(b.totReceived) + '\\n' +
    'NET OUTSTANDING AMOUNT PAYABLE     : Rs. ' + inr(b.totOut) + '\\n' +
    '======================================================\\n' +
    'Please transfer payment via RTGS/NEFT to MSETCL designated account.\\n' +
    'MSETCL LIMITED — Cash Receivables SaaS Platform';

  return txt;
}"""

    content = re.sub(
        r"function generateEmailAdviceText\(lotsList, buyerTitle\) \{[\s\S]*?\n\}\n\nfunction printPaymentAdvice",
        new_email_func + "\n\nfunction printPaymentAdvice",
        content
    )

    # 3. Update printPaymentAdvice
    new_print_func = """function printPaymentAdvice(lotsList, buyerTitle) {
  var isMulti = lotsList.length > 1;
  var bName = buyerTitle || (lotsList[0] ? lotsList[0].buyer : 'Valued Buyer');
  var b = computeAdviceBreakdown(lotsList);

  var r0 = lotsList[0] || {};
  var w = window.open('', '_blank');
  if (!w) { showToast('Allow pop-ups to print payment advice.', 'error'); return; }

  var lotRowsHtml = lotsList.map(function (lot, i) {
    var lSdDue = Math.max(0, numOr(lot.sd_expected) - numOr(lot.sd_received));
    var lFpDue = Math.max(0, numOr(lot.fp_expected) - numOr(lot.fp_received));
    var lLateFee = numOr(lot.late_fee);
    var lOut = numOr(lot.outstanding);
    var lBeforeGstTds = Math.round((numOr(lot.mat_value_plus_gst) || (numOr(lot.mat_value) + numOr(lot.gst))) + numOr(lot.tcs) - numOr(lot.service_charge_to_mstc));
    return '<tr>' +
      '<td style="text-align:center">' + (i + 1) + '</td>' +
      '<td style="font-weight:bold">' + escHtml(lot.lot_no) + '</td>' +
      '<td>' + escHtml(lot.auction || '—') + '</td>' +
      '<td>' + escHtml(lot.lot_name) + '</td>' +
      '<td style="text-align:right">' + numFmt(lot.qty) + ' ' + escHtml(lot.unit || '') + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.rate) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.mat_value) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.gst) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.tcs) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.service_charge_to_mstc) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lBeforeGstTds) + '</td>' +
      '<td style="text-align:right">₹ ' + inr(lot.gst_tds) + '</td>' +
      '<td style="text-align:right;font-weight:bold">₹ ' + inr(lot.total_receivables) + '</td>' +
      '<td style="text-align:right">' + (lSdDue > 1 ? ('₹ ' + inr(lSdDue)) : 'Paid') + '</td>' +
      '<td style="text-align:center;font-size:10px">' + escHtml(dottedDate(lot.sd_date) || '—') + '</td>' +
      '<td style="text-align:right">' + (lFpDue > 1 ? ('₹ ' + inr(lFpDue)) : 'Paid') + '</td>' +
      '<td style="text-align:center;font-size:10px">' + escHtml(dottedDate(lot.fp_date) || '—') + '</td>' +
      '<td style="text-align:right;color:#be123c">' + (lLateFee > 0 ? ('₹ ' + inr(lLateFee)) : '₹ 0') + '</td>' +
      '<td style="text-align:right;font-weight:bold">' + (lOut > 1 ? ('₹ ' + inr(lOut)) : 'Settled') + '</td>' +
    '</tr>';
  }).join('');

  var html = '<!DOCTYPE html><html><head><meta charset="utf-8"/><title>Payment Demand Advice — ' + escHtml(bName) + '</title>' +
    '<style>' +
      'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:#0f172a;margin:24px;font-size:12px;line-height:1.4}' +
      '.header{border-bottom:2px solid #002FA7;padding-bottom:12px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:flex-start}' +
      '.header h1{margin:0;font-size:18px;color:#002FA7;letter-spacing:0.5px}' +
      '.header p{margin:2px 0 0;font-size:11px;color:#64748b}' +
      '.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:16px}' +
      '.kpi{border:1px solid #cbd5e1;border-radius:8px;padding:10px 12px;background:#f8fafc}' +
      '.kpi-lbl{font-size:10px;font-weight:bold;text-transform:uppercase;color:#64748b}' +
      '.kpi-val{font-size:16px;font-weight:800;color:#0f172a;margin-top:2px}' +
      '.kpi.accent{background:#eff6ff;border-color:#bfdbfe;color:#1d4ed8}' +
      '.kpi.accent .kpi-val{color:#1d4ed8}' +
      '.kpi.due{background:#fff1f2;border-color:#fecdd3}' +
      '.kpi.due .kpi-val{color:#be123c}' +
      'table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:11.5px}' +
      'th,td{border:1px solid #cbd5e1;padding:6px 8px}' +
      'th{background:#f1f5f9;font-weight:bold;text-align:left}' +
      '.num{text-align:right}' +
      '.subhead{font-size:13px;font-weight:bold;color:#002FA7;margin:14px 0 6px}' +
      '.note{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:10px 12px;font-size:11px;color:#475569;margin-top:16px}' +
      '@media print{body{margin:0}button{display:none}}' +
    '</style></head><body>' +
    '<div class="header">' +
      '<div>' +
        '<h1>MSETCL LIMITED</h1>' +
        '<p>Cash Receivables Platform · Scrap Auction Disposal Division</p>' +
        '<h2 style="font-size:14px;margin:8px 0 0;color:#0f172a">BUYER PAYMENT DEMAND ADVICE</h2>' +
      '</div>' +
      '<div style="text-align:right">' +
        '<div><b>Buyer:</b> ' + escHtml(bName) + '</div>' +
        '<div><b>Date:</b> ' + (new Date()).toLocaleDateString('en-GB') + '</div>' +
        '<div><b>Scope:</b> ' + (isMulti ? (lotsList.length + ' Lots') : ('Lot No. ' + r0.lot_no)) + '</div>' +
      '</div>' +
    '</div>' +

    '<div class="kpis">' +
      '<div class="kpi accent"><div class="kpi-lbl">Total Cash Payable</div><div class="kpi-val">₹ ' + inr(b.totRec) + '</div></div>' +
      '<div class="kpi"><div class="kpi-lbl">Security Deposit Due</div><div class="kpi-val">₹ ' + inr(b.totSdDue) + '</div><div style="font-size:9.5px;color:#64748b">Exp: ₹ ' + inr(b.totSdExp) + (b.totSdRec > 0 && b.sdDatesStr ? (' | ' + b.sdDatesStr) : '') + '</div></div>' +
      '<div class="kpi"><div class="kpi-lbl">Final Payment Due</div><div class="kpi-val">₹ ' + inr(b.totFpDue) + '</div><div style="font-size:9.5px;color:#64748b">Exp: ₹ ' + inr(b.totFpExp) + (b.totFpRec > 0 && b.fpDatesStr ? (' | ' + b.fpDatesStr) : '') + '</div></div>' +
      '<div class="kpi ' + (b.totLateFee > 0 ? 'due' : '') + '"><div class="kpi-lbl">Late Fee @ 1%/wk</div><div class="kpi-val">₹ ' + inr(b.totLateFee) + '</div><div style="font-size:9.5px;color:#64748b">From 24.08.2026</div></div>' +
      '<div class="kpi ' + (b.totOut > 1 ? 'due' : '') + '"><div class="kpi-lbl">Net Amount Due Now</div><div class="kpi-val">₹ ' + inr(b.totOut) + '</div><div style="font-size:9.5px;color:#64748b">Rec: ₹ ' + inr(b.totReceived) + '</div></div>' +
    '</div>' +

    '<div class="subhead">Valuation &amp; Statutory Charges Breakdown</div>' +
    '<table>' +
      '<tr><th style="width:50%">Particulars</th><th class="num">Amount (INR)</th><th>Remarks</th></tr>' +
      '<tr><td>Material Value (Qty × Rate)</td><td class="num">₹ ' + inr(b.totMat) + '</td><td>Base Scrap Bid Value</td></tr>' +
      '<tr><td>GST @ 18%</td><td class="num">₹ ' + inr(b.totGst) + '</td><td>Applicable Goods &amp; Services Tax</td></tr>' +
      '<tr><td>Material Value + GST</td><td class="num">₹ ' + inr(b.totMatGst) + '</td><td>Subtotal Material + Tax</td></tr>' +
      '<tr><td>TCS @ 2% of Material Value</td><td class="num">₹ ' + inr(b.totTcs) + '</td><td>Tax Collected at Source u/s 206C</td></tr>' +
      '<tr><td>Gross Material Consideration</td><td class="num">₹ ' + inr(b.totGrossValuation) + '</td><td>Material Value + GST + TCS</td></tr>' +
      '<tr><td colspan="3" style="background:#f1f5f9;font-weight:bold;color:#002FA7">MSTC SERVICE CHARGE BREAKUP</td></tr>' +
      '<tr><td>1. Service Charge to MSTC (2.25% of Material Value)</td><td class="num">₹ ' + inr(b.totScBasic) + '</td><td>Base Auction Agency Fee</td></tr>' +
      '<tr><td>2. GST @ 18% on Service Charge</td><td class="num">₹ ' + inr(b.totScGst) + '</td><td>18% GST on MSTC Service Charge</td></tr>' +
      '<tr><td>3. Service Charge + GST (2.655% of Material Value)</td><td class="num">₹ ' + inr(b.totScWithGst) + '</td><td>Gross Service Charge (1 + 2)</td></tr>' +
      '<tr><td>4. TDS u/s 194(O) (0.1% of Material Value)</td><td class="num">₹ ' + inr(b.totTds194o) + '</td><td>E-Commerce Operator TDS Deduction</td></tr>' +
      '<tr><td>5. TDS u/s 194(H) (2% of Service Charge)</td><td class="num">₹ ' + inr(b.totTds194h) + '</td><td>TDS on Commission / Service Charge</td></tr>' +
      '<tr style="background:#f8fafc;font-weight:bold"><td>6. Net Service Charge to MSTC (3 + 4 - 5 = 2.71%)</td><td class="num">₹ ' + inr(b.totSc271) + '</td><td>Net SC to MSTC (2.71% of Mat. Value)</td></tr>' +
      '<tr style="background:#eff6ff;font-weight:bold"><td>TOTAL BEFORE GST TDS CALCULATION</td><td class="num" style="color:#1d4ed8;font-size:12.5px">₹ ' + inr(b.totBeforeGstTds) + '</td><td>Gross Consideration less Net MSTC SC (2.71%)</td></tr>' +
      '<tr><td>Less: GST TDS Deductions</td><td class="num">- ₹ ' + inr(b.totGstTds) + '</td><td>TDS under GST Provisions</td></tr>' +
      '<tr style="background:#f1f5f9;font-weight:bold"><td>TOTAL CASH RECEIVABLE / PAYABLE (BASE)</td><td class="num" style="color:#002FA7;font-size:13px">₹ ' + inr(b.totRec) + '</td><td>Net Statutory Base Cash required</td></tr>' +
    '</table>' +

    '<div class="subhead">Payment Schedule &amp; Receipts Status</div>' +
    '<table>' +
      '<tr><th>Payment Stage</th><th class="num">Expected (₹)</th><th class="num">Received (₹)</th><th>Receipt Date</th><th class="num">Balance Due (₹)</th><th>Status</th></tr>' +
      '<tr><td><b>1. Security Deposit (SD - 25%)</b></td><td class="num">₹ ' + inr(b.totSdExp) + '</td><td class="num">₹ ' + inr(b.totSdRec) + '</td><td style="font-weight:bold;color:#002FA7">' + escHtml(b.sdDatesStr || '—') + '</td><td class="num" style="font-weight:bold">' + (b.totSdDue > 1 ? ('₹ ' + inr(b.totSdDue)) : '₹ 0') + '</td><td>' + (b.totSdDue <= 1 ? 'PAID / SETTLED' : 'PENDING PAYMENT') + '</td></tr>' +
      '<tr><td><b>2. Final Payment (FP - after GST TDS)</b></td><td class="num">₹ ' + inr(b.totFpExp) + '</td><td class="num">₹ ' + inr(b.totFpRec) + '</td><td style="font-weight:bold;color:#002FA7">' + escHtml(b.fpDatesStr || '—') + '</td><td class="num" style="font-weight:bold">' + (b.totFpDue > 1 ? ('₹ ' + inr(b.totFpDue)) : '₹ 0') + '</td><td>' + (b.totFpDue <= 1 ? 'PAID / SETTLED' : 'PENDING PAYMENT') + '</td></tr>' +
      '<tr><td><b>3. Late Fee @ 1%/wk (from 24.08.2026)</b></td><td class="num">₹ ' + inr(b.totLateFee) + '</td><td class="num">—</td><td style="font-size:10.5px;color:#64748b">1%/wk delayed</td><td class="num" style="font-weight:bold;color:' + (b.totLateFee > 0 ? '#be123c' : '#15803d') + '">₹ ' + inr(b.totLateFee) + '</td><td>' + (b.totLateFee > 0 ? 'ACCRUED / DUE' : 'NIL / ON TIME') + '</td></tr>' +
      '<tr style="background:#f1f5f9;font-weight:bold"><td>TOTALS</td><td class="num">₹ ' + inr(b.totRec + b.totLateFee) + '</td><td class="num">₹ ' + inr(b.totReceived) + '</td><td>—</td><td class="num" style="color:' + (b.totOut > 1 ? '#be123c' : '#15803d') + '">₹ ' + inr(b.totOut) + '</td><td>' + (b.totOut <= 1 ? 'FULLY SETTLED' : 'PAYMENT DUE') + '</td></tr>' +
    '</table>' +

    (isMulti ? ('<div class="subhead">Itemized Lot Breakdown</div><table><tr><th>#</th><th>Lot No.</th><th>Auction</th><th>Material</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Mat. Value</th><th class="num">GST</th><th class="num">TCS (2%)</th><th class="num">MSTC SC (2.71%)</th><th class="num">Before GST TDS</th><th class="num">GST TDS</th><th class="num">Total Cash</th><th class="num">SD Due</th><th>SD Date</th><th class="num">FP Due</th><th>FP Date</th><th class="num">Late Fee @ 1%</th><th class="num">Net Due</th></tr>' + lotRowsHtml + '</table>') : '') +

    '<div class="note">' +
      '<b>Payment Terms &amp; Instructions:</b><br/>' +
      '1. Payments must be remitted via RTGS / NEFT / Online Banking to the designated bank account of <b>MSETCL LIMITED</b>.<br/>' +
      '2. Security Deposit (25%) must be deposited within stipulated timeline of auction closing.<br/>' +
      '3. Final Payment (Balance amount after GST TDS &amp; adjustments) plus any applicable Late Fee (@ 1% per week or part thereof from 24th August 2026) must be cleared prior to material delivery / lifting order issue.<br/>' +
      '4. Always quote Lot Number(s) and Buyer Registration Name on remittance transaction references.' +
    '</div>' +
    '<div style="text-align:center;margin-top:20px"><button onclick="window.print()" style="padding:8px 20px;font-size:13px;font-weight:bold;cursor:pointer;background:#002FA7;color:#fff;border:none;border-radius:6px">🖨️ Print Payment Advice</button></div>' +
    '</body></html>';

  w.document.open();
  w.document.write(html);
  w.document.close();
}"""

    content = re.sub(
        r"function printPaymentAdvice\(lotsList, buyerTitle\) \{[\s\S]*?\n\}\n\nfunction openAdviceModal",
        new_print_func + "\n\nfunction openAdviceModal",
        content
    )

    # 4. Update openAdviceModal
    new_advice_modal = """function openAdviceModal(targetLots, buyerTitle) {
  if (typeof targetLots === 'number') {
    targetLots = [lots[targetLots]];
  } else if (!targetLots && lotSelection.size) {
    targetLots = Array.from(lotSelection).map(function (idx) { return lots[idx]; }).filter(Boolean);
  } else if (!targetLots) {
    targetLots = dashFilteredRows();
  }

  if (!targetLots.length) {
    showToast('No lots found for payment advice.', 'error');
    return;
  }

  var isMulti = targetLots.length > 1;
  var bName = buyerTitle || targetLots[0].buyer;
  var b = computeAdviceBreakdown(targetLots);

  var r0 = targetLots[0];
  var lotSubtitle = isMulti
    ? targetLots.length + ' Lots Consolidated (' + targetLots.map(function (x) { return '#' + x.lot_no; }).join(', ') + ')'
    : 'Lot #' + r0.lot_no + ' · Bid Sheet: ' + (r0.auction || '—') + ' · ' + (r0.lot_name || 'Material');

  var sdStatusPill = b.totSdDue <= 1
    ? '<span class="lbl-settled" style="font-size:9px">PAID / SETTLED</span>'
    : '<span class="lbl-unsettled" style="font-size:9px">DUE: ₹ ' + inr(b.totSdDue) + '</span>';

  var fpStatusPill = b.totFpDue <= 1
    ? '<span class="lbl-settled" style="font-size:9px">PAID / SETTLED</span>'
    : '<span class="lbl-unsettled" style="font-size:9px">DUE: ₹ ' + inr(b.totFpDue) + '</span>';

  var lateFeeStatusPill = b.totLateFee <= 0
    ? '<span class="lbl-settled" style="font-size:9px">NIL / ON TIME</span>'
    : '<span class="lbl-unsettled" style="font-size:9px">ACCRUED: ₹ ' + inr(b.totLateFee) + '</span>';

  var outStatusPill = b.totOut <= 1
    ? '<span class="lbl-settled">ALL SETTLED</span>'
    : '<span class="lbl-unsettled">PAYABLE: ₹ ' + inr(b.totOut) + '</span>';

  var multiLotTableHtml = '';
  if (isMulti) {
    multiLotTableHtml =
      '<div style="margin-top:14px">' +
        '<div class="lic-head" style="margin-bottom:6px">📊 Lot-by-Lot Itemized Breakdown (' + targetLots.length + ' Lots)</div>' +
        '<div style="max-height:160px;overflow-y:auto;border:1px solid rgba(255,255,255,0.08);border-radius:8px">' +
          '<table style="width:100%;font-size:11px;border-collapse:collapse;min-width:880px">' +
            '<thead style="background:#0a0a19;position:sticky;top:0">' +
              '<tr>' +
                '<th class="left" style="padding:5px 7px">Lot No.</th>' +
                '<th class="left" style="padding:5px 7px">Material</th>' +
                '<th style="padding:5px 7px">Qty</th>' +
                '<th style="padding:5px 7px">Rate</th>' +
                '<th style="padding:5px 7px">Mat. Value</th>' +
                '<th style="padding:5px 7px">GST (18%)</th>' +
                '<th style="padding:5px 7px">TCS (2%)</th>' +
                '<th style="padding:5px 7px" title="Service Charge to MSTC @ 2.71%">MSTC SC (2.71%)</th>' +
                '<th style="padding:5px 7px" title="Total Before GST TDS">Before GST TDS</th>' +
                '<th style="padding:5px 7px">GST TDS</th>' +
                '<th style="padding:5px 7px">Total Cash</th>' +
                '<th style="padding:5px 7px">SD Due</th>' +
                '<th style="padding:5px 7px">SD Date</th>' +
                '<th style="padding:5px 7px">FP Due</th>' +
                '<th style="padding:5px 7px">FP Date</th>' +
                '<th style="padding:5px 7px;color:#f9a8d4">Late Fee @ 1%</th>' +
                '<th style="padding:5px 7px">Net Due</th>' +
              '</tr>' +
            '</thead>' +
            '<tbody>' +
              targetLots.map(function (lot) {
                var lSdDue = Math.max(0, numOr(lot.sd_expected) - numOr(lot.sd_received));
                var lFpDue = Math.max(0, numOr(lot.fp_expected) - numOr(lot.fp_received));
                var lLateFee = numOr(lot.late_fee);
                var lOut = numOr(lot.outstanding);
                var lBeforeGstTds = Math.round((numOr(lot.mat_value_plus_gst) || (numOr(lot.mat_value) + numOr(lot.gst))) + numOr(lot.tcs) - numOr(lot.service_charge_to_mstc));
                return '<tr>' +
                  '<td class="left" style="font-weight:700;color:var(--cyan);padding:4px 7px">' + escHtml(lot.lot_no) + '</td>' +
                  '<td class="left" style="padding:4px 7px" title="' + escHtml(lot.lot_name) + '">' + escHtml(lot.lot_name ? (lot.lot_name.slice(0, 18) + (lot.lot_name.length > 18 ? '…' : '')) : '—') + '</td>' +
                  '<td style="padding:4px 7px">' + numFmt(lot.qty) + ' ' + escHtml(lot.unit || '') + '</td>' +
                  '<td style="padding:4px 7px">₹ ' + inr(lot.rate) + '</td>' +
                  '<td style="padding:4px 7px">₹ ' + inr(lot.mat_value) + '</td>' +
                  '<td style="padding:4px 7px">₹ ' + inr(lot.gst) + '</td>' +
                  '<td style="padding:4px 7px">₹ ' + inr(lot.tcs) + '</td>' +
                  '<td style="padding:4px 7px;color:#c4b5fd">₹ ' + inr(lot.service_charge_to_mstc) + '</td>' +
                  '<td style="padding:4px 7px;color:#67e8f9">₹ ' + inr(lBeforeGstTds) + '</td>' +
                  '<td style="padding:4px 7px">₹ ' + inr(lot.gst_tds) + '</td>' +
                  '<td style="padding:4px 7px;font-weight:700;color:var(--cyan)">₹ ' + inr(lot.total_receivables) + '</td>' +
                  '<td style="padding:4px 7px;' + (lSdDue > 1 ? 'color:#f9a8d4;font-weight:700' : 'color:#69d791') + '">₹ ' + inr(lSdDue) + '</td>' +
                  '<td style="padding:4px 7px;font-size:10px;color:var(--muted)">' + escHtml(dottedDate(lot.sd_date) || '—') + '</td>' +
                  '<td style="padding:4px 7px;' + (lFpDue > 1 ? 'color:#f9a8d4;font-weight:700' : 'color:#69d791') + '">₹ ' + inr(lFpDue) + '</td>' +
                  '<td style="padding:4px 7px;font-size:10px;color:var(--muted)">' + escHtml(dottedDate(lot.fp_date) || '—') + '</td>' +
                  '<td style="padding:4px 7px;color:#f9a8d4;font-weight:700">' + (lLateFee > 0 ? ('₹ ' + inr(lLateFee)) : '₹ 0') + '</td>' +
                  '<td style="padding:4px 7px;font-weight:700;' + (lOut > 1 ? 'color:#f72585' : 'color:#69d791') + '">₹ ' + inr(lOut) + '</td>' +
                '</tr>';
              }).join('') +
            '</tbody>' +
            '<tfoot style="background:rgba(0,245,255,0.05);font-weight:700">' +
              '<tr>' +
                '<td class="left" colspan="2" style="padding:5px 7px">Total (' + targetLots.length + ' lots)</td>' +
                '<td style="padding:5px 7px">' + numFmt(b.totQty) + '</td>' +
                '<td style="padding:5px 7px">—</td>' +
                '<td style="padding:5px 7px">₹ ' + inr(b.totMat) + '</td>' +
                '<td style="padding:5px 7px">₹ ' + inr(b.totGst) + '</td>' +
                '<td style="padding:5px 7px">₹ ' + inr(b.totTcs) + '</td>' +
                '<td style="padding:5px 7px;color:#c4b5fd">₹ ' + inr(b.totSc271) + '</td>' +
                '<td style="padding:5px 7px;color:#67e8f9">₹ ' + inr(b.totBeforeGstTds) + '</td>' +
                '<td style="padding:5px 7px">₹ ' + inr(b.totGstTds) + '</td>' +
                '<td style="padding:5px 7px;color:var(--cyan)">₹ ' + inr(b.totRec) + '</td>' +
                '<td style="padding:5px 7px;color:#f9a8d4">₹ ' + inr(b.totSdDue) + '</td>' +
                '<td style="padding:5px 7px;font-size:10px;color:var(--cyan)">' + escHtml(b.sdDatesStr || '—') + '</td>' +
                '<td style="padding:5px 7px;color:#f9a8d4">₹ ' + inr(b.totFpDue) + '</td>' +
                '<td style="padding:5px 7px;font-size:10px;color:var(--cyan)">' + escHtml(b.fpDatesStr || '—') + '</td>' +
                '<td style="padding:5px 7px;color:#f9a8d4">₹ ' + inr(b.totLateFee) + '</td>' +
                '<td style="padding:5px 7px;color:#f72585">₹ ' + inr(b.totOut) + '</td>' +
              '</tr>' +
            '</tfoot>' +
          '</table>' +
        '</div>' +
      '</div>';
  }

  var sdCardDateHtml = (b.totSdRec > 0 && b.sdDatesStr) ? ('<div style="font-size:10px;color:var(--dim);margin-top:2px">📅 Rec Date: <b style="color:var(--text)">' + escHtml(b.sdDatesStr) + '</b></div>') : '';
  var fpCardDateHtml = (b.totFpRec > 0 && b.fpDatesStr) ? ('<div style="font-size:10px;color:var(--dim);margin-top:2px">📅 Rec Date: <b style="color:var(--text)">' + escHtml(b.fpDatesStr) + '</b></div>') : '';

  var sdReceiptDateRow = (b.totSdRec > 0 && b.sdDatesStr) ? ('<div class="lic-row"><span class="lic-k">SD Receipt Date</span><span class="lic-v strong" style="color:var(--cyan)">' + escHtml(b.sdDatesStr) + '</span></div>') : '';
  var fpReceiptDateRow = (b.totFpRec > 0 && b.fpDatesStr) ? ('<div class="lic-row"><span class="lic-k">FP Receipt Date</span><span class="lic-v strong" style="color:var(--cyan)">' + escHtml(b.fpDatesStr) + '</span></div>') : '';

  var body =
    '<div class="buyer-advice-modal" style="font-family:Inter,system-ui,sans-serif">' +
      '<!-- Header Banner -->' +
      '<div style="background:linear-gradient(135deg,rgba(0,245,255,0.08),rgba(124,58,237,0.12));border:1px solid rgba(0,245,255,0.2);border-radius:12px;padding:12px 18px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">' +
        '<div>' +
          '<div style="font-size:10px;font-weight:800;letter-spacing:1px;color:var(--cyan);text-transform:uppercase">▸ MSETCL LIMITED — CASH RECEIVABLES PAYMENT DEMAND ADVICE</div>' +
          '<div style="font-size:16px;font-weight:800;color:#ffffff;margin-top:2px">' + escHtml(bName) + '</div>' +
          '<div style="font-size:11.5px;color:var(--muted);margin-top:2px">' + escHtml(lotSubtitle) + '</div>' +
        '</div>' +
        '<div style="text-align:right">' +
          '<div style="font-size:10px;font-weight:700;color:var(--dim);text-transform:uppercase">Overall Status</div>' +
          '<div style="margin-top:3px">' + outStatusPill + '</div>' +
        '</div>' +
      '</div>' +

      '<!-- 5 KPI Highlight Cards (Includes Late Fee) -->' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-bottom:14px">' +
        '<div style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.25);border-radius:10px;padding:10px 12px">' +
          '<div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--cyan);letter-spacing:0.5px">Total Cash (Base)</div>' +
          '<div style="font-size:17px;font-weight:900;color:#ffffff;margin-top:3px">₹ ' + inr(b.totRec) + '</div>' +
          '<div style="font-size:10px;color:var(--muted);margin-top:2px">Net Statutory Base</div>' +
        '</div>' +

        '<div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:10px 12px">' +
          '<div style="display:flex;justify-content:space-between;align-items:center">' +
            '<span style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:0.5px">1. SD Due (25%)</span>' +
            sdStatusPill +
          '</div>' +
          '<div style="font-size:17px;font-weight:900;color:' + (b.totSdDue > 1 ? '#f9a8d4' : '#69d791') + ';margin-top:3px">₹ ' + inr(b.totSdDue) + '</div>' +
          '<div style="font-size:10px;color:var(--muted);margin-top:2px">Exp: ₹ ' + inr(b.totSdExp) + ' | Rec: ₹ ' + inr(b.totSdRec) + '</div>' +
          sdCardDateHtml +
        '</div>' +

        '<div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:10px 12px">' +
          '<div style="display:flex;justify-content:space-between;align-items:center">' +
            '<span style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:0.5px">2. FP Due (after TDS)</span>' +
            fpStatusPill +
          '</div>' +
          '<div style="font-size:17px;font-weight:900;color:' + (b.totFpDue > 1 ? '#f9a8d4' : '#69d791') + ';margin-top:3px">₹ ' + inr(b.totFpDue) + '</div>' +
          '<div style="font-size:10px;color:var(--muted);margin-top:2px">Exp: ₹ ' + inr(b.totFpExp) + ' | Rec: ₹ ' + inr(b.totFpRec) + '</div>' +
          fpCardDateHtml +
        '</div>' +

        '<div style="background:rgba(124,58,237,0.08);border:1px solid rgba(124,58,237,0.3);border-radius:10px;padding:10px 12px">' +
          '<div style="display:flex;justify-content:space-between;align-items:center">' +
            '<span style="font-size:9px;font-weight:700;text-transform:uppercase;color:#c4b5fd;letter-spacing:0.5px">3. Late Fee @ 1%</span>' +
            lateFeeStatusPill +
          '</div>' +
          '<div style="font-size:17px;font-weight:900;color:' + (b.totLateFee > 0 ? '#f9a8d4' : '#69d791') + ';margin-top:3px">₹ ' + inr(b.totLateFee) + '</div>' +
          '<div style="font-size:10px;color:#c4b5fd;margin-top:2px">1%/wk beyond 24.08.2026</div>' +
        '</div>' +

        '<div style="background:rgba(247,37,133,0.08);border:1px solid rgba(247,37,133,0.35);border-radius:10px;padding:10px 12px">' +
          '<div style="font-size:9px;font-weight:700;text-transform:uppercase;color:#f9a8d4;letter-spacing:0.5px">Net Amount Payable</div>' +
          '<div style="font-size:17px;font-weight:900;color:' + (b.totOut > 1 ? '#f72585' : '#69d791') + ';margin-top:3px">₹ ' + inr(b.totOut) + '</div>' +
          '<div style="font-size:10px;color:var(--muted);margin-top:2px">Total Rec: ₹ ' + inr(b.totReceived) + '</div>' +
        '</div>' +
      '</div>' +

      '<!-- Detailed Breakdown Columns -->' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
        '<!-- Block 1: Valuation, TCS & MSTC Service Charge Breakup -->' +
        '<div style="background:rgba(13,13,26,0.6);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:12px">' +
          '<div class="lic-head" style="margin-bottom:8px">💰 Material Valuation, TCS &amp; MSTC Service Charge</div>' +
          '<div class="lic-table">' +
            '<div class="lic-row"><span class="lic-k">Material Value (Qty × Rate)</span><span class="lic-v strong">₹ ' + inr(b.totMat) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">GST @ 18%</span><span class="lic-v">₹ ' + inr(b.totGst) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">Material Value + GST</span><span class="lic-v">₹ ' + inr(b.totMatGst) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">TCS @ 2% (of Material Value)</span><span class="lic-v">₹ ' + inr(b.totTcs) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k" style="color:var(--muted)">Gross Consideration (Mat + GST + TCS)</span><span class="lic-v strong">₹ ' + inr(b.totGrossValuation) + '</span></div>' +
            '<div style="height:4px"></div>' +
            '<div style="font-size:10.5px;font-weight:800;color:#c4b5fd;text-transform:uppercase;letter-spacing:0.5px;padding:4px 0 2px">⚡ MSTC Service Charge Breakup:</div>' +
            '<div class="lic-row"><span class="lic-k">1. Service Charge to MSTC (2.25%)</span><span class="lic-v">₹ ' + inr(b.totScBasic) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">2. GST @ 18% on Service Charge</span><span class="lic-v">₹ ' + inr(b.totScGst) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">3. Service Charge + GST (2.655%)</span><span class="lic-v">₹ ' + inr(b.totScWithGst) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">4. TDS u/s 194(O) (0.1% of Mat)</span><span class="lic-v">₹ ' + inr(b.totTds194o) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">5. TDS u/s 194(H) (2% of SC)</span><span class="lic-v">₹ ' + inr(b.totTds194h) + '</span></div>' +
            '<div class="lic-row" style="background:rgba(124,58,237,0.12);border-radius:6px;padding:3px 6px;margin:2px 0">' +
              '<span class="lic-k" style="color:#c4b5fd;font-weight:700">6. Net SC to MSTC (3+4-5 = 2.71%)</span>' +
              '<span class="lic-v strong" style="color:#c4b5fd">₹ ' + inr(b.totSc271) + '</span>' +
            '</div>' +
            '<div style="height:4px"></div>' +
            '<div class="lic-row" style="background:rgba(0,245,255,0.08);border-radius:6px;padding:4px 6px;margin:2px 0;border:1px solid rgba(0,245,255,0.25)">' +
              '<span class="lic-k" style="color:var(--cyan);font-weight:800">⚡ TOTAL BEFORE GST TDS</span>' +
              '<span class="lic-v strong" style="color:var(--cyan);font-size:12.5px">₹ ' + inr(b.totBeforeGstTds) + '</span>' +
            '</div>' +
            '<div class="lic-row"><span class="lic-k">Less: GST TDS Deductions</span><span class="lic-v">₹ ' + inr(b.totGstTds) + '</span></div>' +
            '<div class="lic-row" style="border-top:1px solid rgba(0,245,255,0.3);margin-top:4px;padding-top:4px">' +
              '<span class="lic-k" style="color:var(--cyan);font-weight:900;font-size:12px">TOTAL CASH RECEIVABLE (BASE)</span>' +
              '<span class="lic-v highlight strong" style="font-size:14px">₹ ' + inr(b.totRec) + '</span>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<!-- Block 2: SD, Final Payment & Late Fee Breakdown -->' +
        '<div style="background:rgba(13,13,26,0.6);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">' +
          '<div>' +
            '<div class="lic-head" style="margin-bottom:8px">💳 Payment Schedule, Late Fee &amp; Balance</div>' +
            '<div class="lic-table">' +
              '<div class="lic-row" style="background:rgba(0,245,255,0.06);border-radius:6px;padding:4px 6px">' +
                '<span class="lic-k" style="color:var(--cyan);font-weight:700">1️⃣ Security Deposit (SD - 25%)</span>' +
                '<span class="lic-v strong" style="color:var(--cyan)">Expected ₹ ' + inr(b.totSdExp) + '</span>' +
              '</div>' +
              '<div class="lic-row"><span class="lic-k">SD Amount Received</span><span class="lic-v success">₹ ' + inr(b.totSdRec) + '</span></div>' +
              sdReceiptDateRow +
              '<div class="lic-row"><span class="lic-k">SD Balance Due</span><span class="lic-v strong ' + (b.totSdDue > 1 ? 'pos' : '') + '">₹ ' + inr(b.totSdDue) + '</span></div>' +
              '<div style="height:5px"></div>' +
              '<div class="lic-row" style="background:rgba(124,58,237,0.08);border-radius:6px;padding:4px 6px">' +
                '<span class="lic-k" style="color:#c4b5fd;font-weight:700">2️⃣ Final Payment Due (FP - after GST TDS)</span>' +
                '<span class="lic-v strong" style="color:#c4b5fd">Expected ₹ ' + inr(b.totFpExp) + '</span>' +
              '</div>' +
              '<div class="lic-row"><span class="lic-k">FP Amount Received</span><span class="lic-v success">₹ ' + inr(b.totFpRec) + '</span></div>' +
              fpReceiptDateRow +
              '<div class="lic-row"><span class="lic-k">FP Balance Due</span><span class="lic-v strong ' + (b.totFpDue > 1 ? 'pos' : '') + '">₹ ' + inr(b.totFpDue) + '</span></div>' +
              '<div style="height:5px"></div>' +
              '<div class="lic-row" style="background:rgba(247,37,133,0.08);border-radius:6px;padding:4px 6px;border:1px solid rgba(247,37,133,0.25)">' +
                '<span class="lic-k" style="color:#f9a8d4;font-weight:700">3️⃣ Late Fee @ 1%/wk (from 24.08.2026)</span>' +
                '<span class="lic-v strong" style="color:#f9a8d4">₹ ' + inr(b.totLateFee) + '</span>' +
              '</div>' +
              '<div class="lic-row"><span class="lic-k">Delay Calculation Basis</span><span class="lic-v" style="font-size:10.5px;color:var(--dim)">1% per wk on balance FP</span></div>' +
              '<div class="lic-row" style="border-top:1px solid rgba(247,37,133,0.3);margin-top:4px;padding-top:4px">' +
                '<span class="lic-k" style="color:#f72585;font-weight:800">NET AMOUNT PAYABLE NOW</span>' +
                '<span class="lic-v strong ' + (b.totOut > 1 ? 'neg' : '') + '" style="font-size:14px;color:' + (b.totOut > 1 ? '#f72585' : '#69d791') + '">₹ ' + inr(b.totOut) + '</span>' +
              '</div>' +
            '</div>' +
          '</div>' +

          '<div style="background:rgba(0,0,0,0.3);border:1px dashed rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;margin-top:10px;font-size:11px;color:var(--dim);line-height:1.4">' +
            '<b style="color:var(--muted)">🏦 Remittance Note:</b> Remit payment via RTGS/NEFT to MSETCL account with reference to <b style="color:var(--text)">' + escHtml(bName) + '</b>.' +
          '</div>' +
        '</div>' +
      '</div>' +

      multiLotTableHtml +
    '</div>';

  var modal = openModal({
    title: 'Payment Demand Advice — ' + bName,
    ultraWide: true,
    body: body,
    actions: [
      {
        label: '📱 Copy WhatsApp Advice',
        cls: 'primary',
        onClick: function () {
          var text = generateWhatsAppAdviceText(targetLots, bName);
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
              showToast('Copied WhatsApp Payment Advice for ' + bName, 'ok');
            }).catch(function () { fallbackCopy(text); });
          } else fallbackCopy(text);
          return false;
        }
      },
      {
        label: '✉️ Copy Email Advice',
        cls: '',
        onClick: function () {
          var text = generateEmailAdviceText(targetLots, bName);
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
              showToast('Copied Email Payment Advice for ' + bName, 'ok');
            }).catch(function () { fallbackCopy(text); });
          } else fallbackCopy(text);
          return false;
        }
      },
      {
        label: '🖨️ Print / Save PDF',
        cls: '',
        onClick: function () {
          printPaymentAdvice(targetLots, bName);
        }
      },
      {
        label: 'Close',
        cls: '',
        onClick: function () {}
      }
    ]
  });
}"""

    content = re.sub(
        r"function openAdviceModal\(targetLots, buyerTitle\) \{[\s\S]*?\n\}\n\n/\* ---------------- Lot Inspection Modal",
        new_advice_modal + "\n\n/* ---------------- Lot Inspection Modal",
        content
    )

    # 5. In openLotDetails (Single Lot Inspection Modal), add Late Fee in Col 3
    old_inspect_col3 = """            '<div class="lic-row"><span class="lic-k">FP Date</span><span class="lic-v">' + escHtml(dottedDate(r.fp_date) || '—') + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">Total Received</span><span class="lic-v success strong">₹ ' + moneyFmt(r.total_received || 0) + '</span></div>' +"""

    new_inspect_col3 = """            '<div class="lic-row"><span class="lic-k">FP Date</span><span class="lic-v">' + escHtml(dottedDate(r.fp_date) || '—') + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">Late Fee @ 1%</span><span class="lic-v strong" style="color:#f9a8d4">₹ ' + moneyFmt(r.late_fee || 0) + '</span></div>' +
            '<div class="lic-row"><span class="lic-k">Total Received</span><span class="lic-v success strong">₹ ' + moneyFmt(r.total_received || 0) + '</span></div>' +"""

    if old_inspect_col3 in content:
        content = content.replace(old_inspect_col3, new_inspect_col3)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"Updated Payment Advice Suite in {fpath} successfully!")
