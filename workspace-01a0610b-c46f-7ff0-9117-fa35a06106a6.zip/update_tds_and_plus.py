with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update FIELD_META for tds194h
text = text.replace(
    "tds194h: { label: 'TDS u/s 194(H)', kind: '', sum: true },",
    "tds194h: { label: 'TDS u/s 194(H) (-)', kind: '', sum: true },"
)

# 2. Update EXPORT_COLS for tds194h
text = text.replace(
    "['tds194h', 'TDS u/s 194(H)', 'f:ROUND(H{r}*2.25%*2%,0)'],",
    "['tds194h', 'TDS u/s 194(H) (-)', 'f:ROUND(H{r}*2.25%*2%,0)'],"
)
text = text.replace(
    "['tds194h', 'TDS u/s 194(H)'],",
    "['tds194h', 'TDS u/s 194(H) (-)'],"
)
text = text.replace(
    "['tds194h', 'TDS u/s 194(H)', ''],",
    "['tds194h', 'TDS u/s 194(H) (-)', ''],"
)

# 3. Update formatCellValue for tds194h
old_fcv = """function formatCellValue(r, key) {
  var v = getLotField(r, key);
  var kind = fieldKind(key);
  if (kind === 'date' || kind === 'date-edit') return v ? escHtml(v) : '—';
  if (key === 'settlement_status' || kind === 'status') return settlementLabelHtml(r);
  if (kind === 'left' || kind === 'edit-text') return escHtml(v === null || v === undefined ? '' : v);
  if (typeof v === 'number' || (v !== '' && v !== null && v !== undefined && isFiniteNum(Number(v)) && !isCustomField(key))) {
    var n = typeof v === 'number' ? v : Number(v);
    return MONEY_FIELDS.has(key) ? moneyFmt(n) : numFmt(n);
  }"""

new_fcv = """function formatCellValue(r, key) {
  var v = getLotField(r, key);
  var kind = fieldKind(key);
  if (kind === 'date' || kind === 'date-edit') return v ? escHtml(v) : '—';
  if (key === 'settlement_status' || kind === 'status') return settlementLabelHtml(r);
  if (kind === 'left' || kind === 'edit-text') return escHtml(v === null || v === undefined ? '' : v);
  if (key === 'tds194h') {
    var n = typeof v === 'number' ? v : Number(v);
    if (!n || isNaN(n)) return '—';
    return '- ' + moneyFmt(Math.abs(n));
  }
  if (typeof v === 'number' || (v !== '' && v !== null && v !== undefined && isFiniteNum(Number(v)) && !isCustomField(key))) {
    var n = typeof v === 'number' ? v : Number(v);
    return MONEY_FIELDS.has(key) ? moneyFmt(n) : numFmt(n);
  }"""

if old_fcv in text:
    text = text.replace(old_fcv, new_fcv, 1)
    print("Updated formatCellValue for tds194h")
else:
    print("formatCellValue not found!")

# 4. Update tfoot in renderDetailInto and renderPivot
old_tfoot_detail = """    if (numericFields.indexOf(f) !== -1 || (custom && custom.type === 'number')) {
      var s = rows.reduce(function (a, r) { return a + numOr(getLotField(r, f)); }, 0);
      return '<td class="num">' + (MONEY_FIELDS.has(f) || (custom && custom.type === 'number') ? moneyFmt(s) : numFmt(s)) + '</td>';
    }"""

new_tfoot_detail = """    if (numericFields.indexOf(f) !== -1 || (custom && custom.type === 'number')) {
      var s = rows.reduce(function (a, r) { return a + numOr(getLotField(r, f)); }, 0);
      if (f === 'tds194h') return '<td class="num">' + (s ? '- ' + moneyFmt(Math.abs(s)) : '—') + '</td>';
      return '<td class="num">' + (MONEY_FIELDS.has(f) || (custom && custom.type === 'number') ? moneyFmt(s) : numFmt(s)) + '</td>';
    }"""

if old_tfoot_detail in text:
    text = text.replace(old_tfoot_detail, new_tfoot_detail, 1)
    print("Updated tfoot in renderDetailInto for tds194h")
else:
    print("old_tfoot_detail not found, checking...")

old_tfoot_pivot = """    tfoot.innerHTML = '<tr>' + cols.map(function (f, i) {
      if (i === 0) return '<td class="left">Total (' + dRows.length + ' lots)</td>';
      var meta = FIELD_META[f];
      if (meta && meta.sum) {
        var s = sumField(dRows, f);
        return '<td>' + (MONEY_FIELDS.has(f) ? moneyFmt(s) : numFmt(s)) + '</td>';
      }
      return '<td></td>';
    }).join('') + '</tr>';"""

new_tfoot_pivot = """    tfoot.innerHTML = '<tr>' + cols.map(function (f, i) {
      if (i === 0) return '<td class="left">Total (' + dRows.length + ' lots)</td>';
      var meta = FIELD_META[f];
      if (meta && meta.sum) {
        var s = sumField(dRows, f);
        if (f === 'tds194h') return '<td class="num">' + (s ? '- ' + moneyFmt(Math.abs(s)) : '—') + '</td>';
        return '<td>' + (MONEY_FIELDS.has(f) ? moneyFmt(s) : numFmt(s)) + '</td>';
      }
      return '<td></td>';
    }).join('') + '</tr>';"""

if old_tfoot_pivot in text:
    text = text.replace(old_tfoot_pivot, new_tfoot_pivot, 1)
    print("Updated tfoot in renderPivot for tds194h")
else:
    print("old_tfoot_pivot not found, checking...")

# 5. Update Lot Inspection modal
text = text.replace(
    "'<div class=\"lic-row\"><span class=\"lic-k\">TDS u/s 194(H)</span><span class=\"lic-v\">₹ ' + moneyFmt(r.tds194h || 0) + '</span></div>'",
    "'<div class=\"lic-row\"><span class=\"lic-k\">TDS u/s 194(H) (-)</span><span class=\"lic-v\" style=\"color:var(--dim)\">- ₹ ' + moneyFmt(r.tds194h || 0) + '</span></div>'"
)

# 6. Update openPaymentAdvice texts
text = text.replace(
    "'5️⃣ TDS u/s 194(H) (2% of Service Charge): ₹ ' + inr(b.totTds194h)",
    "'5️⃣ TDS u/s 194(H) (- 2% of SC): - ₹ ' + inr(b.totTds194h)"
)
text = text.replace(
    "'5. TDS u/s 194(H) (2% of SC)       : Rs. ' + inr(b.totTds194h)",
    "'5. TDS u/s 194(H) (-) (2% of SC)   : - Rs. ' + inr(b.totTds194h)"
)
text = text.replace(
    "'<tr><td>5. TDS u/s 194(H) (2% of Service Charge)</td><td class=\"num\">₹ ' + inr(b.totTds194h) + '</td><td>TDS on Commission / Service Charge",
    "'<tr><td>5. TDS u/s 194(H) (-) (2% of SC)</td><td class=\"num\">- ₹ ' + inr(b.totTds194h) + '</td><td>Deducted from Service Charge (Net SC = SC − TDS 194H)"
)
text = text.replace(
    "'<div class=\"lic-row\"><span class=\"lic-k\">5. TDS u/s 194(H) (2% of SC)</span><span class=\"lic-v\">₹ ' + inr(b.totTds194h) + '</span></div>'",
    "'<div class=\"lic-row\"><span class=\"lic-k\">5. TDS u/s 194(H) (-) (2% of SC)</span><span class=\"lic-v\" style=\"color:var(--dim)\">- ₹ ' + inr(b.totTds194h) + '</span></div>'"
)

# 7. Remove any remaining ＋ icons from unhide / header menus
text = text.replace(
    "'<span class=\"cm-check\">＋</span>' +\n        '<span class=\"cm-label\">' + escHtml(c.label) + '</span>'",
    "'<span class=\"cm-check\">↺</span>' +\n        '<span class=\"cm-label\">' + escHtml(c.label) + '</span>'"
)
text = text.replace(
    "'<button type=\"button\" class=\"cm-item\" data-act=\"unhideall\"><span class=\"cm-check\">＋</span><span class=\"cm-label\">Unhide all columns</span></button>'",
    "'<button type=\"button\" class=\"cm-item\" data-act=\"unhideall\"><span class=\"cm-check\">↺</span><span class=\"cm-label\">Unhide all columns</span></button>'"
)

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)

print("Saved updated index.html with all TDS 194(H) and button changes!")
