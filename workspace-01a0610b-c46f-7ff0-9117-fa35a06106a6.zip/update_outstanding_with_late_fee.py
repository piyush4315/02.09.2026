import re
import json

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update normalizeLot
    # Old: r.outstanding = has('outstanding') ? N('outstanding') : (r.total_receivables - r.total_received);
    # or similar
    content = re.sub(
        r"r\.outstanding\s*=\s*has\('outstanding'\)\s*\?\s*N\('outstanding'\)\s*:\s*\(r\.total_receivables\s*-\s*r\.total_received\);",
        r"r.outstanding = (r._manual && r._manual.outstanding && has('outstanding')) ? N('outstanding') : Math.round(r.total_receivables + r.late_fee - r.total_received);",
        content
    )

    # 2. Update recalcRow
    # Old: r.outstanding = n('total_receivables') - r.total_received;
    content = re.sub(
        r"r\.outstanding\s*=\s*n\('total_receivables'\)\s*-\s*r\.total_received;",
        r"r.outstanding = Math.round(n('total_receivables') + n('late_fee') - r.total_received);",
        content
    )

    # 3. Update recalcLotForm
    # Old: outstanding: tric - recd
    content = re.sub(
        r"outstanding:\s*tric\s*-\s*recd",
        r"outstanding: Math.round(tric + (typeof lateFee !== 'undefined' ? lateFee : 0) - recd)",
        content
    )

    # 4. Update computeAdviceBreakdown
    old_advice_calc = """  var totReceived = lotsList.reduce(function (a, r) { return a + (Number(r.total_received) || 0); }, 0);
  var totOut = lotsList.reduce(function (a, r) { return a + (Number(r.outstanding) || 0); }, 0);"""

    new_advice_calc = """  var totLateFee = lotsList.reduce(function (a, r) { return a + (Number(r.late_fee) || 0); }, 0);
  var totReceived = lotsList.reduce(function (a, r) { return a + (Number(r.total_received) || 0); }, 0);
  var totOut = lotsList.reduce(function (a, r) { return a + (Number(r.outstanding) || 0); }, 0);
  if (totOut === 0 && (totRec + totLateFee - totReceived) > 0) {
    totOut = Math.round(totRec + totLateFee - totReceived);
  }"""

    if old_advice_calc in content:
        content = content.replace(old_advice_calc, new_advice_calc)
    else:
        print(f"Warning: old_advice_calc not found directly in {fpath}")

    # Also update return object of computeAdviceBreakdown
    old_advice_return = """    totReceived: totReceived,
    totOut: totOut,
    sdDatesStr: sdDatesStr,"""

    new_advice_return = """    totLateFee: totLateFee,
    totReceived: totReceived,
    totOut: totOut,
    sdDatesStr: sdDatesStr,"""

    if old_advice_return in content:
        content = content.replace(old_advice_return, new_advice_return)

    # 5. In generateWhatsAppAdviceText, add Late Fee section if totLateFee > 0
    old_wa_fp = """    '2️⃣ *Final Payment (FP - after GST TDS):*\\n' +
    '   • FP Expected: ₹ ' + inr(b.totFpExp) + '\\n' +
    fpRecLine +
    '   • *FP Balance Due:* ₹ ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\\n' +"""

    new_wa_fp = """    '2️⃣ *Final Payment (FP - after GST TDS):*\\n' +
    '   • FP Expected: ₹ ' + inr(b.totFpExp) + '\\n' +
    fpRecLine +
    '   • *FP Balance Due:* ₹ ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? '  ✅ [PAID/SETTLED]' : '  ⏳ [PENDING]') + '\\n' +
    (b.totLateFee > 0 ? ('3️⃣ *Late Fee @ 1%/wk (from 24.08.2026):*\\n   • *Late Fee Due:* ₹ ' + inr(b.totLateFee) + '\\n') : '') +"""

    if old_wa_fp in content:
        content = content.replace(old_wa_fp, new_wa_fp)

    # 6. In generateEmailAdviceText, add Late Fee section if totLateFee > 0
    old_email_fp = """    '2. Final Payment (FP - after GST TDS):\\n' +
    '   - Expected : Rs. ' + inr(b.totFpExp) + '\\n' +
    '   ' + fpRecEmail + '\\n' +
    '   - Balance Due : Rs. ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\\n\\n' +"""

    new_email_fp = """    '2. Final Payment (FP - after GST TDS):\\n' +
    '   - Expected : Rs. ' + inr(b.totFpExp) + '\\n' +
    '   ' + fpRecEmail + '\\n' +
    '   - Balance Due : Rs. ' + inr(b.totFpDue) + (b.totFpDue <= 1 ? ' (SETTLED)' : ' (DUE)') + '\\n\\n' +
    (b.totLateFee > 0 ? ('3. Late Fee @ 1%/wk (from 24.08.2026):\\n   - Late Fee Accrued : Rs. ' + inr(b.totLateFee) + '\\n\\n') : '') +"""

    if old_email_fp in content:
        content = content.replace(old_email_fp, new_email_fp)

    # 7. In printPaymentAdvice, add Late Fee row if totLateFee > 0
    old_print_fp = """      '<tr><td><b>2. Final Payment (FP - after GST TDS)</b></td><td class="num">₹ ' + inr(b.totFpExp) + '</td><td class="num">₹ ' + inr(b.totFpRec) + '</td><td style="font-weight:bold;color:#002FA7">' + escHtml(b.fpDatesStr || '—') + '</td><td class="num" style="font-weight:bold">' + (b.totFpDue > 1 ? ('₹ ' + inr(b.totFpDue)) : '₹ 0') + '</td><td>' + (b.totFpDue <= 1 ? 'PAID / SETTLED' : 'PENDING PAYMENT') + '</td></tr>' +"""

    new_print_fp = """      '<tr><td><b>2. Final Payment (FP - after GST TDS)</b></td><td class="num">₹ ' + inr(b.totFpExp) + '</td><td class="num">₹ ' + inr(b.totFpRec) + '</td><td style="font-weight:bold;color:#002FA7">' + escHtml(b.fpDatesStr || '—') + '</td><td class="num" style="font-weight:bold">' + (b.totFpDue > 1 ? ('₹ ' + inr(b.totFpDue)) : '₹ 0') + '</td><td>' + (b.totFpDue <= 1 ? 'PAID / SETTLED' : 'PENDING PAYMENT') + '</td></tr>' +
      (b.totLateFee > 0 ? ('<tr><td><b>3. Late Fee @ 1%/wk (from 24.08.2026)</b></td><td class="num">₹ ' + inr(b.totLateFee) + '</td><td class="num">—</td><td>—</td><td class="num" style="font-weight:bold;color:#be123c">₹ ' + inr(b.totLateFee) + '</td><td>ACCRUED / DUE</td></tr>') : '') +"""

    if old_print_fp in content:
        content = content.replace(old_print_fp, new_print_fp)

    # 8. In XLSX_COLS in HTML, ensure late_fee is included and outstanding formula is correct
    old_xlsx_cols = """  ['total_received', 'Total Received', 'f:ROUND(U{r}+X{r},0)'],
  ['outstanding', 'Outstanding', 'f:ROUND(S{r}-Z{r},0)'],
  ['settlement_status', 'Settled / Unsettled', 'f:IF(AA{r}<=5,"Settled","Unsettled")'],"""

    new_xlsx_cols = """  ['late_fee', 'Late Fee @ 1%', 'f:IF(Y{r}="", IF(AC{r}="Unsettled", ROUND(W{r}*ROUNDUP((DATE(2026,8,31)-DATE(2026,8,24))/7,0)*0.01, 0), 0), IF(DATE(MID(Y{r},7,4), MID(Y{r},4,2), MID(Y{r},1,2))>DATE(2026,8,24), ROUND(W{r}*ROUNDUP((DATE(MID(Y{r},7,4), MID(Y{r},4,2), MID(Y{r},1,2))-DATE(2026,8,24))/7,0)*0.01, 0), 0))'],
  ['total_received', 'Total Received', 'f:ROUND(U{r}+X{r},0)'],
  ['outstanding', 'Outstanding', 'f:ROUND(S{r}+Z{r}-AA{r},0)'],
  ['settlement_status', 'Settled / Unsettled', 'f:IF(AB{r}<=5,"Settled","Unsettled")'],"""

    if old_xlsx_cols in content:
        content = content.replace(old_xlsx_cols, new_xlsx_cols)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"Updated {fpath} successfully!")
