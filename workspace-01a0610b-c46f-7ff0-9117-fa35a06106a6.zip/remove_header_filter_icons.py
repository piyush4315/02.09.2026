import re

files_to_update = [
    '/home/user/index.html',
    '/home/user/app.html',
    '/home/user/scrapsale.html',
    '/home/user/ScrapSale_Pro.html',
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale_Pro.html',
    '/home/user/uploads/app.html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html'
]

for path in files_to_update:
    with open(path, 'r', encoding='utf-8') as f:
        text = f.read()

    # 1. Simplify thPickerHtml
    pos_th = text.find('function thPickerHtml(')
    if pos_th != -1:
        pos_format = text.find('function formatCellValue(', pos_th)
        if pos_format != -1:
            new_th_fn = """function thPickerHtml(field, table, place, layoutKind) {
  var isSorted = sortState.table === table && sortState.key === field;
  var arrow = isSorted ? (sortState.dir === 1 ? ' ▲' : ' ▼') : '';
  var kind = fieldKind(field);
  var isCenter = (kind === 'center' || kind === 'date' || kind === 'date-edit' || kind === 'status' || field === 'lot_no' || field === 'unit' || field === 'invoice_no' || field === 'sap_document_date' || field === 'sd_date' || field === 'fp_date' || field === 'doc_invoice_date' || field === 'auction' || field === 'settlement_status');
  var cls = isCenter ? 'center' : ((kind === 'left') ? 'left' : '');
  var dragAttr = (layoutKind === 'detail' || layoutKind === 'pivotLot' || layoutKind === 'pivotMetric') ? ' draggable="true"' : '';
  var filterKey = (table === 'pivot' && ui.groupBy !== 'default' && field !== ui.groupBy && field !== 'key' && field !== 'settlement_status' && field !== 'settled_breakdown')
    ? ('pivot_' + field)
    : (field === 'key' ? ui.groupBy : field);
  var hasFilter = colFilterOn(filterKey);

  return '<th class="' + cls + (hasFilter ? ' has-filter' : '') + '"' + dragAttr + ' data-field="' + escHtml(field) + '" data-table="' + table + '" data-place="' + place + '" data-layout="' + layoutKind + '">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(fieldLabel(field)) + '</span>' +
      (arrow ? '<span class="arrow">' + arrow + '</span>' : '') +
    '</span></th>';
}
"""
            text = text[:pos_th] + new_th_fn + text[pos_format:]

    # 2. Simplify buyer grouped thead in renderPivot
    pos_buyer_th = text.find("var groupFilterKey = (groupKey === 'key' ? ui.groupBy : groupKey);")
    if pos_buyer_th != -1:
        pos_thead_end = text.find("metricKeys.map(function (f, i) { return thPickerHtml(f, 'pivot', i, 'pivotMetric'); }).join('') + '</tr>';", pos_buyer_th)
        if pos_thead_end != -1:
            end_idx = pos_thead_end + len("metricKeys.map(function (f, i) { return thPickerHtml(f, 'pivot', i, 'pivotMetric'); }).join('') + '</tr>';")
            new_buyer_thead = """var groupFilterKey = (groupKey === 'key' ? ui.groupBy : groupKey);
  var groupHasFilter = colFilterOn(groupFilterKey);

  thead.innerHTML = '<tr><th class="' + (isBuyerGroup ? 'left th-buyer' : 'left') + (groupHasFilter ? ' has-filter' : '') + '" data-field="' + escHtml(groupKey) + '"' + (isBuyerGroup ? ' data-group="buyer"' : '') + ' data-table="pivot">' +
    '<span class="th-wrap">' +
      '<span class="th-label">' + escHtml(groupLabel) + '</span>' +
      (sortState.table === 'pivot' && sortState.key === 'key' ? '<span class="arrow">' + (sortState.dir === 1 ? ' ▲' : ' ▼') + '</span>' : '') +
    '</span>' +
    '</th>' + metricKeys.map(function (f, i) { return thPickerHtml(f, 'pivot', i, 'pivotMetric'); }).join('') + '</tr>';"""
            text = text[:pos_buyer_th] + new_buyer_thead + text[end_idx:]

    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)

    print(f'Cleaned header filter icons in {path}: th-filt-btn count = {text.count("th-filt-btn")}')
