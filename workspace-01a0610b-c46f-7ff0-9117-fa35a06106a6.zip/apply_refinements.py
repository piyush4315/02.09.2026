import re

def process_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. CSS: Suppress single click focus outline on td
    # Find table tbody td:focus...
    focus_css_pattern = r'table tbody td:focus:not\(\.rng\),\s*table tbody td:focus-visible:not\(\.rng\)\s*\{[^}]*\}'
    focus_css_replacement = '''table tbody td:focus,
table tbody td:focus-visible,
table tbody td:focus:not(.rng),
table tbody td:focus-visible:not(.rng){
  outline:none!important;
  outline-offset:0!important;
}'''
    if re.search(focus_css_pattern, content):
        content = re.sub(focus_css_pattern, focus_css_replacement, content)
    else:
        # Fallback if not matched
        content = content.replace(
            'table tbody td:focus:not(.rng)',
            'table tbody td:focus, table tbody td:focus-visible, table tbody td:focus:not(.rng)'
        )

    # 2. Increase Material Value width from 72px to 96px
    content = re.sub(
        r'table th\[data-field="mat_value"\],table td\[data-field="mat_value"\]\{min-width:72px\}',
        'table th[data-field="mat_value"],table td[data-field="mat_value"]{min-width:96px}',
        content
    )
    content = re.sub(
        r'table th\[data-field="mat_value_plus_gst"\],table td\[data-field="mat_value_plus_gst"\]\{min-width:80px\}',
        'table th[data-field="mat_value_plus_gst"],table td[data-field="mat_value_plus_gst"]{min-width:96px}',
        content
    )

    # 3. Label updates: "Late Fee @ 1%" -> "Late Fee"
    # Column definitions
    content = content.replace("late_fee: { label: 'Late Fee\\u00AD@ 1%'", "late_fee: { label: 'Late Fee'")
    content = content.replace("late_fee: { label: 'Late Fee @ 1%'", "late_fee: { label: 'Late Fee'")
    content = content.replace("['late_fee', 'Late Fee @ 1%'", "['late_fee', 'Late Fee'")
    content = content.replace("['late_fee', 'Late Fee @ 1%/wk'", "['late_fee', 'Late Fee'")
    content = content.replace('<span class="lic-k">Late Fee @ 1%</span>', '<span class="lic-k">Late Fee</span>')
    content = content.replace('3️⃣ *Late Fee @ 1%/wk (from 24.08.2026):*', '3️⃣ *Late Fee (from 24.08.2026):*')
    content = content.replace('3. Late Fee @ 1% per week (from 24.08.2026):', '3. Late Fee (from 24.08.2026):')
    content = content.replace('<b>3. Late Fee @ 1%/wk (from 24.08.2026)</b>', '<b>3. Late Fee (from 24.08.2026)</b>')
    content = content.replace('<th style="padding:5px 7px;color:#f9a8d4">Late Fee @ 1%</th>', '<th style="padding:5px 7px;color:#f9a8d4">Late Fee</th>')
    content = content.replace('<th class="num">Late Fee @ 1%</th>', '<th class="num">Late Fee</th>')
    content = content.replace('<div class="kpi-lbl">Late Fee @ 1%/wk</div>', '<div class="kpi-lbl">Late Fee</div>')
    content = content.replace('3️⃣ Late Fee @ 1%/wk (from 24.08.2026)', '3️⃣ Late Fee (from 24.08.2026)')
    content = content.replace('3. Late Fee @ 1%', '3. Late Fee')

    # 4. JS: gridPaint - Do not outline on single click; outline on Ctrl+click / Shift+range
    old_gridpaint_snippet = """  // Paint range selection (Shift+click or normal click)
  if (gridSel.r1 != null) {
    var rmin = Math.min(gridSel.r1, gridSel.r2), rmax = Math.max(gridSel.r1, gridSel.r2);
    var cmin = Math.min(gridSel.c1, gridSel.c2), cmax = Math.max(gridSel.c1, gridSel.c2);
    var isMultiCell = (rmin !== rmax || cmin !== cmax || (gridSel.selectedCells && gridSel.selectedCells.length > 1));
    for (var r = rmin; r <= rmax; r++) {
      var tr = bodyRows[r];
      if (!tr || !tr.children) continue;
      for (var c2 = cmin; c2 <= cmax; c2++) {
        var td = tr.children[c2];
        if (!td) continue;
        td.classList.add('rng');
        if (r === rmin) td.classList.add('rng-top');
        if (r === rmax) td.classList.add('rng-bottom');
        if (c2 === cmin) td.classList.add('rng-left');
        if (c2 === cmax) td.classList.add('rng-right');
        if (!isMultiCell && r === gridSel.ar && c2 === gridSel.ac) {
          td.classList.add('rng-anchor');
        }
      }
    }
  }"""

    new_gridpaint_snippet = """  // Paint range selection (Shift+drag/click multi-cell range only)
  var hasCtrlSelection = (gridSel.selectedCells && gridSel.selectedCells.length > 0);
  if (gridSel.r1 != null) {
    var rmin = Math.min(gridSel.r1, gridSel.r2), rmax = Math.max(gridSel.r1, gridSel.r2);
    var cmin = Math.min(gridSel.c1, gridSel.c2), cmax = Math.max(gridSel.c1, gridSel.c2);
    var isRangeMulti = (rmin !== rmax || cmin !== cmax);
    
    // Only paint bounding outline on range selection if multi-cell range is selected
    if (isRangeMulti) {
      for (var r = rmin; r <= rmax; r++) {
        var tr = bodyRows[r];
        if (!tr || !tr.children) continue;
        for (var c2 = cmin; c2 <= cmax; c2++) {
          var td = tr.children[c2];
          if (!td) continue;
          td.classList.add('rng');
          if (r === rmin) td.classList.add('rng-top');
          if (r === rmax) td.classList.add('rng-bottom');
          if (c2 === cmin) td.classList.add('rng-left');
          if (c2 === cmax) td.classList.add('rng-right');
        }
      }
    }
  }"""

    if old_gridpaint_snippet in content:
        content = content.replace(old_gridpaint_snippet, new_gridpaint_snippet)
        print("Updated gridPaint snippet successfully.")
    else:
        print("Warning: old_gridpaint_snippet not matched directly, looking for regex...")

    # 5. gridShowInfo - Show HUD on Ctrl+click (even single Ctrl+clicked cell or multi) or multi range
    old_gridinfo_snippet = """  var selectedTds = Array.prototype.slice.call(table.querySelectorAll('tbody td.rng'));
  if (selectedTds.length < 2) {
    el.style.display = 'none';
    el.innerHTML = '';
    return;
  }"""

    new_gridinfo_snippet = """  var selectedTds = Array.prototype.slice.call(table.querySelectorAll('tbody td.rng'));
  if (selectedTds.length === 0) {
    el.style.display = 'none';
    el.innerHTML = '';
    return;
  }"""

    if old_gridinfo_snippet in content:
        content = content.replace(old_gridinfo_snippet, new_gridinfo_snippet)
        print("Updated gridShowInfo snippet successfully.")
    else:
        print("Warning: old_gridinfo_snippet not matched directly.")

    # 6. Disable right click on date fields in contextmenu handler
    old_ctx_start = "  document.addEventListener('contextmenu', function (e) {"
    new_ctx_start = """  document.addEventListener('contextmenu', function (e) {
    /* Check if right-click is on any date field or date component — strictly disable */
    var dateEl = e.target && e.target.closest ? e.target.closest(
      'td[data-field="sd_date"], td[data-field="fp_date"], td[data-field="sap_document_date"], td[data-field="doc_invoice_date"], ' +
      'th[data-field="sd_date"], th[data-field="fp_date"], th[data-field="sap_document_date"], th[data-field="doc_invoice_date"], ' +
      'input.dt-edit, .date-empty-editor, td.dt-cell, td.date, .dt-click-area, .dt-text, [data-field="sd_date"] input, [data-field="fp_date"] input, [data-field="doc_invoice_date"] input, [data-field="sap_document_date"] input'
    ) : null;
    if (dateEl) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }"""

    if old_ctx_start in content and "/* Check if right-click is on any date field" not in content:
        content = content.replace(old_ctx_start, new_ctx_start, 1)
        print("Updated contextmenu date suppression successfully.")

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"File {file_path} processed and saved.")

process_file('/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
process_file('/home/user/index.html')
process_file('/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html')
