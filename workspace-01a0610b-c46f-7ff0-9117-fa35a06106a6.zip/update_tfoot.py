with open("/home/user/index.html", "r", encoding="utf-8") as f:
    text = f.read()

old_str = """      var cls = f === 'outstanding' ? ((s > 1 ? 'pos' : (s < -1 ? 'neg' : 'zero'))) : (fieldKind(f) === 'strong' ? 'strong' : '');
      return '<td class="' + cls + '" data-field="' + escHtml(f) + '">' + (MONEY_FIELDS.has(f) ? moneyFmt(s) : numFmt(s)) + '</td>';"""

new_str = """      var cls = f === 'outstanding' ? ((s > 1 ? 'pos' : (s < -1 ? 'neg' : 'zero'))) : (fieldKind(f) === 'strong' ? 'strong' : '');
      if (f === 'tds194h') return '<td class="' + cls + '" data-field="' + escHtml(f) + '">' + (s ? '- ' + moneyFmt(Math.abs(s)) : '—') + '</td>';
      return '<td class="' + cls + '" data-field="' + escHtml(f) + '">' + (MONEY_FIELDS.has(f) ? moneyFmt(s) : numFmt(s)) + '</td>';"""

if old_str in text:
    text = text.replace(old_str, new_str, 1)
    print("Updated tfoot in renderDetailInto successfully!")
else:
    print("old_str not found!")

with open("/home/user/index.html", "w", encoding="utf-8") as f:
    f.write(text)
