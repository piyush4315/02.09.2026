import re

files = [
    '/home/user/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/uploads/ScrapSale Pro — Cash Receivables SaaS v2.2 (2026-08-30).html',
    '/home/user/index.html'
]

# 1. Update CSS
css_late_fee = '''table th[data-field="late_fee"],table th[data-field="late_fee"] .th-wrap,table th[data-field="late_fee"] .th-label{
  min-width:68px;max-width:84px;white-space:normal!important;word-break:break-word;overflow-wrap:break-word;hyphens:auto;-webkit-hyphens:auto;text-align:center!important;justify-content:center!important;line-height:1.15;
}
table td[data-field="late_fee"],table td[data-field="late_fee"] input{
  min-width:74px;text-align:right!important;white-space:nowrap!important;
}'''

# 2. Update parseDateStr & calcLateFee
js_calc_late_fee = '''function parseDateStr(s) {
  if (!s || s === '—') return null;
  var str = String(s);
  var m = str.match(/^(\\d{1,2})[.\\-/](\\d{1,2})[.\\-/](\\d{2,4})/);
  if (m) {
    var d = +m[1], mo = +m[2] - 1, y = +m[3];
    if (y < 100) y = 2000 + y;
    return new Date(y, mo, d);
  }
  var iso = str.match(/^(\\d{4})-(\\d{2})-(\\d{2})/);
  if (iso) {
    return new Date(+iso[1], +iso[2] - 1, +iso[3]);
  }
  return null;
}

function calcLateFee(r) {
  var baseDate = new Date(2026, 7, 24); // 24 Aug 2026 (0-indexed month 7)
  var payDate = null;
  if (r && r.fp_date) {
    payDate = parseDateStr(r.fp_date);
  }
  var isSettled = (numOr(r && r.outstanding) <= SETTLEMENT_TOLERANCE && numOr(r && r.fp_received) > 0);
  if (!payDate) {
    if (!isSettled) {
      payDate = new Date(2026, 7, 31); // 31 Aug 2026
    } else {
      payDate = baseDate;
    }
  }
  if (!payDate) return 0;
  var diffMs = payDate.getTime() - baseDate.getTime();
  var diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays <= 0) return 0;
  var weeks = Math.ceil(diffDays / 7);
  var baseAmt = numOr(r && r.fp_expected) || numOr(r && r.mat_value);
  return Math.round(baseAmt * weeks * 0.01);
}
window.calcLateFee = calcLateFee;
'''

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        c = f.read()

    # Add CSS
    c = c.replace('/* Popup Calendar for Date Selection */', css_late_fee + '\n/* Popup Calendar for Date Selection */', 1)

    # Add NUM_FIELDS & MONEY_FIELDS & EDITABLE_FIELDS late_fee
    c = c.replace("var NUM_FIELDS = ['qty',", "var NUM_FIELDS = ['qty','late_fee',", 1)
    c = c.replace("var MONEY_FIELDS = new Set(['mat_value',", "var MONEY_FIELDS = new Set(['late_fee','mat_value',", 1)
    c = c.replace("var EDITABLE_FIELDS = ['gst_tds_rate',", "var EDITABLE_FIELDS = ['late_fee','gst_tds_rate',", 1)

    # Add parseDateStr & calcLateFee
    c = c.replace('function dottedDate(v) {', js_calc_late_fee + '\nfunction dottedDate(v) {', 1)

    # Update normalizeLot
    old_norm = "r.fp_date = D('fp_date');"
    new_norm = "r.fp_date = D('fp_date');\n  r.late_fee = has('late_fee') ? N('late_fee') : calcLateFee(r);"
    c = c.replace(old_norm, new_norm, 1)

    # Update recalcRow
    old_recalc = "if (changed.indexOf('gst_tds_rate') !== -1) {"
    new_recalc = """if (changed.indexOf('late_fee') !== -1) {
    r._manual.late_fee = true;
  } else if (!r._manual.late_fee && (changed.indexOf('fp_date') !== -1 || changed.indexOf('mat_value') !== -1 || changed.indexOf('fp_expected') !== -1 || changed.indexOf('qty') !== -1 || changed.indexOf('rate') !== -1)) {
    r.late_fee = calcLateFee(r);
  }
  if (changed.indexOf('gst_tds_rate') !== -1) {"""
    c = c.replace(old_recalc, new_recalc, 1)

    # Update DEFAULT_DETAIL_KEYS
    old_detail_keys = "var DEFAULT_DETAIL_KEYS = ['qty','rate','lot_name','auction','unit','lot_no','buyer','mat_value','gst','mat_value_plus_gst','tcs','tds194o','service_charge_mstc','tds194h','net_service_charge','service_charge_to_mstc','gst_tds_rate','gst_tds','total_receivables','sd_expected','sd_received','sd_date','fp_expected','fp_received','fp_date','total_received','outstanding','settlement_status','invoice_no','sap_document_date','doc_invoice_date'];"
    new_detail_keys = "var DEFAULT_DETAIL_KEYS = ['qty','rate','lot_name','auction','unit','lot_no','buyer','mat_value','gst','mat_value_plus_gst','tcs','tds194o','service_charge_mstc','tds194h','net_service_charge','service_charge_to_mstc','gst_tds_rate','gst_tds','total_receivables','sd_expected','sd_received','sd_date','fp_expected','fp_received','fp_date','late_fee','total_received','outstanding','settlement_status','invoice_no','sap_document_date','doc_invoice_date'];"
    c = c.replace(old_detail_keys, new_detail_keys)

    # Update DEFAULT_PIVOT_METRIC_KEYS
    old_pivot_metrics = "var DEFAULT_PIVOT_METRIC_KEYS = ['lots','mat_value','gst','tcs','total_receivables','sd_expected','sd_received','fp_expected','fp_received','total_received','outstanding','settled_breakdown'];"
    new_pivot_metrics = "var DEFAULT_PIVOT_METRIC_KEYS = ['lots','mat_value','gst','tcs','total_receivables','sd_expected','sd_received','fp_expected','fp_received','late_fee','total_received','outstanding','settled_breakdown'];"
    c = c.replace(old_pivot_metrics, new_pivot_metrics)

    # Update DEFAULT_PIVOT_LOT_KEYS
    old_pivot_lots = "var DEFAULT_PIVOT_LOT_KEYS = ['lot_no','buyer','total_receivables','sd_expected','sd_received','sd_date','fp_expected','fp_received','fp_date','total_received','outstanding','settlement_status'];"
    new_pivot_lots = "var DEFAULT_PIVOT_LOT_KEYS = ['lot_no','buyer','total_receivables','sd_expected','sd_received','sd_date','fp_expected','fp_received','fp_date','late_fee','total_received','outstanding','settlement_status'];"
    c = c.replace(old_pivot_lots, new_pivot_lots)

    # Update FIELD_META
    old_field_meta = "fp_date: { label: 'FP Date', kind: 'date-edit', sum: false, edit: true },"
    new_field_meta = "fp_date: { label: 'FP Date', kind: 'date-edit', sum: false, edit: true },\n  late_fee: { label: 'Late Fee\\u00AD@ 1%', kind: 'edit', sum: true, edit: true },"
    c = c.replace(old_field_meta, new_field_meta, 1)

    # Update isEditableField
    old_is_editable = "key === 'doc_invoice_date';"
    new_is_editable = "key === 'doc_invoice_date' || key === 'late_fee';"
    c = c.replace(old_is_editable, new_is_editable, 1)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(c)

    print(f'Updated {fpath} with late_fee')

print('Finished updating web application files.')
