const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1400, height: 900 }
  });
  const page = await context.newPage();
  
  await page.goto("file:///home/user/index.html");
  await page.waitForTimeout(600);

  const stats = await page.evaluate(() => {
    return {
      lotsCount: lots ? lots.length : 0,
      buyersCount: new Set(lots.map(l => l.buyer)).size,
      totMatValue: lots.reduce((a, b) => a + (b.mat_value || 0), 0),
      totReceivables: lots.reduce((a, b) => a + (b.total_receivables || 0), 0),
      totReceived: lots.reduce((a, b) => a + (b.total_received || 0), 0),
      totOutstanding: lots.reduce((a, b) => a + (b.outstanding || 0), 0),
      sampleLot1874: lots.find(l => String(l.lot_no) === "1874"),
      sampleLot1923: lots.find(l => String(l.lot_no) === "1923"),
      sampleLot1763: lots.find(l => String(l.lot_no) === "1763")
    };
  });

  console.log("Updated App Stats:", JSON.stringify({
    lotsCount: stats.lotsCount,
    buyersCount: stats.buyersCount,
    totMatValue: stats.totMatValue,
    totReceivables: stats.totReceivables,
    totReceived: stats.totReceived,
    totOutstanding: stats.totOutstanding
  }, null, 2));

  console.log("Lot 1874:", JSON.stringify(stats.sampleLot1874, null, 2));
  console.log("Lot 1923:", JSON.stringify(stats.sampleLot1923, null, 2));

  // Take proof screenshot
  await page.screenshot({ path: "/home/user/updated_csv_data_proof.png" });

  await browser.close();
  console.log("Updated CSV data verification complete!");
})();
