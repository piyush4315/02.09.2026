const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  // iPhone 14 Pro portrait dimensions: 393 x 852
  const page = await browser.newPage({
    viewport: { width: 393, height: 852 },
    isMobile: true,
    hasTouch: true
  });

  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);

  console.log('1. Testing click on Buyer row in grouped Pivot Analytics...');
  // Grouped view by Buyer: click first buyer row
  const firstBuyerTr = await page.$('#pivotTable tbody tr');
  if (firstBuyerTr) {
    const buyerName = await firstBuyerTr.evaluate(el => el.getAttribute('data-value'));
    console.log('Clicking on buyer row:', buyerName);
    await firstBuyerTr.click();
    await page.waitForTimeout(600);

    // Verify detail panel is filtered to this buyer
    const filterText = await page.evaluate(() => {
      const el = document.getElementById('detailCountDash');
      return el ? el.textContent : '';
    });
    console.log('Lot detail count after drill-down:', filterText);
    await page.screenshot({ path: '/home/user/mobile_drilled_lot_detail.png' });
  }

  console.log('2. Testing click on Lot No. in drilled Lot Details table...');
  const lotNoCell = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (lotNoCell) {
    console.log('Clicking on lot no cell...');
    await lotNoCell.click();
    await page.waitForTimeout(500);

    const isModalVisible = await page.evaluate(() => {
      const modal = document.querySelector('.lot-inspect-modal, .modal.ultra-wide');
      return modal ? {
        visible: true,
        title: modal.querySelector('.modal-head h3')?.textContent,
        bodyHeight: modal.querySelector('.modal-body')?.offsetHeight,
        bodyScrollHeight: modal.querySelector('.modal-body')?.scrollHeight,
        cardsCount: modal.querySelectorAll('.lot-inspect-col').length,
        buttons: Array.from(modal.querySelectorAll('.modal-foot .btn')).map(b => b.textContent.trim())
      } : { visible: false };
    });
    console.log('Lot Details modal info:', JSON.stringify(isModalVisible, null, 2));

    await page.screenshot({ path: '/home/user/mobile_lot_details_window_portrait.png' });
    console.log('Saved mobile_lot_details_window_portrait.png');

    // Test scrolling inside the modal body
    await page.evaluate(() => {
      const mb = document.querySelector('.modal-body');
      if (mb) mb.scrollTop = 350;
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: '/home/user/mobile_lot_details_window_scrolled.png' });
    console.log('Saved mobile_lot_details_window_scrolled.png');

    // Test clicking "Close" button
    const closeBtn = await page.$('.modal-foot .btn.secondary:has-text("Close")');
    if (closeBtn) {
      await closeBtn.click();
      await page.waitForTimeout(300);
      console.log('Modal closed successfully.');
    }
  }

  console.log('3. Testing click on Buyer cell directly in Lot Details table...');
  const buyerCell = await page.$('#detailTableDash tbody td[data-field="buyer"]');
  if (buyerCell) {
    console.log('Clicking on buyer cell...');
    await buyerCell.click();
    await page.waitForTimeout(500);

    const isModalOpen = await page.evaluate(() => !!document.querySelector('.modal'));
    console.log('Modal opened on buyer click:', isModalOpen);
    await page.screenshot({ path: '/home/user/mobile_buyer_click_modal.png' });

    // Close modal
    await page.evaluate(() => {
      const closeBtn = document.querySelector('.modal .xclose, .modal-foot .btn:last-child');
      if (closeBtn) closeBtn.click();
    });
    await page.waitForTimeout(300);
  }

  // Light theme test on mobile portrait
  console.log('4. Testing Light Theme on mobile portrait...');
  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'light');
  });
  await page.waitForTimeout(300);
  const lotNoCellLight = await page.$('#detailTableDash tbody td[data-field="lot_no"]');
  if (lotNoCellLight) {
    await lotNoCellLight.click();
    await page.waitForTimeout(400);
    await page.screenshot({ path: '/home/user/mobile_lot_details_light_theme.png' });
    console.log('Saved mobile_lot_details_light_theme.png');
  }

  await browser.close();
  console.log('ALL MOBILE PORTRAIT TESTS PASSED!');
})();
